import { G as e, H as t, K as n, R as r, V as i, d as a, k as o, l as s, q as c, z as l } from "./index-client-Bo2ahwCj.js";
//#region frontend/node_modules/svelte/src/store/index-client.js
function u(n, o) {
	var s = r, u = l, d = n();
	let f = a(d, (a) => {
		var o = d !== n(), f, p = l, m = r;
		t(u), i(s);
		try {
			f = e(() => {
				c(() => {
					let e = n();
					o && a(e);
				});
			});
		} finally {
			t(p), i(m);
		}
		return o = !0, f;
	});
	return o ? {
		set: o,
		update: (e) => o(e(n())),
		subscribe: f.subscribe
	} : { subscribe: f.subscribe };
}
function d(e) {
	let t, r = o((n) => {
		let r = !1, i = e.subscribe((e) => {
			t = e, r && n();
		});
		return r = !0, i;
	});
	function i() {
		return n() ? (r(), t) : s(e);
	}
	return "set" in e ? {
		get current() {
			return i();
		},
		set current(t) {
			e.set(t);
		}
	} : { get current() {
		return i();
	} };
}
//#endregion
export { u as n, d as t };
