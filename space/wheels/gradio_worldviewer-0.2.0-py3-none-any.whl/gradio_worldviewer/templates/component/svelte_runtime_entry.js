import { t as e } from "./rolldown-runtime-Dy4uBu1J.js";
import { E as t, O as n, ct as r, x as i } from "./index-client-Bo2ahwCj.js";
//#region frontend/node_modules/svelte/src/internal/disclose-version.js
var a = /* @__PURE__ */ e({});
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
//#endregion
export { a as SVELTE_VERSION, i as createRawSnippet, r as getAllContexts, t as mount, n as unmount };
