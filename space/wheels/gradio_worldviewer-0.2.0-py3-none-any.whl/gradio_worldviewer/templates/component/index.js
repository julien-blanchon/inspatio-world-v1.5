import { $ as e, A as t, B as n, C as r, D as i, F as a, I as o, J as s, M as c, N as l, P as u, Q as d, S as f, T as p, U as m, Y as h, Z as g, _ as ee, _t as _, at as v, b as y, dt as te, et as b, f as ne, g as x, gt as S, h as re, ht as C, i as w, j as ie, m as ae, n as oe, ot as se, p as ce, r as T, rt as E, st as D, t as le, tt as O, ut as ue, v as k, vt as A, w as j, y as de, yt as fe } from "./index-client-Bo2ahwCj.js";
import { t as M } from "./index-client-C_FtlK5K.js";
//#region frontend/node_modules/@gradio/theme/dist/src/colors.js
var N = [
	{
		color: "red",
		primary: 600,
		secondary: 100
	},
	{
		color: "green",
		primary: 600,
		secondary: 100
	},
	{
		color: "blue",
		primary: 600,
		secondary: 100
	},
	{
		color: "yellow",
		primary: 500,
		secondary: 100
	},
	{
		color: "purple",
		primary: 600,
		secondary: 100
	},
	{
		color: "teal",
		primary: 600,
		secondary: 100
	},
	{
		color: "orange",
		primary: 600,
		secondary: 100
	},
	{
		color: "cyan",
		primary: 600,
		secondary: 100
	},
	{
		color: "lime",
		primary: 500,
		secondary: 100
	},
	{
		color: "pink",
		primary: 600,
		secondary: 100
	}
], pe = {
	inherit: "inherit",
	current: "currentColor",
	transparent: "transparent",
	black: "#000",
	white: "#fff",
	slate: {
		50: "#f8fafc",
		100: "#f1f5f9",
		200: "#e2e8f0",
		300: "#cbd5e1",
		400: "#94a3b8",
		500: "#64748b",
		600: "#475569",
		700: "#334155",
		800: "#1e293b",
		900: "#0f172a",
		950: "#020617"
	},
	gray: {
		50: "#f9fafb",
		100: "#f3f4f6",
		200: "#e5e7eb",
		300: "#d1d5db",
		400: "#9ca3af",
		500: "#6b7280",
		600: "#4b5563",
		700: "#374151",
		800: "#1f2937",
		900: "#111827",
		950: "#030712"
	},
	zinc: {
		50: "#fafafa",
		100: "#f4f4f5",
		200: "#e4e4e7",
		300: "#d4d4d8",
		400: "#a1a1aa",
		500: "#71717a",
		600: "#52525b",
		700: "#3f3f46",
		800: "#27272a",
		900: "#18181b",
		950: "#09090b"
	},
	neutral: {
		50: "#fafafa",
		100: "#f5f5f5",
		200: "#e5e5e5",
		300: "#d4d4d4",
		400: "#a3a3a3",
		500: "#737373",
		600: "#525252",
		700: "#404040",
		800: "#262626",
		900: "#171717",
		950: "#0a0a0a"
	},
	stone: {
		50: "#fafaf9",
		100: "#f5f5f4",
		200: "#e7e5e4",
		300: "#d6d3d1",
		400: "#a8a29e",
		500: "#78716c",
		600: "#57534e",
		700: "#44403c",
		800: "#292524",
		900: "#1c1917",
		950: "#0c0a09"
	},
	red: {
		50: "#fef2f2",
		100: "#fee2e2",
		200: "#fecaca",
		300: "#fca5a5",
		400: "#f87171",
		500: "#ef4444",
		600: "#dc2626",
		700: "#b91c1c",
		800: "#991b1b",
		900: "#7f1d1d",
		950: "#450a0a"
	},
	orange: {
		50: "#fff7ed",
		100: "#ffedd5",
		200: "#fed7aa",
		300: "#fdba74",
		400: "#fb923c",
		500: "#f97316",
		600: "#ea580c",
		700: "#c2410c",
		800: "#9a3412",
		900: "#7c2d12",
		950: "#431407"
	},
	amber: {
		50: "#fffbeb",
		100: "#fef3c7",
		200: "#fde68a",
		300: "#fcd34d",
		400: "#fbbf24",
		500: "#f59e0b",
		600: "#d97706",
		700: "#b45309",
		800: "#92400e",
		900: "#78350f",
		950: "#451a03"
	},
	yellow: {
		50: "#fefce8",
		100: "#fef9c3",
		200: "#fef08a",
		300: "#fde047",
		400: "#facc15",
		500: "#eab308",
		600: "#ca8a04",
		700: "#a16207",
		800: "#854d0e",
		900: "#713f12",
		950: "#422006"
	},
	lime: {
		50: "#f7fee7",
		100: "#ecfccb",
		200: "#d9f99d",
		300: "#bef264",
		400: "#a3e635",
		500: "#84cc16",
		600: "#65a30d",
		700: "#4d7c0f",
		800: "#3f6212",
		900: "#365314",
		950: "#1a2e05"
	},
	green: {
		50: "#f0fdf4",
		100: "#dcfce7",
		200: "#bbf7d0",
		300: "#86efac",
		400: "#4ade80",
		500: "#22c55e",
		600: "#16a34a",
		700: "#15803d",
		800: "#166534",
		900: "#14532d",
		950: "#052e16"
	},
	emerald: {
		50: "#ecfdf5",
		100: "#d1fae5",
		200: "#a7f3d0",
		300: "#6ee7b7",
		400: "#34d399",
		500: "#10b981",
		600: "#059669",
		700: "#047857",
		800: "#065f46",
		900: "#064e3b",
		950: "#022c22"
	},
	teal: {
		50: "#f0fdfa",
		100: "#ccfbf1",
		200: "#99f6e4",
		300: "#5eead4",
		400: "#2dd4bf",
		500: "#14b8a6",
		600: "#0d9488",
		700: "#0f766e",
		800: "#115e59",
		900: "#134e4a",
		950: "#042f2e"
	},
	cyan: {
		50: "#ecfeff",
		100: "#cffafe",
		200: "#a5f3fc",
		300: "#67e8f9",
		400: "#22d3ee",
		500: "#06b6d4",
		600: "#0891b2",
		700: "#0e7490",
		800: "#155e75",
		900: "#164e63",
		950: "#083344"
	},
	sky: {
		50: "#f0f9ff",
		100: "#e0f2fe",
		200: "#bae6fd",
		300: "#7dd3fc",
		400: "#38bdf8",
		500: "#0ea5e9",
		600: "#0284c7",
		700: "#0369a1",
		800: "#075985",
		900: "#0c4a6e",
		950: "#082f49"
	},
	blue: {
		50: "#eff6ff",
		100: "#dbeafe",
		200: "#bfdbfe",
		300: "#93c5fd",
		400: "#60a5fa",
		500: "#3b82f6",
		600: "#2563eb",
		700: "#1d4ed8",
		800: "#1e40af",
		900: "#1e3a8a",
		950: "#172554"
	},
	indigo: {
		50: "#eef2ff",
		100: "#e0e7ff",
		200: "#c7d2fe",
		300: "#a5b4fc",
		400: "#818cf8",
		500: "#6366f1",
		600: "#4f46e5",
		700: "#4338ca",
		800: "#3730a3",
		900: "#312e81",
		950: "#1e1b4b"
	},
	violet: {
		50: "#f5f3ff",
		100: "#ede9fe",
		200: "#ddd6fe",
		300: "#c4b5fd",
		400: "#a78bfa",
		500: "#8b5cf6",
		600: "#7c3aed",
		700: "#6d28d9",
		800: "#5b21b6",
		900: "#4c1d95",
		950: "#2e1065"
	},
	purple: {
		50: "#faf5ff",
		100: "#f3e8ff",
		200: "#e9d5ff",
		300: "#d8b4fe",
		400: "#c084fc",
		500: "#a855f7",
		600: "#9333ea",
		700: "#7e22ce",
		800: "#6b21a8",
		900: "#581c87",
		950: "#3b0764"
	},
	fuchsia: {
		50: "#fdf4ff",
		100: "#fae8ff",
		200: "#f5d0fe",
		300: "#f0abfc",
		400: "#e879f9",
		500: "#d946ef",
		600: "#c026d3",
		700: "#a21caf",
		800: "#86198f",
		900: "#701a75",
		950: "#4a044e"
	},
	pink: {
		50: "#fdf2f8",
		100: "#fce7f3",
		200: "#fbcfe8",
		300: "#f9a8d4",
		400: "#f472b6",
		500: "#ec4899",
		600: "#db2777",
		700: "#be185d",
		800: "#9d174d",
		900: "#831843",
		950: "#500724"
	},
	rose: {
		50: "#fff1f2",
		100: "#ffe4e6",
		200: "#fecdd3",
		300: "#fda4af",
		400: "#fb7185",
		500: "#f43f5e",
		600: "#e11d48",
		700: "#be123c",
		800: "#9f1239",
		900: "#881337",
		950: "#4c0519"
	}
};
N.reduce((e, { color: t, primary: n, secondary: r }) => ({
	...e,
	[t]: {
		primary: pe[t][n],
		secondary: pe[t][r]
	}
}), {});
var me = [
	"label",
	"info",
	"placeholder",
	"description",
	"title",
	"value"
], P = /* @__PURE__ */ "elem_id.elem_classes.visible.interactive.server_fns.server.id.target.theme_mode.version.root.autoscroll.max_file_size.formatter.client.load_component.scale.min_width.theme.padding.loading_status.label.show_label.validation_error.show_progress.api_prefix.container.attached_events.register_component.unregister_component.dispatcher".split(".");
function he(e) {
	return typeof e == "string" && e.includes("__i18n__");
}
var ge = class {
	load_component;
	#e = v(O({}));
	get shared() {
		return n(this.#e);
	}
	set shared(e) {
		E(this.#e, e, !0);
	}
	#t = v(O({}));
	get props() {
		return n(this.#t);
	}
	set props(e) {
		E(this.#t, e, !0);
	}
	#n = v((e) => e);
	get i18n() {
		return n(this.#n);
	}
	set i18n(e) {
		E(this.#n, e, !0);
	}
	i18n_store;
	_i18n_from_store;
	translatable_props = {};
	dispatcher;
	last_update = null;
	shared_props = P;
	mounted = !1;
	old_value;
	register_component;
	unregister_component;
	set_data_callback;
	get_data_callback;
	registered_id = null;
	last_shared_props;
	last_props;
	constructor(e, t) {
		for (let t in e.shared_props) this.shared[t] = e.shared_props[t];
		for (let t in e.props) t !== "i18n_store" && (this.props[t] = e.props[t]);
		if (t) for (let e in t) this.props[e] === void 0 && (this.props[e] = t[e]);
		this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? M(this.i18n_store) : void 0;
		for (let t of me) this.shared[t] = this._translate_and_store("shared", t, e.shared_props[t]), this.props[t] = this._translate_and_store("props", t, e.props[t]);
		this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {}), this.unregister_component = this.shared.unregister_component || (() => {}), this.dispatcher = this.shared.dispatcher || (() => {}), this.set_data_callback = this.set_data.bind(this), this.get_data_callback = this.get_data.bind(this), this.register_component(this.shared.id, this.set_data_callback, this.get_data_callback), this.registered_id = this.shared.id, this.last_shared_props = e.shared_props, this.last_props = e.props, h(() => {
			let t = e.shared_props.id;
			if (this.last_shared_props !== e.shared_props) {
				for (let t in e.shared_props) {
					let n = e.shared_props[t];
					n !== void 0 && (this._is_i18n_managed(`shared.${t}`, n) || (this.shared[t] = n));
				}
				this.last_shared_props = e.shared_props;
			}
			if (this.last_props !== e.props) {
				for (let t in e.props) {
					if (t === "i18n_store") continue;
					let n = e.props[t];
					n !== void 0 && (this._is_i18n_managed(`props.${t}`, n) || (this.props[t] = n));
				}
				this.last_props = e.props;
			}
			this.registered_id !== null && this.registered_id !== t && this.unregister_component(this.registered_id, this.set_data_callback), this.register_component(t, this.set_data_callback, this.get_data_callback), this.registered_id = t, m(() => {
				this.shared.id = t;
			});
		}), h(() => () => {
			this.registered_id !== null && this.unregister_component(this.registered_id, this.set_data_callback);
		}), h(() => {
			if (this.i18n_store) return this.i18n_store.subscribe(() => {
				for (let [e, t] of Object.entries(this.translatable_props)) {
					let [n, r] = e.split("."), i = this.i18n(t);
					n === "shared" ? this.shared[r] = i : this.props[r] = i;
				}
			});
		});
	}
	_is_i18n_managed(e, t) {
		let n = this.translatable_props[e];
		return n ? t === n || (delete this.translatable_props[e], !1) : !1;
	}
	_translate_and_store(e, t, n) {
		if (typeof n != "string") return n;
		let r = this.i18n(n);
		return r !== n && (this.translatable_props[`${e}.${t}`] = n), r;
	}
	live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
	dispatch(e, t) {
		this.dispatcher(this.shared.id, e, t);
	}
	async get_data() {
		return C(this.props);
	}
	update(e) {
		this.set_data(e);
	}
	set_data(e) {
		for (let t in e) {
			let n = e[t], r = he(n) ? this._translate_and_store(this.shared_props.includes(t) ? "shared" : "props", t, n) : n;
			if (this.shared_props.includes(t)) {
				let e = t;
				this.shared[e] = r;
				continue;
			}
			this.props[t] = r;
		}
	}
	watch_for_change() {
		h(() => {
			this.mounted ||= (this.old_value = this.props.value, !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
		});
	}
}, _e = l("<svg class=\"resize-handle svelte-1stq1b1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 10 10\"><line x1=\"1\" y1=\"9\" x2=\"9\" y2=\"1\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line><line x1=\"5\" y1=\"9\" x2=\"9\" y2=\"5\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line></svg>"), F = c("<!> <!>", 1), I = c("<div class=\"placeholder svelte-1stq1b1\"></div>");
function ve(e, r) {
	te(r, !0);
	let i = T(r, "height", 3, void 0), o = T(r, "min_height", 3, void 0), c = T(r, "max_height", 3, void 0), l = T(r, "width", 3, void 0), u = T(r, "elem_id", 3, ""), p = T(r, "elem_classes", 19, () => []), m = T(r, "variant", 3, "solid"), g = T(r, "border_mode", 3, "base"), _ = T(r, "padding", 3, !0), y = T(r, "type", 3, "normal"), x = T(r, "test_id", 3, void 0), S = T(r, "explicit_call", 3, !1), C = T(r, "container", 3, !0), w = T(r, "visible", 3, !0), oe = T(r, "allow_overflow", 3, !0), se = T(r, "overflow_behavior", 3, "auto"), le = T(r, "scale", 3, null), O = T(r, "min_width", 3, 0), k = T(r, "flex", 3, !1), A = T(r, "resizable", 3, !1), M = T(r, "rtl", 3, !1), N = T(r, "fullscreen", 15, !1), pe = T(r, "label", 3, void 0), me = N(), P = v(void 0), he = D(() => y() === "fieldset" ? "fieldset" : "div"), ge = D(() => w() ? k() : !1), ve = v(0), L = v(0), R = v(null), ye = null, z = null, be = null;
	function xe(e) {
		N() && e.key === "Escape" && N(!1);
	}
	function Se(e) {
		let t = e.getRootNode();
		return e.closest(".gradio-container") ?? (t instanceof ShadowRoot ? t : document.body);
	}
	function Ce(e) {
		let t = document.createElement("div");
		t.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; visibility: hidden; pointer-events: none;", e.appendChild(t);
		let n = t.getBoundingClientRect();
		return t.remove(), n;
	}
	function we(e, t) {
		let n = e.parentNode;
		if (!n || n === t) return !1;
		let r = Ce(n), i = Ce(t);
		return Math.abs(r.top - i.top) > 1 || Math.abs(r.left - i.left) > 1 || Math.abs(r.width - i.width) > 1 || Math.abs(r.height - i.height) > 1;
	}
	function Te(e, t) {
		e.parentNode && e.parentNode !== t && (ye = e.parentNode, be = e, z = document.createComment("fullscreen block"), ye.insertBefore(z, e), t.appendChild(e));
	}
	function Ee() {
		if (!ye || !be) return;
		let e = z && z.parentNode === ye ? z : null;
		ye.insertBefore(be, e), e?.remove(), ye = null, z = null, be = null;
	}
	h(() => {
		let e = n(P);
		if (N() !== me && e) {
			if (me = N(), N()) {
				E(R, e.getBoundingClientRect(), !0), E(ve, e.offsetHeight, !0), E(L, e.offsetWidth, !0);
				let t = Se(e);
				we(e, t) && Te(e, t), window.addEventListener("keydown", xe);
			} else Ee(), E(R, null), window.removeEventListener("keydown", xe);
		}
	}), h(() => () => {
		window.removeEventListener("keydown", xe), Ee();
	});
	let De = (e) => {
		if (e !== void 0) {
			if (typeof e == "number") return e + "px";
			if (typeof e == "string") return e;
		}
	}, Oe = (e) => {
		let t = n(P);
		if (!t) return;
		let r = e.clientY, i = (e) => {
			let n = e.clientY - r;
			r = e.clientY, t.style.height = `${t.offsetHeight + n}px`;
		}, a = () => {
			window.removeEventListener("mousemove", i), window.removeEventListener("mouseup", a);
		};
		window.addEventListener("mousemove", i), window.addEventListener("mouseup", a);
	};
	var ke = ie(), Ae = d(ke), je = (e) => {
		var h = F(), v = d(h);
		de(v, () => n(he), !1, (e, s) => {
			ne(e, (e) => E(P, e, !0), () => n(P)), re(e, (e, t, r, i, a) => ({
				"data-testid": x(),
				id: u(),
				class: `block ${e ?? ""}`,
				dir: M() ? "rtl" : "ltr",
				"aria-label": pe(),
				style: "",
				[ce]: {
					hidden: w() === "hidden",
					padded: _(),
					flex: n(ge),
					border_focus: g() === "focus",
					border_contrast: g() === "contrast",
					"hide-container": !S() && !C(),
					fullscreen: N(),
					animating: N() && n(R) !== null,
					"auto-margin": le() === null
				},
				[ae]: {
					height: t,
					"min-height": r,
					"max-height": i,
					"--start-top": n(R) ? `${n(R).top}px` : "0px",
					"--start-left": n(R) ? `${n(R).left}px` : "0px",
					"--start-width": n(R) ? `${n(R).width}px` : "0px",
					"--start-height": n(R) ? `${n(R).height}px` : "0px",
					width: a,
					"border-style": m(),
					overflow: oe() ? se() : "hidden",
					"flex-grow": le(),
					"min-width": `calc(min(${O()}px, 100%))`
				}
			}), [
				() => p()?.join(" ") || "",
				() => N() ? void 0 : De(i()),
				() => N() ? void 0 : De(o()),
				() => N() ? void 0 : De(c()),
				() => N() ? void 0 : typeof l() == "number" ? `calc(min(${l()}px, 100%))` : De(l())
			], void 0, void 0, "svelte-1stq1b1");
			var h = F(), ee = d(h);
			f(ee, () => r.children ?? fe);
			var v = b(ee, 2), y = (e) => {
				var n = _e();
				a("mousedown", n, Oe), t(e, n);
			};
			j(v, (e) => {
				A() && e(y);
			}), t(s, h);
		});
		var y = b(v, 2), te = (e) => {
			var r = I();
			let i;
			s(() => i = ee(r, "", i, {
				height: n(ve) + "px",
				width: n(L) + "px"
			})), t(e, r);
		};
		j(y, (e) => {
			N() && e(te);
		}), t(e, h);
	};
	j(Ae, (e) => {
		(w() === !0 || w() === "hidden") && e(je);
	}), t(e, ke), ue();
}
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/CustomButton.svelte
u(["mousedown"]), u(["click"]), S(), u(["click"]), u(["click"]);
//#endregion
//#region frontend/Timeline.svelte
var L = c("<span class=\"svelte-vjzdoe\"><i class=\"svelte-vjzdoe\"></i> </span>"), R = c("<div class=\"tl svelte-vjzdoe\"><canvas data-testid=\"worldviewer-timeline\" class=\"svelte-vjzdoe\"></canvas> <div class=\"legend svelte-vjzdoe\"><!> <span class=\"svelte-vjzdoe\"><i class=\"hatch svelte-vjzdoe\"></i>autopilot</span> <span class=\"svelte-vjzdoe\"><i class=\"blk svelte-vjzdoe\"></i>block</span></div></div>");
function ye(e, a) {
	te(a, !0);
	let o = T(a, "seconds", 3, 8), c = [
		{
			axis: "forward",
			color: "#f97316",
			pos: "W",
			neg: "S"
		},
		{
			axis: "right",
			color: "#22d3ee",
			pos: "D",
			neg: "A"
		},
		{
			axis: "yaw",
			color: "#a78bfa",
			pos: "E",
			neg: "Q"
		},
		{
			axis: "pitch",
			color: "#4ade80",
			pos: "R",
			neg: "F"
		},
		{
			axis: "up",
			color: "#facc15",
			pos: "␣",
			neg: "⇧"
		}
	], l = new Map(c.map((e, t) => [e.axis, t])), u = v(void 0), d = v(void 0), f = 0, p = null, m = 600, h = 148, y = 1, x = null, S = c.length * 10 - 2, re = 10 + S + 10, C = re + 22 + 4, w = C + S + 8;
	function ie() {
		n(u) && n(d) && (y = Math.min(2, window.devicePixelRatio || 1), m = Math.max(200, n(u).clientWidth), h = w + 16, n(d).width = Math.round(m * y), n(d).height = Math.round(h * y), n(d).style.height = `${h}px`, x = null);
	}
	function ae(e) {
		let t = document.createElement("canvas");
		t.width = t.height = 8 * y;
		let n = t.getContext("2d");
		return n.strokeStyle = "rgba(255,255,255,0.28)", n.lineWidth = 1.5 * y, n.beginPath(), n.moveTo(0, 8 * y), n.lineTo(8 * y, 0), n.stroke(), e.createPattern(t, "repeat");
	}
	function se(e, t) {
		let n = 0;
		for (; n < e.length;) {
			let r = e[n];
			if ((typeof r == "number" ? r : r.t1 ?? Infinity) >= t) break;
			n++;
		}
		n > 0 && e.splice(0, n);
	}
	function ce(e, t, n, r, i) {
		for (let a of t) {
			let t = a.t1 == null ? r : Math.min(a.t1, r);
			if (t <= a.t0) continue;
			let o = Math.max(58, i(a.t0)), s = i(t);
			if (s <= 58) continue;
			let u = Math.max(1.5, s - o);
			if (a.axis === "auto") {
				x ||= ae(e), e.fillStyle = "rgba(255,255,255,0.05)", e.fillRect(o, n, u, S), x && (e.fillStyle = x, e.fillRect(o, n, u, S)), u > 60 && (e.fillStyle = "rgba(255,255,255,0.6)", e.font = "600 9px ui-sans-serif, system-ui, sans-serif", e.fillText("autopilot", o + 5, n + S / 2 + 3));
				continue;
			}
			let d = l.get(a.axis) ?? 0, f = c[d], p = n + d * 10;
			e.globalAlpha = .35 + .65 * Math.min(1, Math.abs(a.val)), a.val > 0 ? (e.fillStyle = f.color, e.fillRect(o, p, u, 8)) : (e.fillStyle = f.color + "40", e.fillRect(o, p, u, 8), e.strokeStyle = f.color, e.lineWidth = 1, e.strokeRect(o + .5, p + .5, u - 1, 7)), e.globalAlpha = 1, u > 11 && (e.fillStyle = a.val > 0 ? "rgba(0,0,0,0.75)" : f.color, e.font = "700 7.5px ui-monospace, monospace", e.fillText(a.val > 0 ? f.pos : f.neg, o + 2.5, p + 8 - 1.3));
		}
	}
	function D() {
		if (f = requestAnimationFrame(D), !n(d)) return;
		let e = n(d).getContext("2d");
		if (!e) return;
		let t = performance.now(), r = o() * 1e3, i = m - 58 - 8, s = (e) => 58 + i - (t - e) / r * i, c = t - r - 500;
		se(a.store.you, c), se(a.store.played, c), se(a.store.ticks, c), se(a.store.blocks, c), e.setTransform(y, 0, 0, y, 0, 0), e.clearRect(0, 0, m, h), e.font = "600 10px ui-sans-serif, system-ui, sans-serif";
		for (let [t, n] of [[10, "You"], [C, "Played"]]) e.fillStyle = "rgba(255,255,255,0.035)", e.fillRect(58, t - 2, i, S + 4), e.fillStyle = "rgba(244,245,247,0.75)", e.fillText(n, 8, t + S / 2 + 4);
		e.strokeStyle = "rgba(255,255,255,0.06)", e.fillStyle = "rgba(244,245,247,0.38)", e.font = "9px ui-monospace, monospace", e.lineWidth = 1;
		let l = Math.ceil((t - r) / 1e3);
		for (let n = l; n <= Math.floor(t / 1e3); n++) {
			let t = Math.round(s(n * 1e3)) + .5;
			t < 58 || (e.beginPath(), e.moveTo(t, 8), e.lineTo(t, C + S + 2), e.stroke());
		}
		for (let t = 0; t <= o(); t += 2) {
			let n = 58 + i - t / o() * i;
			e.fillText(t === 0 ? "now" : `-${t}s`, n - (t === 0 ? 16 : 8), w + 8);
		}
		e.strokeStyle = "rgba(255,255,255,0.28)", e.setLineDash([2, 2]);
		for (let t of a.store.blocks) {
			let n = Math.round(s(t)) + .5;
			n < 58 || (e.beginPath(), e.moveTo(n, C - 4), e.lineTo(n, C + S + 4), e.stroke());
		}
		e.setLineDash([]), ce(e, a.store.you, 10, t, s), ce(e, a.store.played, C, t, s), e.fillStyle = "rgba(244,245,247,0.45)";
		for (let t of a.store.ticks) {
			let n = s(t);
			n < 58 || e.fillRect(n - .5, 10 + S + 3, 1, 4);
		}
		let u = a.store.latency_ms;
		if (u != null && Number.isFinite(u)) {
			let n = s(t), r = Math.max(58, s(t - u)), i = re + 11 + 1;
			e.strokeStyle = "rgba(244,245,247,0.55)", e.beginPath(), e.moveTo(r, i), e.lineTo(n, i), e.moveTo(r + .5, i - 4), e.lineTo(r + .5, i + 4), e.moveTo(n - .5, i - 4), e.lineTo(n - .5, i + 4), e.stroke();
			let a = `latency ${(u / 1e3).toFixed(2)} s`;
			e.font = "600 10px ui-sans-serif, system-ui, sans-serif";
			let o = e.measureText(a).width, c = Math.min(Math.max((r + n) / 2 - o / 2, 60), n - o - 2);
			e.fillStyle = "#11141b", e.fillRect(c - 5, i - 8, o + 10, 15), e.fillStyle = "#f4f5f7", e.fillText(a, c, i + 3.5);
		}
		e.strokeStyle = "rgba(249,115,22,0.8)", e.beginPath(), e.moveTo(s(t) - .5, 6), e.lineTo(s(t) - .5, C + S + 4), e.stroke();
	}
	oe(() => {
		p = new ResizeObserver(ie), n(u) && p.observe(n(u)), ie(), f = requestAnimationFrame(D);
	}), le(() => {
		cancelAnimationFrame(f), p?.disconnect();
	});
	var O = R(), k = g(O);
	ne(k, (e) => E(d, e), () => n(d));
	var j = b(k, 2), de = g(j);
	r(de, 17, () => c, (e) => e.axis, (e, r) => {
		var a = L(), o = g(a);
		let c;
		var l = b(o);
		A(a), s(() => {
			c = ee(o, "", c, { background: n(r).color }), i(l, `${n(r).pos ?? ""}/${n(r).neg ?? ""} ${n(r).axis ?? ""}`);
		}), t(e, a);
	}), _(4), A(j), A(O), ne(O, (e) => E(u, e), () => n(u)), t(e, O), ue();
}
//#endregion
//#region frontend/Index.svelte
var z = (e, n = fe, r = fe) => {
	var i = xe();
	s(() => {
		k(i, 1, `info ${r() ?? ""}`, "svelte-r41nsf"), x(i, "aria-label", n()), x(i, "data-tip", n());
	}), t(e, i);
}, be = /* @__PURE__ */ new Set([
	"$$slots",
	"$$events",
	"$$legacy"
]), xe = c("<span tabindex=\"0\" role=\"note\">i</span>"), Se = c("<div class=\"poster svelte-r41nsf\"><div class=\"poster-grid svelte-r41nsf\"></div></div>"), Ce = c("<span class=\"msg svelte-r41nsf\"> </span>"), we = c("<span class=\"svelte-r41nsf\"><span class=\"k svelte-r41nsf\">gen</span> </span>"), Te = c("<span class=\"lat svelte-r41nsf\"><span class=\"k svelte-r41nsf\">latency</span> </span>"), Ee = l("<svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"svelte-r41nsf\"><path d=\"M8 3v3a2 2 0 0 1-2 2H3M21 8h-3a2 2 0 0 1-2-2V3M3 16h3a2 2 0 0 1 2 2v3M16 21v-3a2 2 0 0 1 2-2h3\" class=\"svelte-r41nsf\"></path></svg>"), De = l("<svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"svelte-r41nsf\"><path d=\"M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3\" class=\"svelte-r41nsf\"></path></svg>"), Oe = c("<div class=\"overlay dim svelte-r41nsf\"><div class=\"spinner svelte-r41nsf\" aria-hidden=\"true\"></div> <div class=\"ov-text svelte-r41nsf\"> </div></div>"), ke = c("<div class=\"overlay error svelte-r41nsf\"><div class=\"ov-title svelte-r41nsf\">Error</div> <div class=\"ov-text svelte-r41nsf\"> </div> <button class=\"btn primary small svelte-r41nsf\">Try again</button></div>"), Ae = c("<div class=\"ov-text svelte-r41nsf\"> </div>"), je = c("<div class=\"overlay dim svelte-r41nsf\"><div class=\"ov-title svelte-r41nsf\">Session ended</div> <!> <button class=\"btn primary small svelte-r41nsf\"><svg viewBox=\"0 0 24 24\" width=\"14\" height=\"14\" fill=\"currentColor\" class=\"svelte-r41nsf\"><path d=\"M8 5v14l11-7z\" class=\"svelte-r41nsf\"></path></svg> Start again</button></div>"), Me = c("<div><button class=\"big-play svelte-r41nsf\" aria-label=\"Start\"><svg viewBox=\"0 0 24 24\" width=\"30\" height=\"30\" fill=\"currentColor\" class=\"svelte-r41nsf\"><path d=\"M8 5v14l11-7z\" class=\"svelte-r41nsf\"></path></svg></button> <div class=\"ov-text svelte-r41nsf\"> </div></div>"), Ne = c("<div class=\"chip buffering glass svelte-r41nsf\"><span class=\"mini-spin svelte-r41nsf\"></span>buffering</div>"), Pe = c("<div class=\"chip hint glass svelte-r41nsf\">Click here to control</div>"), Fe = c("<div class=\"session-bar svelte-r41nsf\"><div class=\"fill svelte-r41nsf\"></div></div>"), Ie = c("<span class=\"time mono svelte-r41nsf\"> </span>"), Le = c("<div class=\"empty svelte-r41nsf\">No render condition yet</div>"), Re = c("<span class=\"sub svelte-r41nsf\"> </span>"), ze = c("<button class=\"mini svelte-r41nsf\" title=\"Re-frame the scene\">Reset view</button>"), Be = c("<div class=\"empty svelte-r41nsf\">3D view unavailable</div>"), Ve = c("<span class=\"lat-badge mono svelte-r41nsf\"> </span>"), He = c("<section class=\"panel tl-panel svelte-r41nsf\"><header class=\"svelte-r41nsf\"><span class=\"title svelte-r41nsf\">Timeline</span> <!> <span class=\"sub svelte-r41nsf\">your input vs. what is on screen</span> <span class=\"grow svelte-r41nsf\"></span> <!></header> <!></section>"), Ue = c("<div><div class=\"grid svelte-r41nsf\"><div class=\"main svelte-r41nsf\"><div tabindex=\"0\" role=\"application\" aria-label=\"World viewer. Click, then use W A S D, arrows, Q E, R F, Space and Shift to move the camera. Enter starts, Escape stops.\" data-testid=\"worldviewer-stage\"><canvas data-testid=\"worldviewer-canvas\"></canvas> <!> <div aria-live=\"polite\" data-testid=\"worldviewer-hud\"><div class=\"hud-row status-row svelte-r41nsf\"><span></span> <span class=\"status-name svelte-r41nsf\"> </span> <!></div> <div class=\"hud-row mono svelte-r41nsf\"><span class=\"svelte-r41nsf\"><span class=\"k svelte-r41nsf\">play</span> </span> <!> <span class=\"svelte-r41nsf\"><span class=\"k svelte-r41nsf\">buf</span> </span> <!></div></div> <div class=\"tools svelte-r41nsf\"><button class=\"icon-btn glass svelte-r41nsf\" aria-label=\"Toggle fullscreen\"><!></button></div> <!> <!> <!> <!></div> <div class=\"toolbar svelte-r41nsf\"><div class=\"left svelte-r41nsf\"><button class=\"btn primary svelte-r41nsf\" data-testid=\"worldviewer-start\"><svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"svelte-r41nsf\"><path d=\"M8 5v14l11-7z\" class=\"svelte-r41nsf\"></path></svg> Start</button> <button class=\"btn stop svelte-r41nsf\" data-testid=\"worldviewer-stop\"><svg viewBox=\"0 0 24 24\" width=\"14\" height=\"14\" fill=\"currentColor\" class=\"svelte-r41nsf\"><rect x=\"6\" y=\"6\" width=\"12\" height=\"12\" rx=\"2\" class=\"svelte-r41nsf\"></rect></svg> Stop</button> <!></div> <div class=\"hints svelte-r41nsf\" aria-hidden=\"true\"><span class=\"svelte-r41nsf\"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> move</span> <span class=\"svelte-r41nsf\"><kbd>Q</kbd><kbd>E</kbd>/<kbd class=\"svelte-r41nsf\">←</kbd><kbd class=\"svelte-r41nsf\">→</kbd> turn</span> <span class=\"svelte-r41nsf\"><kbd>R</kbd><kbd>F</kbd> look</span> <span class=\"svelte-r41nsf\"><kbd>Space</kbd><kbd>⇧</kbd> up/down</span> <span class=\"svelte-r41nsf\"><kbd class=\"svelte-r41nsf\">↵</kbd> start <kbd class=\"svelte-r41nsf\">Esc</kbd> stop</span></div></div></div> <div class=\"side svelte-r41nsf\"><section><header class=\"svelte-r41nsf\"><span class=\"title svelte-r41nsf\">What the model sees</span> <!> <span class=\"grow svelte-r41nsf\"></span> <button class=\"mini svelte-r41nsf\" data-testid=\"worldviewer-cond-toggle\"> </button></header> <div><div class=\"cond-wrap svelte-r41nsf\"><canvas data-testid=\"worldviewer-cond\"></canvas> <!></div> <div class=\"caption svelte-r41nsf\">Point cloud splatted into your camera — black holes are what the model imagines</div></div></section> <section><header class=\"svelte-r41nsf\"><span class=\"title svelte-r41nsf\">Camera</span> <!> <!> <span class=\"grow svelte-r41nsf\"></span> <!> <button class=\"mini svelte-r41nsf\"> </button></header> <div><!> <div class=\"cam-legend svelte-r41nsf\"><span class=\"svelte-r41nsf\"><i class=\"sw src svelte-r41nsf\"></i>source</span> <span class=\"svelte-r41nsf\"><i class=\"sw played svelte-r41nsf\"></i>played</span> <span class=\"svelte-r41nsf\"><i class=\"sw buf svelte-r41nsf\"></i>buffered</span></div></div></section></div></div> <!></div>");
function We(r, c) {
	te(c, !0);
	let l = new ge(w(c, be));
	l.watch_for_change();
	let u = [
		"forward",
		"right",
		"yaw",
		"pitch",
		"up"
	], f = D(() => Math.max(1, l.props.prebuffer_frames ?? 8)), S = D(() => l.props.catchup_rate ?? 1.15), re = D(() => l.props.heartbeat_ms ?? 250), C = D(() => 1e3 / Math.max(1, l.props.max_control_hz ?? 20)), ae = D(() => l.props.timeline_seconds ?? 8), ce = D(() => l.props.show_timeline ?? !0), T = D(() => l.props.placeholder ?? "Press Start, then click here and use WASD / arrows to move"), de = v(void 0), fe = v(void 0), M = v(void 0), N = v(void 0), pe = v(0), me = import("./CameraView-C2uTDLxu.js"), P = v(null), he = v(!1), _e = v(!1), F = v(O(m(() => l.props.show_render ?? !0))), I = v(O(m(() => l.props.show_camera ?? !0))), L = v(!1), R = v(!1), xe = v(!1), We = v(0), Ge = v(0), B = v(null), Ke = v(O(m(() => l.props.aspect_ratio || 832 / 480))), qe = v(O(performance.now())), Je = v(O(performance.now())), Ye = v(""), Xe = D(() => l.props.value ?? null), Ze = D(() => n(Xe)?.status ?? "idle"), Qe = D(() => l.shared.loading_status), $e = D(() => n(Qe)?.status === "error" && (n(P) === "start" || n(Ze) === "loading" || n(Ze) === "running")), V = D(() => n($e) ? "error" : n(P) === "start" ? "loading" : n(P) === "stop" ? "ended" : n(Ze)), H = D(() => n($e) ? n(Qe)?.message || n(Xe)?.message || "Something went wrong" : n(P) === "start" ? ot() || "Starting…" : n(P) === "stop" ? "Stopped" : n(Xe)?.message ?? ""), et = D(() => n(V) === "running" || n(V) === "loading"), tt = D(() => !n(et)), nt = D(() => n(et)), U = D(() => n(Xe)?.stats ?? {}), rt = D(() => typeof n(U).gen_fps == "number" ? n(U).gen_fps : null), it = D(() => typeof n(U).limit_s == "number" ? n(U).limit_s : null), at = D(() => {
		let e = typeof n(U).elapsed_s == "number" ? n(U).elapsed_s : 0, t = n(Ze) === "running" ? (n(qe) - n(Je)) / 1e3 : 0;
		return n(it) ? Math.min(n(it), e + t) : e + t;
	});
	function ot() {
		let e = l.shared.loading_status;
		return e?.status === "pending" && e.queue_position != null && e.queue_position > 0 ? `Waiting in queue (position ${e.queue_position + 1}${e.queue_size ? ` / ${e.queue_size}` : ""})…` : "";
	}
	let st = {
		you: [],
		played: [],
		ticks: [],
		blocks: [],
		latency_ms: null
	}, W = {
		scene: null,
		scene_version: 0,
		poses: [],
		played: 0,
		version: 0
	}, ct = "", G = [], lt = 0, ut = Promise.resolve(), dt = null, ft = /* @__PURE__ */ new Set(), pt = -1, mt = 12, ht = !1, gt = 0, _t = 0, K = null, q = [], vt = 0, yt = 0, J = null, Y = /* @__PURE__ */ new Map(), X = [];
	function Z(e) {
		e && ("close" in e.bm && e.bm.close(), e.rb && "close" in e.rb && e.rb.close());
	}
	function bt(e) {
		lt++;
		for (let e of G) Z(e);
		G = [], ft = /* @__PURE__ */ new Set(), pt = -1, dt = e, ht = !1, _t = 0, q = [], E(We, 0), J = null, st.latency_ms = null, E(B, null), Dt(performance.now()), W.poses = [], W.played = 0, W.version++;
	}
	function xt(e) {
		let t = e.indexOf(","), n = e.slice(5, t).split(";")[0] || "image/jpeg", r = atob(e.slice(t + 1)), i = new Uint8Array(r.length);
		for (let e = 0; e < r.length; e++) i[e] = r.charCodeAt(e);
		return new Blob([i], { type: n });
	}
	async function St(e) {
		if (typeof createImageBitmap == "function" && e.startsWith("data:")) return await createImageBitmap(xt(e));
		let t = new Image();
		return t.decoding = "async", t.src = e, await t.decode(), t;
	}
	function Ct(e) {
		return e ? {
			forward: +(e.forward ?? 0),
			right: +(e.right ?? 0),
			up: +(e.up ?? 0),
			yaw: +(e.yaw ?? 0),
			pitch: +(e.pitch ?? 0)
		} : null;
	}
	function wt(e) {
		let t = lt, n = e.fps > 0 ? e.fps : 15, r = Promise.all(e.frames.map(St)), i = e.renders?.length ? Promise.all(e.renders.map((e) => St(e).catch(() => null))) : Promise.resolve(null);
		ut = ut.then(async () => {
			let a, o;
			try {
				[a, o] = await Promise.all([r, i]);
			} catch (t) {
				console.warn("[WorldViewer] failed to decode chunk", e.id, t);
				return;
			}
			if (t !== lt) {
				a.forEach((e) => Z({
					bm: e,
					rb: null
				})), o?.forEach((e) => e && Z({
					bm: e,
					rb: null
				}));
				return;
			}
			let s = Array.isArray(e.actions), c = a.map((t, r) => {
				let i = e.poses?.[r], a = -1;
				return Array.isArray(i) && i.length >= 12 && (W.poses.push(i), a = W.poses.length - 1), {
					bm: t,
					rb: o?.[r] ?? null,
					fps: n,
					action: s ? Ct(e.actions[r]) : null,
					has_action: s,
					seq: e.control_seqs?.[r] ?? null,
					pose: i ?? null,
					chunk_id: e.id,
					first_in_chunk: r === 0,
					pose_index: a
				};
			});
			e.poses?.length && W.version++, o && o.some(Boolean) && E(R, !0), mt = Math.max(1, c.length), G.push(...c), E(We, G.length, !0);
		});
	}
	function Tt(e) {
		let t = e.scene;
		if (!t || !t.points) return;
		let n = `${t.title}|${t.points.length}|${t.points.slice(0, 64)}|${t.points.slice(-64)}|${t.source_poses?.length}`;
		n !== ct && (ct = n, W.scene = t, W.scene_version++, E(Ye, t.title || "", !0));
	}
	function Et(e) {
		if (!e) return;
		(n(P) === "start" || n(P) === "stop" && e.status !== "running" && e.status !== "loading") && E(P, null), E(Je, performance.now(), !0), Tt(e);
		let t = e.chunk;
		if (t && Array.isArray(t.frames) && t.frames.length !== 0) {
			if (t.session !== dt) bt(t.session);
			else if (t.id === 0 && pt > 0) bt(t.session);
			else if (ft.has(t.id)) return;
			ft.add(t.id), pt = Math.max(pt, t.id), wt(t);
		}
	}
	h(() => {
		let e = l.props.value;
		m(() => Et(e));
	});
	function Dt(e) {
		for (let t of X) (t.t1 == null || t.t1 > e) && (t.t1 = e);
		X = [];
	}
	function Ot(e, t) {
		let n = 1e3 / (e.fps || 15), r = t + n;
		e.first_in_chunk && st.blocks.push(t);
		let i = [];
		if (e.has_action && !e.action) i.push({
			axis: "auto",
			val: 1
		});
		else if (e.action) for (let t of u) e.action[t] !== 0 && i.push({
			axis: t,
			val: e.action[t]
		});
		let a = [];
		for (let e of i) {
			let i = X.find((r) => r.axis === e.axis && r.val === e.val && r.t1 != null && r.t1 >= t - n * 1.5);
			if (i) i.t1 = r, a.push(i);
			else {
				let n = {
					axis: e.axis,
					val: e.val,
					t0: t,
					t1: r
				};
				st.played.push(n), a.push(n);
			}
		}
		for (let e of X) !a.includes(e) && e.t1 != null && e.t1 > t && (e.t1 = t);
		X = a;
	}
	function kt(e, t) {
		if (!n(M)) return;
		let r = e.bm.width, i = e.bm.height;
		r && i && (n(M).width !== r || n(M).height !== i) && (n(M).width = r, n(M).height = i, E(Ke, r / i)), n(M).getContext("2d")?.drawImage(e.bm, 0, 0, n(M).width, n(M).height), At(e);
		let a = K;
		if (K = e, a && a !== e && Z(a), n(L) || E(L, !0), e.seq != null && Y.has(e.seq)) {
			let n = t - Y.get(e.seq);
			J = J == null ? n : J * .85 + n * .15, st.latency_ms = J;
		}
		Ot(e, t), e.pose_index >= 0 && (W.played = e.pose_index + 1, W.version++);
	}
	function At(e) {
		if (!e?.rb || !n(N)) return;
		let t = e.rb.width, r = e.rb.height;
		t && r && (n(N).width !== t || n(N).height !== r) && (n(N).width = t, n(N).height = r), n(N).getContext("2d")?.drawImage(e.rb, 0, 0, n(N).width, n(N).height);
	}
	function jt() {
		K && n(M) && (n(M).getContext("2d")?.drawImage(K.bm, 0, 0, n(M).width, n(M).height), At(K));
	}
	function Mt(e) {
		vt = requestAnimationFrame(Mt);
		let t = gt ? Math.min(e - gt, 250) : 0;
		gt = e;
		let r = n(Ze) === "running" || n(Ze) === "loading";
		if (ht || (G.length >= n(f) || G.length > 0 && !r) && (ht = !0, _t = 1e3 / (G[0]?.fps || 15)), ht) {
			if (G.length === 0) ht = !1, Dt(e);
			else {
				let r = G.length, i = r > 4 * mt ? n(S) * n(S) : r > 2 * mt ? n(S) : 1;
				_t += t * i;
				let a = 1e3 / (G[0].fps || 15);
				_t >= a && (_t = Math.min(_t - a, a), kt(G.shift(), e), q.push(e), q.length > 30 && q.shift());
			}
		}
		if (e - yt > 120) {
			yt = e;
			let t = r && !ht && n(L);
			t !== n(xe) && E(xe, t, !0), n(We) !== G.length && E(We, G.length, !0);
			let i = 0;
			q.length > 2 && e - q[q.length - 1] < 1e3 && (i = (q.length - 1) * 1e3 / (q[q.length - 1] - q[0])), Math.abs(i - n(Ge)) > .05 && E(Ge, i, !0);
			let a = J;
			a !== n(B) && (a == null || n(B) == null || Math.abs(a - n(B)) > 15) && E(B, a, !0), E(qe, performance.now(), !0);
			for (let [t, n] of Y) e - n > 6e4 && Y.delete(t);
		}
	}
	let Nt = {
		KeyW: "fwd",
		ArrowUp: "fwd",
		KeyS: "back",
		ArrowDown: "back",
		KeyA: "left",
		KeyD: "right",
		KeyQ: "yawL",
		ArrowLeft: "yawL",
		KeyE: "yawR",
		ArrowRight: "yawR",
		KeyR: "pitchU",
		KeyF: "pitchD",
		Space: "up",
		ShiftLeft: "down",
		ShiftRight: "down"
	}, Q = v(O({})), $ = D(() => new Set(Object.values(n(Q))));
	function Pt(e) {
		let t = (t, n) => +!!e.has(t) - !!e.has(n);
		return {
			forward: t("fwd", "back"),
			right: t("right", "left"),
			up: t("up", "down"),
			yaw: t("yawR", "yawL"),
			pitch: t("pitchU", "pitchD")
		};
	}
	let Ft = {};
	function It(e) {
		let t = performance.now();
		for (let n of u) {
			let r = Ft[n];
			if (!(r && r.val === e[n]) && (r && (r.t1 = t, delete Ft[n]), e[n] !== 0)) {
				let r = {
					axis: n,
					val: e[n],
					t0: t,
					t1: null
				};
				st.you.push(r), Ft[n] = r;
			}
		}
	}
	let Lt = 0, Rt = "", zt = 0, Bt = null;
	function Vt(e = !1) {
		let t = Pt(n($)), r = `${t.forward},${t.right},${t.up},${t.yaw},${t.pitch}`;
		if (!e && r === Rt) return;
		let i = performance.now(), a = zt + n(C) - i;
		if (a > 0) {
			Bt ||= setTimeout(() => {
				Bt = null, Vt(!0);
			}, a);
			return;
		}
		Rt = r, zt = i;
		let o = {
			...t,
			seq: ++Lt,
			session: dt ?? ""
		};
		Y.set(o.seq, i), st.ticks.push(i), l.dispatch("control", o);
	}
	h(() => {
		let e = n($);
		m(() => {
			It(Pt(e)), Vt(!1);
		});
	}), h(() => {
		if (!n(et)) return;
		let e = setInterval(() => Vt(!0), n(re));
		return () => clearInterval(e);
	});
	function Ht() {
		n(tt) && (E(P, "start"), E(Je, performance.now(), !0), l.dispatch("start", {}), n(fe)?.focus({ preventScroll: !0 }));
	}
	function Ut() {
		n(nt) && (E(P, "stop"), l.dispatch("stop", {}));
	}
	function Wt(e) {
		if (e.ctrlKey || e.metaKey || e.altKey) return;
		if (e.code === "Enter" || e.code === "NumpadEnter") {
			e.preventDefault(), Ht();
			return;
		}
		if (e.code === "Escape") {
			e.preventDefault(), Ut();
			return;
		}
		let t = Nt[e.code];
		t && (e.preventDefault(), n(Q)[e.code] !== t && (n(Q)[e.code] = t));
	}
	function Gt(e) {
		Nt[e.code] && (e.preventDefault(), delete n(Q)[e.code]);
	}
	function Kt() {
		Object.keys(n(Q)).length && E(Q, {}, !0);
	}
	function qt() {
		E(he, !1), Kt();
	}
	async function Jt() {
		try {
			document.fullscreenElement ? await document.exitFullscreen() : await n(de)?.requestFullscreen();
		} catch (e) {
			console.warn("[WorldViewer] fullscreen failed", e);
		}
	}
	function Yt() {
		document.hidden && Kt();
	}
	function Xt() {
		E(_e, document.fullscreenElement === n(de)), requestAnimationFrame(jt);
	}
	oe(() => {
		vt = requestAnimationFrame(Mt), document.addEventListener("fullscreenchange", Xt), document.addEventListener("visibilitychange", Yt), window.addEventListener("blur", Kt);
	}), le(() => {
		cancelAnimationFrame(vt), Bt && clearTimeout(Bt), document.removeEventListener("fullscreenchange", Xt), document.removeEventListener("visibilitychange", Yt), window.removeEventListener("blur", Kt), bt(null), Z(K);
	}), ve(r, {
		get visible() {
			return l.shared.visible;
		},
		get elem_id() {
			return l.shared.elem_id;
		},
		get elem_classes() {
			return l.shared.elem_classes;
		},
		get container() {
			return l.shared.container;
		},
		get scale() {
			return l.shared.scale;
		},
		get min_width() {
			return l.shared.min_width;
		},
		padding: !1,
		allow_overflow: !0,
		children: (r, c) => {
			var l = Ue();
			let u;
			var f = g(l), m = g(f), h = g(m);
			let v, te;
			var S = g(h);
			let re;
			ne(S, (e) => E(M, e), () => n(M));
			var C = b(S, 2), w = (e) => {
				var n = Se();
				t(e, n);
			};
			j(C, (e) => {
				n(L) || e(w);
			});
			var oe = b(C, 2);
			let D;
			var le = g(oe), O = g(le), ue = b(O, 2), P = e(ue, !0), ge = b(ue, 2), ve = (r) => {
				var a = Ce(), o = e(a, !0);
				s(() => {
					x(a, "title", n(H)), i(o, n(H));
				}), t(r, a);
			};
			j(ge, (e) => {
				n(H) && n(V) !== "loading" && n(V) !== "error" && e(ve);
			}), A(le);
			var be = b(le, 2), qe = g(be), Je = b(g(qe));
			A(qe);
			var Xe = b(qe, 2), Ze = (e) => {
				var r = we(), a = b(g(r));
				A(r), s((e) => i(a, ` ${e ?? ""} fps`), [() => n(rt).toFixed(1)]), t(e, r);
			};
			j(Xe, (e) => {
				n(rt) != null && e(Ze);
			});
			var Qe = b(Xe, 2), $e = b(g(Qe));
			A(Qe);
			var et = b(Qe, 2), U = (e) => {
				var r = Te(), a = b(g(r));
				A(r), s((e) => i(a, ` ${e ?? ""} s`), [() => (n(B) / 1e3).toFixed(2)]), t(e, r);
			};
			j(et, (e) => {
				n(B) != null && e(U);
			}), A(be), A(oe);
			var ot = b(oe, 2), ct = g(ot), G = g(ct), lt = (e) => {
				var n = Ee();
				t(e, n);
			}, ut = (e) => {
				var n = De();
				t(e, n);
			};
			j(G, (e) => {
				n(_e) ? e(lt) : e(ut, -1);
			}), A(ct), A(ot);
			var dt = b(ot, 2), ft = (r) => {
				var a = Oe(), o = b(g(a), 2), c = e(o, !0);
				A(a), s(() => i(c, n(H) || "Loading…")), t(r, a);
			}, pt = (r) => {
				var o = ke(), c = b(g(o), 2), l = e(c, !0), u = b(c, 2);
				A(o), s(() => i(l, n(H))), a("click", u, Ht), t(r, o);
			}, mt = (r) => {
				var o = je(), c = b(g(o), 2), l = (r) => {
					var a = Ae(), o = e(a, !0);
					s(() => i(o, n(H))), t(r, a);
				};
				j(c, (e) => {
					n(H) && e(l);
				});
				var u = b(c, 2);
				A(o), a("click", u, Ht), t(r, o);
			}, ht = (r) => {
				var o = Me();
				let c;
				var l = g(o), u = b(l, 2), d = e(u, !0);
				A(o), s(() => {
					c = k(o, 1, "overlay svelte-r41nsf", null, c, { dim: n(L) }), i(d, n(H) || n(T));
				}), a("click", l, Ht), t(r, o);
			};
			j(dt, (e) => {
				n(V) === "loading" ? e(ft) : n(V) === "error" ? e(pt, 1) : n(V) === "ended" && n(We) === 0 ? e(mt, 2) : n(V) === "idle" && e(ht, 3);
			});
			var gt = b(dt, 2), _t = (e) => {
				var n = Ne();
				t(e, n);
			};
			j(gt, (e) => {
				n(xe) && n(V) === "running" && e(_t);
			});
			var K = b(gt, 2), q = (e) => {
				var n = Pe();
				t(e, n);
			};
			j(K, (e) => {
				n(V) === "running" && !n(he) && e(q);
			});
			var vt = b(K, 2), yt = (e) => {
				var r = Fe(), i = g(r);
				let a;
				A(r), s((e, t, n) => {
					x(r, "title", `Session time ${e ?? ""}s / ${t ?? ""}s`), a = ee(i, "", a, { width: n });
				}, [
					() => n(at).toFixed(0),
					() => n(it).toFixed(0),
					() => `${Math.min(100, 100 * n(at) / n(it))}%`
				]), t(e, r);
			};
			j(vt, (e) => {
				n(it) && e(yt);
			}), A(h), ne(h, (e) => E(fe, e), () => n(fe));
			var J = b(h, 2), Y = g(J), X = g(Y), Z = b(X, 2), bt = b(Z, 2), xt = (r) => {
				var a = Ie(), o = e(a);
				s((e, t) => i(o, `${e ?? ""}s / ${t ?? ""}s`), [() => n(at).toFixed(0), () => n(it).toFixed(0)]), t(r, a);
			};
			j(bt, (e) => {
				n(it) && e(xt);
			}), A(Y);
			var St = b(Y, 2), Ct = g(St), wt = g(Ct);
			let Tt;
			var Et = b(wt);
			let Dt;
			var Ot = b(Et);
			let kt;
			var At = b(Ot);
			let Mt;
			_(), A(Ct);
			var Nt = b(Ct, 2), Q = g(Nt);
			let Pt;
			var Ft = b(Q);
			let It;
			_(4), A(Nt);
			var Lt = b(Nt, 2), Rt = g(Lt);
			let zt;
			var Bt = b(Rt);
			let Vt;
			_(), A(Lt);
			var Kt = b(Lt, 2), Yt = g(Kt);
			let Xt;
			var Zt = b(Yt);
			let Qt;
			_(), A(Kt), _(2), A(St), A(J), A(m);
			var $t = b(m, 2), en = g($t);
			let tn;
			var nn = g(en), rn = b(g(nn), 2);
			z(rn, () => "The render condition: the scene's point cloud (from depth) splatted into the camera you are steering, for the frame being played. Black holes are regions no source pixel covers — the model has to imagine them.", () => "right");
			var an = b(rn, 4), on = e(an, !0);
			A(nn);
			var sn = b(nn, 2);
			let cn;
			var ln = g(sn);
			let un;
			var dn = g(ln);
			let fn;
			ne(dn, (e) => E(N, e), () => n(N));
			var pn = b(dn, 2), mn = (e) => {
				var n = Le();
				t(e, n);
			};
			j(pn, (e) => {
				n(R) || e(mn);
			}), A(ln), _(2), A(sn), A(en);
			var hn = b(en, 2);
			let gn;
			var _n = g(hn), vn = b(g(_n), 2);
			z(vn, () => "3D view of the scene point cloud (in the source camera's world frame), the source camera(s) in grey, and the generated camera path: solid = already played, faint = generated but still buffered, highlighted frustum = current frame. Drag to orbit, scroll to zoom.", () => "right");
			var yn = b(vn, 2), bn = (r) => {
				var a = Re(), o = e(a, !0);
				s(() => {
					x(a, "title", n(Ye)), i(o, n(Ye));
				}), t(r, a);
			};
			j(yn, (e) => {
				n(Ye) && e(bn);
			});
			var xn = b(yn, 4), Sn = (e) => {
				var n = ze();
				a("click", n, () => se(pe)), t(e, n);
			};
			j(xn, (e) => {
				n(I) && e(Sn);
			});
			var Cn = b(xn, 2), wn = e(Cn, !0);
			A(_n);
			var Tn = b(_n, 2);
			let En;
			var Dn = g(Tn);
			p(Dn, () => me, null, (e, r) => {
				var i = ie(), a = d(i);
				y(a, () => n(r).default, (e, t) => {
					t(e, {
						get store() {
							return W;
						},
						get visible() {
							return n(I);
						},
						get reset() {
							return n(pe);
						}
					});
				}), t(e, i);
			}, (e) => {
				var n = Be();
				t(e, n);
			}), _(2), A(Tn), A(hn), A($t), A(f);
			var On = b(f, 2), kn = (r) => {
				var a = He(), o = g(a), c = b(g(o), 2);
				z(c, () => "You: your key presses as they happen (ticks = control events sent). Played: the camera action baked into each frame when it is displayed. Generation runs in blocks of frames, so the Played lane is the You lane shifted right by the end-to-end latency.", () => "left");
				var l = b(c, 6), u = (r) => {
					var a = Ve(), o = e(a);
					s((e) => i(o, `latency ${e ?? ""} s`), [() => (n(B) / 1e3).toFixed(2)]), t(r, a);
				};
				j(l, (e) => {
					n(B) != null && e(u);
				}), A(o), ye(b(o, 2), {
					get store() {
						return st;
					},
					get seconds() {
						return n(ae);
					}
				}), A(a), t(r, a);
			};
			j(On, (e) => {
				n(ce) && e(kn);
			}), A(l), ne(l, (e) => E(de, e), () => n(de)), s((e, t, r, a, o, s, c, d, f, p, m) => {
				u = k(l, 1, "wv svelte-r41nsf", null, u, { fullscreen: n(_e) }), v = k(h, 1, "stage svelte-r41nsf", null, v, { focused: n(he) }), te = ee(h, "", te, { "--ar": n(Ke) }), re = k(S, 1, "screen svelte-r41nsf", null, re, { hidden: !n(L) }), D = k(oe, 1, "hud glass svelte-r41nsf", null, D, { hidden: n(V) === "idle" && !n(L) }), k(O, 1, `dot ${n(V) ?? ""}`, "svelte-r41nsf"), i(P, n(V)), i(Je, ` ${e ?? ""}`), i($e, ` ${n(We) ?? ""}`), x(ct, "title", n(_e) ? "Exit fullscreen" : "Fullscreen"), X.disabled = !n(tt), Z.disabled = !n(nt), Tt = k(wt, 1, "svelte-r41nsf", null, Tt, { on: t }), Dt = k(Et, 1, "svelte-r41nsf", null, Dt, { on: r }), kt = k(Ot, 1, "svelte-r41nsf", null, kt, { on: a }), Mt = k(At, 1, "svelte-r41nsf", null, Mt, { on: o }), Pt = k(Q, 1, "svelte-r41nsf", null, Pt, { on: s }), It = k(Ft, 1, "svelte-r41nsf", null, It, { on: c }), zt = k(Rt, 1, "svelte-r41nsf", null, zt, { on: d }), Vt = k(Bt, 1, "svelte-r41nsf", null, Vt, { on: f }), Xt = k(Yt, 1, "svelte-r41nsf", null, Xt, { on: p }), Qt = k(Zt, 1, "svelte-r41nsf", null, Qt, { on: m }), tn = k(en, 1, "panel cond-panel svelte-r41nsf", null, tn, { closed: !n(F) }), x(an, "aria-pressed", n(F)), i(on, n(F) ? "Hide" : "Show"), cn = k(sn, 1, "panel-body svelte-r41nsf", null, cn, { hidden: !n(F) }), un = ee(ln, "", un, { "--ar": n(Ke) }), fn = k(dn, 1, "cond svelte-r41nsf", null, fn, { hidden: !n(R) }), gn = k(hn, 1, "panel cam-panel svelte-r41nsf", null, gn, { closed: !n(I) }), x(Cn, "aria-pressed", n(I)), i(wn, n(I) ? "Hide" : "Show"), En = k(Tn, 1, "panel-body cam-body svelte-r41nsf", null, En, { hidden: !n(I) });
			}, [
				() => n(Ge).toFixed(1),
				() => n($).has("fwd"),
				() => n($).has("left"),
				() => n($).has("back"),
				() => n($).has("right"),
				() => n($).has("yawL"),
				() => n($).has("yawR"),
				() => n($).has("pitchU"),
				() => n($).has("pitchD"),
				() => n($).has("up"),
				() => n($).has("down")
			]), a("keydown", h, Wt), a("keyup", h, Gt), o("focus", h, () => E(he, !0)), o("blur", h, qt), a("pointerdown", h, () => n(fe)?.focus({ preventScroll: !0 })), a("click", ct, Jt), a("click", X, Ht), a("click", Z, Ut), a("click", an, () => {
				E(F, !n(F)), requestAnimationFrame(jt);
			}), a("click", Cn, () => E(I, !n(I))), t(r, l);
		},
		$$slots: { default: !0 }
	}), ue();
}
u([
	"keydown",
	"keyup",
	"pointerdown",
	"click"
]);
//#endregion
export { We as default };
