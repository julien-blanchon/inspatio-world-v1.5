import { t as e } from "./rolldown-runtime-Dy4uBu1J.js";
import { D as t, S as n, k as r, lt as i } from "./index-client-D4l2Sz_C.js";
//#region frontend/node_modules/svelte/src/internal/disclose-version.js
var a = /* @__PURE__ */ e({});
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
//#endregion
export { a as SVELTE_VERSION, n as createRawSnippet, i as getAllContexts, t as mount, r as unmount };
