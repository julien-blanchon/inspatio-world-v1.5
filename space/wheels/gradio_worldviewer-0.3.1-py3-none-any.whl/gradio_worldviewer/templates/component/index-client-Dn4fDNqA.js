import { A as e, B as t, H as n, J as r, K as i, U as a, d as o, l as s, q as c, z as l } from "./index-client-D4l2Sz_C.js";
//#region frontend/node_modules/svelte/src/store/index-client.js
function u(e, s) {
	var c = l, u = t, d = e();
	let f = o(d, (o) => {
		var s = d !== e(), f, p = t, m = l;
		a(u), n(c);
		try {
			f = i(() => {
				r(() => {
					let t = e();
					s && o(t);
				});
			});
		} finally {
			a(p), n(m);
		}
		return s = !0, f;
	});
	return s ? {
		set: s,
		update: (t) => s(t(e())),
		subscribe: f.subscribe
	} : { subscribe: f.subscribe };
}
function d(t) {
	let n, r = e((e) => {
		let r = !1, i = t.subscribe((t) => {
			n = t, r && e();
		});
		return r = !0, i;
	});
	function i() {
		return c() ? (r(), n) : s(t);
	}
	return "set" in t ? {
		get current() {
			return i();
		},
		set current(e) {
			t.set(e);
		}
	} : { get current() {
		return i();
	} };
}
//#endregion
export { u as n, d as t };
