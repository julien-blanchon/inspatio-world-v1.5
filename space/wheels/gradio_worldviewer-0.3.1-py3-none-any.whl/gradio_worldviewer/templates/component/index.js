import { $ as e, C as t, E as n, F as r, I as i, L as a, M as o, N as s, O as c, P as l, Q as u, T as d, V as f, W as p, X as m, Y as h, _ as g, _t as _, b as v, bt as y, ct as b, dt as x, et as S, f as C, ft as ee, g as w, gt as te, h as ne, i as re, it as T, j as E, m as D, n as ie, nt as O, ot as k, p as A, r as j, st as ae, t as oe, tt as M, v as N, vt as P, w as F, x as I, y as se, yt as L } from "./index-client-D4l2Sz_C.js";
import { t as R } from "./index-client-Dn4fDNqA.js";
//#region frontend/node_modules/@gradio/theme/dist/src/colors.js
var z = [
	{
		color: "red",
		primary: 600,
		secondary: 100
	},
	{
		color: "green",
		primary: 600,
		secondary: 100
	},
	{
		color: "blue",
		primary: 600,
		secondary: 100
	},
	{
		color: "yellow",
		primary: 500,
		secondary: 100
	},
	{
		color: "purple",
		primary: 600,
		secondary: 100
	},
	{
		color: "teal",
		primary: 600,
		secondary: 100
	},
	{
		color: "orange",
		primary: 600,
		secondary: 100
	},
	{
		color: "cyan",
		primary: 600,
		secondary: 100
	},
	{
		color: "lime",
		primary: 500,
		secondary: 100
	},
	{
		color: "pink",
		primary: 600,
		secondary: 100
	}
], B = {
	inherit: "inherit",
	current: "currentColor",
	transparent: "transparent",
	black: "#000",
	white: "#fff",
	slate: {
		50: "#f8fafc",
		100: "#f1f5f9",
		200: "#e2e8f0",
		300: "#cbd5e1",
		400: "#94a3b8",
		500: "#64748b",
		600: "#475569",
		700: "#334155",
		800: "#1e293b",
		900: "#0f172a",
		950: "#020617"
	},
	gray: {
		50: "#f9fafb",
		100: "#f3f4f6",
		200: "#e5e7eb",
		300: "#d1d5db",
		400: "#9ca3af",
		500: "#6b7280",
		600: "#4b5563",
		700: "#374151",
		800: "#1f2937",
		900: "#111827",
		950: "#030712"
	},
	zinc: {
		50: "#fafafa",
		100: "#f4f4f5",
		200: "#e4e4e7",
		300: "#d4d4d8",
		400: "#a1a1aa",
		500: "#71717a",
		600: "#52525b",
		700: "#3f3f46",
		800: "#27272a",
		900: "#18181b",
		950: "#09090b"
	},
	neutral: {
		50: "#fafafa",
		100: "#f5f5f5",
		200: "#e5e5e5",
		300: "#d4d4d4",
		400: "#a3a3a3",
		500: "#737373",
		600: "#525252",
		700: "#404040",
		800: "#262626",
		900: "#171717",
		950: "#0a0a0a"
	},
	stone: {
		50: "#fafaf9",
		100: "#f5f5f4",
		200: "#e7e5e4",
		300: "#d6d3d1",
		400: "#a8a29e",
		500: "#78716c",
		600: "#57534e",
		700: "#44403c",
		800: "#292524",
		900: "#1c1917",
		950: "#0c0a09"
	},
	red: {
		50: "#fef2f2",
		100: "#fee2e2",
		200: "#fecaca",
		300: "#fca5a5",
		400: "#f87171",
		500: "#ef4444",
		600: "#dc2626",
		700: "#b91c1c",
		800: "#991b1b",
		900: "#7f1d1d",
		950: "#450a0a"
	},
	orange: {
		50: "#fff7ed",
		100: "#ffedd5",
		200: "#fed7aa",
		300: "#fdba74",
		400: "#fb923c",
		500: "#f97316",
		600: "#ea580c",
		700: "#c2410c",
		800: "#9a3412",
		900: "#7c2d12",
		950: "#431407"
	},
	amber: {
		50: "#fffbeb",
		100: "#fef3c7",
		200: "#fde68a",
		300: "#fcd34d",
		400: "#fbbf24",
		500: "#f59e0b",
		600: "#d97706",
		700: "#b45309",
		800: "#92400e",
		900: "#78350f",
		950: "#451a03"
	},
	yellow: {
		50: "#fefce8",
		100: "#fef9c3",
		200: "#fef08a",
		300: "#fde047",
		400: "#facc15",
		500: "#eab308",
		600: "#ca8a04",
		700: "#a16207",
		800: "#854d0e",
		900: "#713f12",
		950: "#422006"
	},
	lime: {
		50: "#f7fee7",
		100: "#ecfccb",
		200: "#d9f99d",
		300: "#bef264",
		400: "#a3e635",
		500: "#84cc16",
		600: "#65a30d",
		700: "#4d7c0f",
		800: "#3f6212",
		900: "#365314",
		950: "#1a2e05"
	},
	green: {
		50: "#f0fdf4",
		100: "#dcfce7",
		200: "#bbf7d0",
		300: "#86efac",
		400: "#4ade80",
		500: "#22c55e",
		600: "#16a34a",
		700: "#15803d",
		800: "#166534",
		900: "#14532d",
		950: "#052e16"
	},
	emerald: {
		50: "#ecfdf5",
		100: "#d1fae5",
		200: "#a7f3d0",
		300: "#6ee7b7",
		400: "#34d399",
		500: "#10b981",
		600: "#059669",
		700: "#047857",
		800: "#065f46",
		900: "#064e3b",
		950: "#022c22"
	},
	teal: {
		50: "#f0fdfa",
		100: "#ccfbf1",
		200: "#99f6e4",
		300: "#5eead4",
		400: "#2dd4bf",
		500: "#14b8a6",
		600: "#0d9488",
		700: "#0f766e",
		800: "#115e59",
		900: "#134e4a",
		950: "#042f2e"
	},
	cyan: {
		50: "#ecfeff",
		100: "#cffafe",
		200: "#a5f3fc",
		300: "#67e8f9",
		400: "#22d3ee",
		500: "#06b6d4",
		600: "#0891b2",
		700: "#0e7490",
		800: "#155e75",
		900: "#164e63",
		950: "#083344"
	},
	sky: {
		50: "#f0f9ff",
		100: "#e0f2fe",
		200: "#bae6fd",
		300: "#7dd3fc",
		400: "#38bdf8",
		500: "#0ea5e9",
		600: "#0284c7",
		700: "#0369a1",
		800: "#075985",
		900: "#0c4a6e",
		950: "#082f49"
	},
	blue: {
		50: "#eff6ff",
		100: "#dbeafe",
		200: "#bfdbfe",
		300: "#93c5fd",
		400: "#60a5fa",
		500: "#3b82f6",
		600: "#2563eb",
		700: "#1d4ed8",
		800: "#1e40af",
		900: "#1e3a8a",
		950: "#172554"
	},
	indigo: {
		50: "#eef2ff",
		100: "#e0e7ff",
		200: "#c7d2fe",
		300: "#a5b4fc",
		400: "#818cf8",
		500: "#6366f1",
		600: "#4f46e5",
		700: "#4338ca",
		800: "#3730a3",
		900: "#312e81",
		950: "#1e1b4b"
	},
	violet: {
		50: "#f5f3ff",
		100: "#ede9fe",
		200: "#ddd6fe",
		300: "#c4b5fd",
		400: "#a78bfa",
		500: "#8b5cf6",
		600: "#7c3aed",
		700: "#6d28d9",
		800: "#5b21b6",
		900: "#4c1d95",
		950: "#2e1065"
	},
	purple: {
		50: "#faf5ff",
		100: "#f3e8ff",
		200: "#e9d5ff",
		300: "#d8b4fe",
		400: "#c084fc",
		500: "#a855f7",
		600: "#9333ea",
		700: "#7e22ce",
		800: "#6b21a8",
		900: "#581c87",
		950: "#3b0764"
	},
	fuchsia: {
		50: "#fdf4ff",
		100: "#fae8ff",
		200: "#f5d0fe",
		300: "#f0abfc",
		400: "#e879f9",
		500: "#d946ef",
		600: "#c026d3",
		700: "#a21caf",
		800: "#86198f",
		900: "#701a75",
		950: "#4a044e"
	},
	pink: {
		50: "#fdf2f8",
		100: "#fce7f3",
		200: "#fbcfe8",
		300: "#f9a8d4",
		400: "#f472b6",
		500: "#ec4899",
		600: "#db2777",
		700: "#be185d",
		800: "#9d174d",
		900: "#831843",
		950: "#500724"
	},
	rose: {
		50: "#fff1f2",
		100: "#ffe4e6",
		200: "#fecdd3",
		300: "#fda4af",
		400: "#fb7185",
		500: "#f43f5e",
		600: "#e11d48",
		700: "#be123c",
		800: "#9f1239",
		900: "#881337",
		950: "#4c0519"
	}
};
z.reduce((e, { color: t, primary: n, secondary: r }) => ({
	...e,
	[t]: {
		primary: B[t][n],
		secondary: B[t][r]
	}
}), {});
var ce = [
	"label",
	"info",
	"placeholder",
	"description",
	"title",
	"value"
], V = /* @__PURE__ */ "elem_id.elem_classes.visible.interactive.server_fns.server.id.target.theme_mode.version.root.autoscroll.max_file_size.formatter.client.load_component.scale.min_width.theme.padding.loading_status.label.show_label.validation_error.show_progress.api_prefix.container.attached_events.register_component.unregister_component.dispatcher".split(".");
function H(e) {
	return typeof e == "string" && e.includes("__i18n__");
}
var le = class {
	load_component;
	#e = k(O({}));
	get shared() {
		return f(this.#e);
	}
	set shared(e) {
		T(this.#e, e, !0);
	}
	#t = k(O({}));
	get props() {
		return f(this.#t);
	}
	set props(e) {
		T(this.#t, e, !0);
	}
	#n = k((e) => e);
	get i18n() {
		return f(this.#n);
	}
	set i18n(e) {
		T(this.#n, e, !0);
	}
	i18n_store;
	_i18n_from_store;
	translatable_props = {};
	dispatcher;
	last_update = null;
	shared_props = V;
	mounted = !1;
	old_value;
	register_component;
	unregister_component;
	set_data_callback;
	get_data_callback;
	registered_id = null;
	last_shared_props;
	last_props;
	constructor(e, t) {
		for (let t in e.shared_props) this.shared[t] = e.shared_props[t];
		for (let t in e.props) t !== "i18n_store" && (this.props[t] = e.props[t]);
		if (t) for (let e in t) this.props[e] === void 0 && (this.props[e] = t[e]);
		this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? R(this.i18n_store) : void 0;
		for (let t of ce) this.shared[t] = this._translate_and_store("shared", t, e.shared_props[t]), this.props[t] = this._translate_and_store("props", t, e.props[t]);
		this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {}), this.unregister_component = this.shared.unregister_component || (() => {}), this.dispatcher = this.shared.dispatcher || (() => {}), this.set_data_callback = this.set_data.bind(this), this.get_data_callback = this.get_data.bind(this), this.register_component(this.shared.id, this.set_data_callback, this.get_data_callback), this.registered_id = this.shared.id, this.last_shared_props = e.shared_props, this.last_props = e.props, m(() => {
			let t = e.shared_props.id;
			if (this.last_shared_props !== e.shared_props) {
				for (let t in e.shared_props) {
					let n = e.shared_props[t];
					n !== void 0 && (this._is_i18n_managed(`shared.${t}`, n) || (this.shared[t] = n));
				}
				this.last_shared_props = e.shared_props;
			}
			if (this.last_props !== e.props) {
				for (let t in e.props) {
					if (t === "i18n_store") continue;
					let n = e.props[t];
					n !== void 0 && (this._is_i18n_managed(`props.${t}`, n) || (this.props[t] = n));
				}
				this.last_props = e.props;
			}
			this.registered_id !== null && this.registered_id !== t && this.unregister_component(this.registered_id, this.set_data_callback), this.register_component(t, this.set_data_callback, this.get_data_callback), this.registered_id = t, p(() => {
				this.shared.id = t;
			});
		}), m(() => () => {
			this.registered_id !== null && this.unregister_component(this.registered_id, this.set_data_callback);
		}), m(() => {
			if (this.i18n_store) return this.i18n_store.subscribe(() => {
				for (let [e, t] of Object.entries(this.translatable_props)) {
					let [n, r] = e.split("."), i = this.i18n(t);
					n === "shared" ? this.shared[r] = i : this.props[r] = i;
				}
			});
		});
	}
	_is_i18n_managed(e, t) {
		let n = this.translatable_props[e];
		return n ? t === n || (delete this.translatable_props[e], !1) : !1;
	}
	_translate_and_store(e, t, n) {
		if (typeof n != "string") return n;
		let r = this.i18n(n);
		return r !== n && (this.translatable_props[`${e}.${t}`] = n), r;
	}
	live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
	dispatch(e, t) {
		this.dispatcher(this.shared.id, e, t);
	}
	async get_data() {
		return te(this.props);
	}
	update(e) {
		this.set_data(e);
	}
	set_data(e) {
		for (let t in e) {
			let n = e[t], r = H(n) ? this._translate_and_store(this.shared_props.includes(t) ? "shared" : "props", t, n) : n;
			if (this.shared_props.includes(t)) {
				let e = t;
				this.shared[e] = r;
				continue;
			}
			this.props[t] = r;
		}
	}
	watch_for_change() {
		m(() => {
			this.mounted ||= (this.old_value = this.props.value, !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
		});
	}
}, U = l("<svg class=\"resize-handle svelte-1stq1b1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 10 10\"><line x1=\"1\" y1=\"9\" x2=\"9\" y2=\"1\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line><line x1=\"5\" y1=\"9\" x2=\"9\" y2=\"5\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line></svg>"), W = s("<!> <!>", 1), ue = s("<div class=\"placeholder svelte-1stq1b1\"></div>");
function de(n, r) {
	ee(r, !0);
	let a = j(r, "height", 3, void 0), s = j(r, "min_height", 3, void 0), c = j(r, "max_height", 3, void 0), l = j(r, "width", 3, void 0), u = j(r, "elem_id", 3, ""), p = j(r, "elem_classes", 19, () => []), _ = j(r, "variant", 3, "solid"), S = j(r, "border_mode", 3, "base"), w = j(r, "padding", 3, !0), te = j(r, "type", 3, "normal"), re = j(r, "test_id", 3, void 0), ie = j(r, "explicit_call", 3, !1), O = j(r, "container", 3, !0), ae = j(r, "visible", 3, !0), oe = j(r, "allow_overflow", 3, !0), N = j(r, "overflow_behavior", 3, "auto"), P = j(r, "scale", 3, null), F = j(r, "min_width", 3, 0), I = j(r, "flex", 3, !1), se = j(r, "resizable", 3, !1), L = j(r, "rtl", 3, !1), R = j(r, "fullscreen", 15, !1), z = j(r, "label", 3, void 0), B = R(), ce = k(void 0), V = b(() => te() === "fieldset" ? "fieldset" : "div"), H = b(() => ae() ? I() : !1), le = k(0), de = k(0), G = k(null), K = null, fe = null, q = null;
	function pe(e) {
		R() && e.key === "Escape" && R(!1);
	}
	function me(e) {
		let t = e.getRootNode();
		return e.closest(".gradio-container") ?? (t instanceof ShadowRoot ? t : document.body);
	}
	function he(e) {
		let t = document.createElement("div");
		t.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; visibility: hidden; pointer-events: none;", e.appendChild(t);
		let n = t.getBoundingClientRect();
		return t.remove(), n;
	}
	function ge(e, t) {
		let n = e.parentNode;
		if (!n || n === t) return !1;
		let r = he(n), i = he(t);
		return Math.abs(r.top - i.top) > 1 || Math.abs(r.left - i.left) > 1 || Math.abs(r.width - i.width) > 1 || Math.abs(r.height - i.height) > 1;
	}
	function _e(e, t) {
		e.parentNode && e.parentNode !== t && (K = e.parentNode, q = e, fe = document.createComment("fullscreen block"), K.insertBefore(fe, e), t.appendChild(e));
	}
	function ve() {
		if (!K || !q) return;
		let e = fe && fe.parentNode === K ? fe : null;
		K.insertBefore(q, e), e?.remove(), K = null, fe = null, q = null;
	}
	m(() => {
		let e = f(ce);
		if (R() !== B && e) {
			if (B = R(), R()) {
				T(G, e.getBoundingClientRect(), !0), T(le, e.offsetHeight, !0), T(de, e.offsetWidth, !0);
				let t = me(e);
				ge(e, t) && _e(e, t), window.addEventListener("keydown", pe);
			} else ve(), T(G, null), window.removeEventListener("keydown", pe);
		}
	}), m(() => () => {
		window.removeEventListener("keydown", pe), ve();
	});
	let ye = (e) => {
		if (e !== void 0) {
			if (typeof e == "number") return e + "px";
			if (typeof e == "string") return e;
		}
	}, be = (e) => {
		let t = f(ce);
		if (!t) return;
		let n = e.clientY, r = (e) => {
			let r = e.clientY - n;
			n = e.clientY, t.style.height = `${t.offsetHeight + r}px`;
		}, i = () => {
			window.removeEventListener("mousemove", r), window.removeEventListener("mouseup", i);
		};
		window.addEventListener("mousemove", r), window.addEventListener("mouseup", i);
	};
	var xe = o(), Se = e(xe), Ce = (n) => {
		var o = W(), m = e(o);
		v(m, () => f(V), !1, (n, o) => {
			C(n, (e) => T(ce, e, !0), () => f(ce)), ne(n, (e, t, n, r, i) => ({
				"data-testid": re(),
				id: u(),
				class: `block ${e ?? ""}`,
				dir: L() ? "rtl" : "ltr",
				"aria-label": z(),
				style: "",
				[A]: {
					hidden: ae() === "hidden",
					padded: w(),
					flex: f(H),
					border_focus: S() === "focus",
					border_contrast: S() === "contrast",
					"hide-container": !ie() && !O(),
					fullscreen: R(),
					animating: R() && f(G) !== null,
					"auto-margin": P() === null
				},
				[D]: {
					height: t,
					"min-height": n,
					"max-height": r,
					"--start-top": f(G) ? `${f(G).top}px` : "0px",
					"--start-left": f(G) ? `${f(G).left}px` : "0px",
					"--start-width": f(G) ? `${f(G).width}px` : "0px",
					"--start-height": f(G) ? `${f(G).height}px` : "0px",
					width: i,
					"border-style": _(),
					overflow: oe() ? N() : "hidden",
					"flex-grow": P(),
					"min-width": `calc(min(${F()}px, 100%))`
				}
			}), [
				() => p()?.join(" ") || "",
				() => R() ? void 0 : ye(a()),
				() => R() ? void 0 : ye(s()),
				() => R() ? void 0 : ye(c()),
				() => R() ? void 0 : typeof l() == "number" ? `calc(min(${l()}px, 100%))` : ye(l())
			], void 0, void 0, "svelte-1stq1b1");
			var m = W(), h = e(m);
			t(h, () => r.children ?? y);
			var g = M(h, 2), v = (e) => {
				var t = U();
				i("mousedown", t, be), E(e, t);
			};
			d(g, (e) => {
				se() && e(v);
			}), E(o, m);
		});
		var b = M(m, 2), x = (e) => {
			var t = ue();
			let n;
			h(() => n = g(t, "", n, {
				height: f(le) + "px",
				width: f(de) + "px"
			})), E(e, t);
		};
		d(b, (e) => {
			R() && e(x);
		}), E(n, o);
	};
	d(Se, (e) => {
		(ae() === !0 || ae() === "hidden") && e(Ce);
	}), E(n, xe), x();
}
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/CustomButton.svelte
r(["mousedown"]), r(["click"]), _(), r(["click"]), r(["click"]);
//#endregion
//#region frontend/Timeline.svelte
var G = s("<span class=\"svelte-vjzdoe\"><i class=\"svelte-vjzdoe\"></i> </span>"), K = s("<div class=\"tl svelte-vjzdoe\"><canvas data-testid=\"worldviewer-timeline\" class=\"svelte-vjzdoe\"></canvas> <div class=\"legend svelte-vjzdoe\"><!> <span class=\"svelte-vjzdoe\"><i class=\"hatch svelte-vjzdoe\"></i>autopilot</span> <span class=\"svelte-vjzdoe\"><i class=\"strip svelte-vjzdoe\"></i>displayed frames</span> <span class=\"svelte-vjzdoe\"><i class=\"blk svelte-vjzdoe\"></i>block</span></div></div>");
function fe(e, t) {
	ee(t, !0);
	let n = j(t, "seconds", 3, 10), r = j(t, "running", 3, !1), i = j(t, "default_latency_ms", 3, 2e3), a = [
		{
			axis: "forward",
			color: "#f97316",
			pos: "W",
			neg: "S"
		},
		{
			axis: "right",
			color: "#22d3ee",
			pos: "D",
			neg: "A"
		},
		{
			axis: "yaw",
			color: "#a78bfa",
			pos: "E",
			neg: "Q"
		},
		{
			axis: "pitch",
			color: "#4ade80",
			pos: "R",
			neg: "F"
		},
		{
			axis: "up",
			color: "#facc15",
			pos: "␣",
			neg: "⇧"
		}
	], o = new Map(a.map((e, t) => [e.axis, t])), s = k(void 0), l = k(void 0), d = 0, p = null, m = 600, _ = 120, v = 1, y = null, b = null, S = !0, te = -1, ne = !1, re = .8, D = a.length * 11 - 2, O = 22 + D + 7, A = a.length * 4 - 1, ae = O + A + 13;
	function N() {
		f(s) && f(l) && (v = Math.min(2, window.devicePixelRatio || 1), m = Math.max(240, f(s).clientWidth), _ = ae + 6, f(l).width = Math.round(m * v), f(l).height = Math.round(_ * v), f(l).style.height = `${_}px`, y = null, S = !0);
	}
	function I(e) {
		let t = document.createElement("canvas");
		t.width = t.height = Math.round(6 * v);
		let n = t.getContext("2d");
		return n.strokeStyle = "rgba(255,255,255,0.4)", n.lineWidth = 1.2 * v, n.beginPath(), n.moveTo(0, t.height), n.lineTo(t.width, 0), n.stroke(), e.createPattern(t, "repeat");
	}
	function se(e, t, n, r, i, a) {
		y ||= I(e), e.globalAlpha = a, e.fillStyle = "rgba(255,255,255,0.06)", e.fillRect(t, n, r, i), y && (e.fillStyle = y, e.fillRect(t, n, r, i)), e.globalAlpha = 1;
	}
	function R(e, t, n, r, i, s, c, l) {
		let u = r - n;
		if (!(u <= 0)) {
			if (t.has_action && !t.action) {
				se(e, n, i, u, a.length * (s + c) - c, l);
				return;
			}
			if (t.action) {
				for (let r of a) {
					let a = t.action[r.axis];
					if (!a) continue;
					let d = i + (o.get(r.axis) ?? 0) * (s + c);
					e.globalAlpha = l * (a > 0 ? .35 + .65 * Math.min(1, a) : .3 + .35 * Math.min(1, -a)), e.fillStyle = r.color, e.fillRect(n, d, u, s);
				}
				e.globalAlpha = 1;
			}
		}
	}
	function z(e) {
		let n = 0;
		for (; n < t.store.you.length && (t.store.you[n].t1 ?? Infinity) < e;) n++;
		for (n && t.store.you.splice(0, n), n = 0; n < t.store.frames.length && t.store.frames[n].t + t.store.frames[n].dur < e;) n++;
		n && t.store.frames.splice(0, n);
	}
	function B(e, r) {
		if (!f(l)) return;
		let s = f(l).getContext("2d");
		if (!s) return;
		let c = n() * 1e3, u = m - 10, d = u - 10, p = d / c, h = 10 + re * d, g = t.store.sched, y = t.store.latency_ms != null && Number.isFinite(t.store.latency_ms), x = Math.min(g ? g.delay_ms : y ? t.store.latency_ms : i(), .85 * re * c), S = h - x * p, C = (t) => h - (e - t) * p, ee = (t) => S - (e - t) * p;
		r && z(e - c * 1.2), s.setTransform(v, 0, 0, v, 0, 0), s.clearRect(0, 0, m, _);
		let w = O + A + 3 - 19;
		s.fillStyle = "rgba(255,255,255,0.035)", s.fillRect(10, 19, S - 10, w), s.fillStyle = "rgba(249,115,22,0.07)", s.fillRect(S, 19, h - S, w), s.fillStyle = "rgba(255,255,255,0.015)", s.fillRect(h, 19, u - h, w), s.strokeStyle = "rgba(255,255,255,0.06)", s.lineWidth = 1, s.font = "9px ui-monospace, monospace", s.fillStyle = "rgba(244,245,247,0.4)", s.textAlign = "center";
		for (let e = -Math.floor(re * n()); e <= Math.floor(.19999999999999996 * n()); e++) {
			let t = Math.round(h + e * 1e3 * p) + .5;
			s.beginPath(), s.moveTo(t, 19), s.lineTo(t, 19 + w), s.stroke(), e !== 0 && s.fillText(`${e > 0 ? "+" : ""}${e}s`, t, ae);
		}
		if (s.textAlign = "left", r || b != null) {
			let n = [], r = (e) => C(g.base0 + e.index * 1e3 / g.fps);
			for (let e of t.store.frames) {
				let t = e.dur * p, i = g && e.index != null ? r(e) : ee(e.t);
				i + t >= 10 && n.push([
					e,
					i,
					i + t,
					!0
				]);
			}
			let i = 0;
			for (let e of t.store.queue) {
				let t = 1e3 / (e.fps || 15), a = g && e.index != null ? r(e) : S + i * p;
				if (i += t, a > u) break;
				n.push([
					e,
					a,
					Math.min(u, a + t * p),
					!1
				]);
			}
			for (let [e, t, r, i] of n) R(s, e, Math.max(10, t), r + .5, O, 3, 1, i ? 1 : .4), e.first_in_chunk && t >= 10 && (s.fillStyle = i ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.35)", s.fillRect(Math.round(t), O - 3, 1, A + 6));
			let c = e - (h - 10) / p;
			if (t.store.you.some((t) => (t.t1 ?? e) >= c)) for (let n of t.store.you) {
				let t = n.t1 == null ? e : Math.min(n.t1, e);
				if (t <= n.t0) continue;
				let r = Math.max(10, C(n.t0)), i = Math.min(h, C(t));
				if (i <= 10) continue;
				let c = a[o.get(n.axis) ?? 0], l = 22 + (o.get(n.axis) ?? 0) * 11, u = Math.min(1, Math.abs(n.val));
				for (let [e, t, a] of [[
					r,
					Math.min(i, S),
					1
				], [
					Math.max(r, S),
					i,
					.45
				]]) {
					let r = t - e;
					r <= 0 || (s.globalAlpha = a * (.35 + .65 * u), n.val > 0 ? (s.fillStyle = c.color, s.fillRect(e, l, Math.max(1.5, r), 9)) : (s.fillStyle = c.color + "40", s.fillRect(e, l, Math.max(1.5, r), 9), s.strokeStyle = c.color, s.strokeRect(e + .5, l + .5, Math.max(1, r - 1), 8)));
				}
				s.globalAlpha = 1, i - r > 11 && (s.fillStyle = n.val > 0 ? "rgba(0,0,0,0.75)" : c.color, s.font = "700 8px ui-monospace, monospace", s.fillText(n.val > 0 ? c.pos : c.neg, r + 2.5, l + 9 - 1.5));
			}
			else {
				for (let [e, t, r, i] of n) R(s, e, Math.max(10, t), r + .5, 22, 9, 2, i ? .9 : .35);
				(t.store.frames.some((e) => e.has_action && !e.action) || t.store.queue.some((e) => e.has_action && !e.action)) && (s.fillStyle = "rgba(244,245,247,0.75)", s.font = "600 9px ui-sans-serif, system-ui, sans-serif", s.fillText("autopilot", 16, 22 + D / 2 + 3));
			}
		} else s.fillStyle = "rgba(244,245,247,0.4)", s.font = "11px ui-sans-serif, system-ui, sans-serif", s.textAlign = "center", s.fillText("Press Start — your key presses and the model's response appear here", (10 + u) / 2, 22 + D / 2 + 4), s.textAlign = "left";
		s.lineWidth = 1.5, s.strokeStyle = "rgba(244,245,247,0.85)", s.beginPath(), s.moveTo(Math.round(S) + .5, 16), s.lineTo(Math.round(S) + .5, 19 + w + 2), s.stroke(), s.strokeStyle = "#f97316", s.beginPath(), s.moveTo(Math.round(h) + .5, 16), s.lineTo(Math.round(h) + .5, 19 + w + 2), s.stroke(), s.lineWidth = 1, s.font = "700 9.5px ui-sans-serif, system-ui, sans-serif", s.fillStyle = "#f97316", s.fillText("You", h + 4, 10), s.fillStyle = "rgba(244,245,247,0.9)";
		let te = s.measureText("Model").width;
		s.fillText("Model", S - te - 4, 10), s.strokeStyle = "rgba(244,245,247,0.55)", s.beginPath(), s.moveTo(S + 2, 13), s.lineTo(h - 2, 13), s.stroke();
		let ne = g ? `${(x / 1e3).toFixed(1)} s` : y ? `latency ${(x / 1e3).toFixed(2)} s` : `latency ≈${(x / 1e3).toFixed(1)} s (estimate)`;
		s.font = "600 10px ui-sans-serif, system-ui, sans-serif";
		let T = s.measureText(ne).width, E = Math.max(S + 4, (S + h) / 2 - T / 2);
		s.fillStyle = "#0e1117", s.fillRect(E - 5, 5, T + 10, 14), s.fillStyle = g || y ? "#fdba74" : "rgba(244,245,247,0.6)", s.fillText(ne, E, 16.5), s.fillStyle = "rgba(244,245,247,0.4)", s.font = "9px ui-monospace, monospace", s.textAlign = "center", s.fillText("now", h, ae), s.textAlign = "left";
	}
	function ce() {
		if (d = requestAnimationFrame(ce), t.store.session !== te && (te = t.store.session, b = null, S = !0), r()) {
			let e = performance.now();
			b = e, ne = !0, B(e, !0);
		} else (S || ne) && (ne = !1, S = !1, B(b ?? performance.now(), !1));
	}
	ie(() => {
		p = new ResizeObserver(N), f(s) && p.observe(f(s)), N(), d = requestAnimationFrame(ce);
	}), oe(() => {
		cancelAnimationFrame(d), p?.disconnect();
	});
	var V = K(), H = u(V);
	C(H, (e) => T(l, e), () => f(l));
	var le = M(H, 2), U = u(le);
	F(U, 17, () => a, (e) => e.axis, (e, t) => {
		var n = G(), r = u(n);
		let i;
		var a = M(r);
		L(n), h(() => {
			i = g(r, "", i, { background: f(t).color }), c(a, `${f(t).pos ?? ""}/${f(t).neg ?? ""} ${f(t).axis ?? ""}`);
		}), E(e, n);
	}), P(6), L(le), L(V), C(V, (e) => T(s, e), () => f(s)), h(() => w(H, "data-running", r() ? "1" : "0")), E(e, V), x();
}
//#endregion
//#region frontend/MapView.svelte
var q = s("<div class=\"readout mono svelte-1q9tenk\"> </div>"), pe = s("<div class=\"note svelte-1q9tenk\">The map of your camera path appears here once a session starts.</div>"), me = s("<div class=\"map svelte-1q9tenk\"><canvas data-testid=\"worldviewer-map\" class=\"svelte-1q9tenk\"></canvas> <div class=\"compass svelte-1q9tenk\" aria-hidden=\"true\">▲ ahead</div> <!> <!></div>");
function he(e, t) {
	ee(t, !0);
	let n = j(t, "visible", 3, !0), r = j(t, "reset", 3, 0), o = j(t, "accent", 3, "#f97316"), s = k(void 0), l = k(void 0), p = k(""), g = k(!0), _ = 0, v = null, y = 300, b = 200, w = 1, te = [
		0,
		0,
		0
	], ne = [
		1,
		0,
		0
	], re = [
		0,
		1,
		0
	], D = [
		0,
		0,
		1
	], O = !1, A = 1, ae = [
		500,
		500,
		416,
		240,
		832,
		480
	], N = [], P = /* @__PURE__ */ new Float32Array(), F = /* @__PURE__ */ new Float32Array(), I = {
		u: 0,
		v: 0,
		s: 60
	}, se = {
		u: 0,
		v: 0,
		s: 60
	}, R = {
		du: 0,
		dv: 0,
		zoom: 1
	}, z = -1, B = -1, ce = 0, V = !0, H = 0, le = 0, U = null, W = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], ue = (e, t) => [
		e[0] - t[0],
		e[1] - t[1],
		e[2] - t[2]
	], de = (e) => [
		e[3],
		e[7],
		e[11]
	], G = (e, t) => [
		e[t],
		e[4 + t],
		e[8 + t]
	], K = (e) => {
		let t = ue(e, te);
		return [
			W(t, ne),
			W(t, D),
			-W(t, re)
		];
	};
	function fe(e) {
		let t = atob(e), n = new Uint8Array(t.length);
		for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
		return n;
	}
	function he() {
		let e = t.store.scene?.source_poses?.[0] ?? t.store.poses[0] ?? null;
		O = !!e, e && (te = de(e), ne = G(e, 0), re = G(e, 1), D = G(e, 2));
	}
	function ge() {
		N = [];
		let e = t.store.scene;
		if (e?.intrinsics?.length === 6 && (ae = e.intrinsics.slice()), he(), A = 1, !e?.points) return;
		let n, r;
		try {
			let t = fe(e.points);
			n = new Float32Array(t.buffer, 0, Math.floor(t.byteLength / 12) * 3), r = fe(e.colors);
		} catch {
			return;
		}
		let i = Math.min(n.length / 3, Math.floor(r.length / 3)), a = Math.max(1, Math.floor(i / 12e3)), o = /* @__PURE__ */ new Map(), s = [];
		for (let e = 0; e < i; e += a) {
			let t = [
				n[e * 3],
				n[e * 3 + 1],
				n[e * 3 + 2]
			];
			if (!Number.isFinite(t[0] + t[1] + t[2])) continue;
			let [i, a] = K(t);
			a > 0 && s.push(a);
			let c = r[e * 3], l = r[e * 3 + 1], u = r[e * 3 + 2], d = .3 * c + .59 * l + .11 * u, f = (e) => Math.round((.45 * e + .55 * d) / 255 * 3) * 85, p = `rgb(${f(c)},${f(l)},${f(u)})`, m = o.get(p);
			m || o.set(p, m = []), m.push(i, a);
		}
		N = [...o].map(([e, t]) => ({
			style: e,
			uv: new Float32Array(t)
		})), s.length && (s.sort((e, t) => e - t), A = Math.max(.001, s[Math.floor(s.length / 2)]));
	}
	function _e() {
		O || he();
		let e = t.store.poses.length;
		P = new Float32Array(e), F = new Float32Array(e);
		for (let n = 0; n < e; n++) {
			let [e, r] = K(de(t.store.poses[n]));
			P[n] = e, F[n] = r;
		}
	}
	function ve() {
		let e = -.35 * A, t = .35 * A, n = -.15 * A, r = .6 * A;
		for (let i = 0; i < P.length; i++) e = Math.min(e, P[i]), t = Math.max(t, P[i]), n = Math.min(n, F[i]), r = Math.max(r, F[i]);
		let i = .18 * Math.max(t - e, r - n) + .05 * A;
		e -= i, t += i, n -= i, r += i;
		let a = Math.min((y - 24) / (t - e), (b - 44) / (r - n));
		se = {
			u: (e + t) / 2,
			v: (n + r) / 2,
			s: Math.max(1e-6, a)
		};
	}
	function ye() {
		f(s) && f(l) && (w = Math.min(2, window.devicePixelRatio || 1), y = Math.max(120, f(s).clientWidth), b = Math.max(120, f(s).clientHeight), f(l).width = Math.round(y * w), f(l).height = Math.round(b * w), ve(), U = null, V = !0);
	}
	function be(e) {
		let t = 60 / e, n = 10 ** Math.floor(Math.log10(t));
		for (let e of [
			1,
			2,
			5,
			10
		]) if (e * n >= t) return e * n;
		return 10 * n;
	}
	function xe() {
		if (!f(l)) return;
		let e = f(l).getContext("2d");
		if (!e) return;
		let n = I.s * R.zoom, r = I.u + R.du, i = I.v + R.dv, a = (e) => y / 2 + (e - r) * n, s = (e) => b / 2 + 8 - (e - i) * n;
		e.setTransform(w, 0, 0, w, 0, 0), e.clearRect(0, 0, y, b);
		let c = be(n);
		e.strokeStyle = "rgba(255,255,255,0.05)", e.lineWidth = 1, e.beginPath();
		let u = Math.floor((r - y / 2 / n) / c) * c;
		for (let t = u; a(t) < y; t += c) {
			let n = Math.round(a(t)) + .5;
			e.moveTo(n, 0), e.lineTo(n, b);
		}
		let d = Math.floor((i - b / 2 / n) / c) * c;
		for (let t = d; s(t) > 0; t += c) {
			let n = Math.round(s(t)) + .5;
			e.moveTo(0, n), e.lineTo(y, n);
		}
		if (e.stroke(), N.length) {
			(!U || Math.abs(Math.log(n / U.s)) > .04 || Math.abs((r - U.u) * n) > y * .2 || Math.abs((i - U.v) * n) > b * .2) && (U = Se(r, i, n));
			let t = n / U.s, a = y / 2 + (U.u - r) * n - U.ox * t, o = b / 2 + 8 - (U.v - i) * n - U.oy * t;
			e.globalAlpha = .3, e.drawImage(U.c, a, o, U.c.width / w * t, U.c.height / w * t), e.globalAlpha = 1;
		}
		O && we(e, a(0), s(0), 0, 26, "rgba(203,213,225,0.55)", "rgba(203,213,225,0.10)", 1.2);
		let m = P.length, h = Math.min(t.store.played, m);
		if (m - Math.max(0, h - 1) >= 2) {
			e.strokeStyle = o(), e.globalAlpha = .45, e.lineWidth = 3, e.setLineDash([6, 5]), e.lineCap = "round", e.beginPath();
			for (let t = Math.max(0, h - 1); t < m; t++) {
				let n = a(P[t]), r = s(F[t]);
				t === Math.max(0, h - 1) ? e.moveTo(n, r) : e.lineTo(n, r);
			}
			e.stroke(), e.setLineDash([]), e.globalAlpha = 1;
		}
		if (h >= 2) {
			e.strokeStyle = o(), e.lineWidth = 4, e.lineCap = "round", e.lineJoin = "round", e.beginPath();
			for (let t = 0; t < h; t++) {
				let n = a(P[t]), r = s(F[t]);
				t === 0 ? e.moveTo(n, r) : e.lineTo(n, r);
			}
			e.stroke();
		}
		for (let t = 0; t < m; t += 12) {
			let n = a(P[t]), r = s(F[t]);
			e.beginPath(), e.arc(n, r, 5, 0, Math.PI * 2), t < h ? (e.fillStyle = o(), e.fill()) : (e.fillStyle = "rgba(14,17,23,0.9)", e.fill(), e.globalAlpha = .55, e.strokeStyle = o(), e.lineWidth = 2, e.stroke(), e.globalAlpha = 1);
		}
		if (m > h && m > 0) {
			let t = a(P[m - 1]), n = s(F[m - 1]);
			e.globalAlpha = .7, e.strokeStyle = o(), e.lineWidth = 2, e.beginPath(), e.arc(t, n, 8, 0, Math.PI * 2), e.stroke(), e.globalAlpha = 1;
		}
		if (O) {
			let t = a(m ? P[0] : 0), n = s(m ? F[0] : 0);
			e.beginPath(), e.arc(t, n, 7, 0, Math.PI * 2), e.fillStyle = "#0e1117", e.fill(), e.lineWidth = 2.5, e.strokeStyle = "#f4f5f7", e.stroke(), e.beginPath(), e.arc(t, n, 2.5, 0, Math.PI * 2), e.fillStyle = "#f4f5f7", e.fill(), Ce(e, "start", t + 11, n + 4, "#f4f5f7");
		}
		let g = "";
		if (h > 0) {
			let n = t.store.poses[h - 1], r = G(n, 2), i = W(r, ne), c = W(r, D), l = Math.atan2(i, c), u = a(P[h - 1]), d = s(F[h - 1]);
			we(e, u, d, l, 44, o(), "rgba(249,115,22,0.28)", 2.5), e.beginPath(), e.arc(u, d, 6, 0, Math.PI * 2), e.fillStyle = o(), e.fill(), e.lineWidth = 2, e.strokeStyle = "#fff", e.stroke();
			let [, , f] = K(de(n)), p = Math.asin(Math.max(-1, Math.min(1, -W(r, re)))), m = (e) => `${e >= 0 ? "+" : "−"}${Math.abs(e * 180 / Math.PI).toFixed(0)}°`;
			g = `heading ${m(l)} · pitch ${m(p)} · height ${f >= 0 ? "+" : "−"}${Math.abs(f).toFixed(2)}`;
		}
		g !== f(p) && T(p, g, !0), e.fillStyle = "rgba(244,245,247,0.45)", e.font = "9px ui-monospace, monospace";
		let _ = c * n;
		e.fillRect(y - 12 - _, b - 12, _, 2), e.textAlign = "right", e.fillText(`${+c.toPrecision(2)} u`, y - 12, b - 16), e.textAlign = "left";
	}
	function Se(e, t, n) {
		let r = Math.round(y * 1.6), i = Math.round(b * 1.6), a = U?.c ?? document.createElement("canvas");
		a.width = Math.round(r * w), a.height = Math.round(i * w);
		let o = a.getContext("2d");
		o.setTransform(w, 0, 0, w, 0, 0), o.clearRect(0, 0, r, i);
		let s = r / 2, c = i / 2 + 8, l = Math.max(1, Math.min(2.2, n * A * .004));
		for (let a of N) {
			o.fillStyle = a.style, o.beginPath();
			let u = a.uv;
			for (let a = 0; a < u.length; a += 2) {
				let d = s + (u[a] - e) * n, f = c - (u[a + 1] - t) * n;
				d < -2 || f < -2 || d > r + 2 || f > i + 2 || o.rect(d - l / 2, f - l / 2, l, l);
			}
			o.fill();
		}
		return {
			c: a,
			u: e,
			v: t,
			s: n,
			ox: s,
			oy: c
		};
	}
	function Ce(e, t, n, r, i) {
		e.font = "700 10px ui-sans-serif, system-ui, sans-serif";
		let a = e.measureText(t).width;
		e.fillStyle = "rgba(14,17,23,0.8)", e.fillRect(n - 3, r - 10, a + 6, 14), e.fillStyle = i, e.fillText(t, n, r);
	}
	function we(e, t, n, r, i, a, o, s) {
		let c = Math.atan2(ae[4] / 2, ae[0]), l = r - c - Math.PI / 2, u = r + c - Math.PI / 2;
		e.beginPath(), e.moveTo(t, n), e.arc(t, n, i, l, u), e.closePath(), e.fillStyle = o, e.fill(), e.lineWidth = s, e.lineJoin = "round", e.strokeStyle = a, e.stroke();
	}
	function Te(e) {
		_ = requestAnimationFrame(Te);
		let i = H ? Math.min(100, e - H) : 16;
		if (H = e, !n() || !f(l)) return;
		t.store.scene_version !== z && (z = t.store.scene_version, ge(), U = null, _e(), ve(), I = { ...se }, V = !0), t.store.version !== B && (B = t.store.version, (t.store.poses.length === 0 || !O) && he(), _e(), ve(), t.store.poses.length === 0 && (I = { ...se }), V = !0), r() !== ce && (ce = r(), R = {
			du: 0,
			dv: 0,
			zoom: 1
		}, V = !0);
		let a = 1 - Math.exp(-i / 250), o = se.u - I.u, s = se.v - I.v, c = Math.log(se.s / I.s);
		(Math.abs(o) * I.s > .2 || Math.abs(s) * I.s > .2 || Math.abs(c) > .002) && (I.u += o * a, I.v += s * a, I.s *= Math.exp(c * a), V = !0);
		let u = !O && t.store.poses.length === 0;
		u !== f(g) && T(g, u, !0), V && e - le >= 33 && (V = !1, le = e, xe());
	}
	let Ee = null;
	function De(e) {
		Ee = {
			x: e.clientX,
			y: e.clientY
		}, e.currentTarget.setPointerCapture?.(e.pointerId);
	}
	function Oe(e) {
		if (!Ee) return;
		let t = I.s * R.zoom;
		R.du -= (e.clientX - Ee.x) / t, R.dv += (e.clientY - Ee.y) / t, Ee = {
			x: e.clientX,
			y: e.clientY
		}, V = !0;
	}
	function ke() {
		Ee = null;
	}
	function Ae(e) {
		e.preventDefault(), R.zoom = Math.min(20, Math.max(.2, R.zoom * Math.exp(-e.deltaY * .0015))), V = !0;
	}
	ie(() => {
		v = new ResizeObserver(ye), f(s) && v.observe(f(s)), f(l)?.addEventListener("wheel", Ae, { passive: !1 }), ye(), _ = requestAnimationFrame(Te);
	}), oe(() => {
		cancelAnimationFrame(_), v?.disconnect(), f(l)?.removeEventListener("wheel", Ae);
	}), m(() => {
		n() && (V = !0, requestAnimationFrame(ye));
	});
	var je = me(), Me = u(je);
	C(Me, (e) => T(l, e), () => f(l));
	var Ne = M(Me, 4), Pe = (e) => {
		var t = q(), n = S(t, !0);
		h(() => c(n, f(p))), E(e, t);
	};
	d(Ne, (e) => {
		f(p) && e(Pe);
	});
	var Fe = M(Ne, 2), Ie = (e) => {
		var t = pe();
		E(e, t);
	};
	d(Fe, (e) => {
		f(g) && e(Ie);
	}), L(je), C(je, (e) => T(s, e), () => f(s)), i("pointerdown", Me, De), i("pointermove", Me, Oe), i("pointerup", Me, ke), a("pointercancel", Me, ke), E(e, je), x();
}
r([
	"pointerdown",
	"pointermove",
	"pointerup"
]);
//#endregion
//#region frontend/Index.svelte
var ge = (e, t = y, n = y) => {
	var r = ve();
	h(() => {
		N(r, 1, `info ${n() ?? ""}`, "svelte-r41nsf"), w(r, "aria-label", t()), w(r, "data-tip", t());
	}), E(e, r);
}, _e = /* @__PURE__ */ new Set([
	"$$slots",
	"$$events",
	"$$legacy"
]), ve = s("<span tabindex=\"0\" role=\"note\">i</span>"), ye = s("<div class=\"poster svelte-r41nsf\"><div class=\"poster-grid svelte-r41nsf\"></div></div>"), be = s("<span class=\"msg svelte-r41nsf\"> </span>"), xe = s("<span class=\"svelte-r41nsf\"><span class=\"k svelte-r41nsf\">gen</span> </span>"), Se = s("<span class=\"lat svelte-r41nsf\"><span class=\"k svelte-r41nsf\">delay</span> </span>"), Ce = s("<span><span class=\"k svelte-r41nsf\"> </span> </span>"), we = l("<svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"svelte-r41nsf\"><path d=\"M8 3v3a2 2 0 0 1-2 2H3M21 8h-3a2 2 0 0 1-2-2V3M3 16h3a2 2 0 0 1 2 2v3M16 21v-3a2 2 0 0 1 2-2h3\" class=\"svelte-r41nsf\"></path></svg>"), Te = l("<svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"svelte-r41nsf\"><path d=\"M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3\" class=\"svelte-r41nsf\"></path></svg>"), Ee = s("<div class=\"overlay dim svelte-r41nsf\"><div class=\"spinner svelte-r41nsf\" aria-hidden=\"true\"></div> <div class=\"ov-text svelte-r41nsf\"> </div></div>"), De = s("<div class=\"overlay error svelte-r41nsf\"><div class=\"ov-title svelte-r41nsf\">Error</div> <div class=\"ov-text svelte-r41nsf\"> </div> <button class=\"btn primary small svelte-r41nsf\">Try again</button></div>"), Oe = s("<div class=\"ov-text svelte-r41nsf\"> </div>"), ke = s("<div class=\"overlay dim svelte-r41nsf\"><div class=\"ov-title svelte-r41nsf\">Session ended</div> <!> <button class=\"btn primary small svelte-r41nsf\"><svg viewBox=\"0 0 24 24\" width=\"14\" height=\"14\" fill=\"currentColor\" class=\"svelte-r41nsf\"><path d=\"M8 5v14l11-7z\" class=\"svelte-r41nsf\"></path></svg> Start again</button></div>"), Ae = s("<div><button class=\"big-play svelte-r41nsf\" aria-label=\"Start\"><svg viewBox=\"0 0 24 24\" width=\"30\" height=\"30\" fill=\"currentColor\" class=\"svelte-r41nsf\"><path d=\"M8 5v14l11-7z\" class=\"svelte-r41nsf\"></path></svg></button> <div class=\"ov-text svelte-r41nsf\"> </div></div>"), je = s("<div class=\"chip buffering glass svelte-r41nsf\"><span class=\"mini-spin svelte-r41nsf\"></span>buffering</div>"), Me = s("<div class=\"chip buffering glass svelte-r41nsf\"><span class=\"mini-spin svelte-r41nsf\"></span> </div>"), Ne = s("<div class=\"chip hint glass svelte-r41nsf\">Click here to control</div>"), Pe = s("<div class=\"session-bar svelte-r41nsf\"><div class=\"fill svelte-r41nsf\"></div></div>"), Fe = s("<span class=\"time mono svelte-r41nsf\"> </span>"), Ie = s("<div class=\"empty svelte-r41nsf\">No render condition yet</div>"), Le = s("<span class=\"sub svelte-r41nsf\"> </span>"), Re = s("<div class=\"seg svelte-r41nsf\" role=\"group\" aria-label=\"Camera view\"><button data-testid=\"worldviewer-cam-map\">Map</button> <button data-testid=\"worldviewer-cam-3d\">3D</button></div> <button class=\"mini svelte-r41nsf\" title=\"Re-frame the view\">Reset view</button>", 1), ze = s("<div class=\"empty svelte-r41nsf\">3D view unavailable</div>"), Be = s("<span class=\"lat-badge mono svelte-r41nsf\" title=\"Measured time from a control event to the frame generated with it\"> </span>"), Ve = s("<section class=\"panel tl-panel svelte-r41nsf\"><header class=\"svelte-r41nsf\"><span class=\"title svelte-r41nsf\">Timeline</span> <!> <span class=\"sub svelte-r41nsf\">your keys vs. what is on screen</span> <span class=\"grow svelte-r41nsf\"></span> <!></header> <!></section>"), He = s("<div><div class=\"grid svelte-r41nsf\"><div class=\"main svelte-r41nsf\"><div tabindex=\"0\" role=\"application\" aria-label=\"World viewer. Click, then use W A S D, arrows, Q E, R F, Space and Shift to move the camera. Enter starts, Escape stops.\" data-testid=\"worldviewer-stage\"><canvas data-testid=\"worldviewer-canvas\"></canvas> <!> <div aria-live=\"polite\" data-testid=\"worldviewer-hud\"><div class=\"hud-row status-row svelte-r41nsf\"><span></span> <span class=\"status-name svelte-r41nsf\"> </span> <!></div> <div class=\"hud-row mono svelte-r41nsf\"><span class=\"svelte-r41nsf\"><span class=\"k svelte-r41nsf\">play</span> </span> <!> <span class=\"svelte-r41nsf\"><span class=\"k svelte-r41nsf\">buf</span> </span> <!> <!></div></div> <div class=\"tools svelte-r41nsf\"><button class=\"icon-btn glass svelte-r41nsf\" aria-label=\"Toggle fullscreen\"><!></button></div> <!> <!> <!> <!> <!></div> <div class=\"toolbar svelte-r41nsf\"><div class=\"left svelte-r41nsf\"><button class=\"btn primary svelte-r41nsf\" data-testid=\"worldviewer-start\"><svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"svelte-r41nsf\"><path d=\"M8 5v14l11-7z\" class=\"svelte-r41nsf\"></path></svg> Start</button> <button class=\"btn stop svelte-r41nsf\" data-testid=\"worldviewer-stop\"><svg viewBox=\"0 0 24 24\" width=\"14\" height=\"14\" fill=\"currentColor\" class=\"svelte-r41nsf\"><rect x=\"6\" y=\"6\" width=\"12\" height=\"12\" rx=\"2\" class=\"svelte-r41nsf\"></rect></svg> Stop</button> <!></div> <div class=\"hints svelte-r41nsf\" aria-hidden=\"true\"><span class=\"svelte-r41nsf\"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> move</span> <span class=\"svelte-r41nsf\"><kbd>Q</kbd><kbd>E</kbd>/<kbd class=\"svelte-r41nsf\">←</kbd><kbd class=\"svelte-r41nsf\">→</kbd> turn</span> <span class=\"svelte-r41nsf\"><kbd>R</kbd><kbd>F</kbd> look</span> <span class=\"svelte-r41nsf\"><kbd>Space</kbd><kbd>⇧</kbd> up/down</span> <span class=\"svelte-r41nsf\"><kbd class=\"svelte-r41nsf\">↵</kbd> start <kbd class=\"svelte-r41nsf\">Esc</kbd> stop</span></div></div></div> <div class=\"side svelte-r41nsf\"><section><header class=\"svelte-r41nsf\"><span class=\"title svelte-r41nsf\">What the model sees</span> <!> <span class=\"grow svelte-r41nsf\"></span> <button class=\"mini svelte-r41nsf\" data-testid=\"worldviewer-cond-toggle\"> </button></header> <div><div class=\"cond-wrap svelte-r41nsf\"><canvas data-testid=\"worldviewer-cond\"></canvas> <!></div> <div class=\"caption svelte-r41nsf\">Point cloud splatted into your camera — black holes are what the model imagines</div></div></section> <section><header class=\"svelte-r41nsf\"><span class=\"title svelte-r41nsf\">Camera</span> <!> <!> <span class=\"grow svelte-r41nsf\"></span> <!> <button class=\"mini svelte-r41nsf\"> </button></header> <div><!> <div class=\"cam-legend svelte-r41nsf\"><span class=\"svelte-r41nsf\"><i class=\"mk start svelte-r41nsf\"></i>start</span> <span class=\"svelte-r41nsf\"><i class=\"sw played svelte-r41nsf\"></i>played</span> <span class=\"svelte-r41nsf\"><i class=\"sw buf svelte-r41nsf\"></i>upcoming</span> <span class=\"svelte-r41nsf\"><i class=\"mk cur svelte-r41nsf\"></i>camera</span></div></div></section></div></div> <!></div>");
function Ue(t, r) {
	ee(r, !0);
	let s = new le(re(r, _e));
	s.watch_for_change();
	let l = [
		"forward",
		"right",
		"yaw",
		"pitch",
		"up"
	], _ = b(() => Math.max(1, s.props.prebuffer_frames ?? 8)), v = b(() => s.props.catchup_rate ?? 1.15), y = b(() => s.props.heartbeat_ms ?? 250), te = b(() => 1e3 / Math.max(1, s.props.max_control_hz ?? 20)), ne = b(() => s.props.timeline_seconds ?? 10), D = b(() => 1e3 * (s.props.latency ?? 3.5)), A = b(() => s.props.show_timeline ?? !0), j = b(() => s.props.placeholder ?? "Press Start, then click here and use WASD / arrows to move"), F = k(void 0), R = k(void 0), z = k(void 0), B = k(void 0), ce = k(0), V = k("map"), H = k(null);
	function U(e) {
		T(V, e, !0), e === "3d" && !f(H) && T(H, import("./CameraView-BJgQ5RXs.js"), !0);
	}
	let W = k(null), ue = k(!1), G = k(!1), K = k(O(p(() => s.props.show_render ?? !0))), q = k(O(p(() => s.props.show_camera ?? !0))), pe = k(!1), me = k(!1), ve = k(!1), Ue = k(0), We = k(0), Ge = k(null), Ke = k(null), qe = k(null), Je = k(O(p(() => s.props.aspect_ratio || 832 / 480))), Ye = k(O(performance.now())), Xe = k(O(performance.now())), Ze = k(""), Qe = b(() => s.props.value ?? null), $e = b(() => f(Qe)?.status ?? "idle"), et = b(() => s.shared.loading_status), tt = b(() => f(et)?.status === "error" && (f(W) === "start" || f($e) === "loading" || f($e) === "running")), J = b(() => f(tt) ? "error" : f(W) === "start" ? "loading" : f(W) === "stop" ? "ended" : f($e)), nt = b(() => f(tt) ? f(et)?.message || f(Qe)?.message || "Something went wrong" : f(W) === "start" ? ut() || "Starting…" : f(W) === "stop" ? "Stopped" : f(Qe)?.message ?? ""), rt = b(() => f(J) === "running" || f(J) === "loading"), it = b(() => !f(rt)), at = b(() => f(rt)), ot = b(() => f(Qe)?.stats ?? {}), st = b(() => typeof f(ot).gen_fps == "number" ? f(ot).gen_fps : null), ct = b(() => typeof f(ot).limit_s == "number" ? f(ot).limit_s : null), lt = b(() => {
		let e = typeof f(ot).elapsed_s == "number" ? f(ot).elapsed_s : 0, t = f($e) === "running" ? (f(Ye) - f(Xe)) / 1e3 : 0;
		return f(ct) ? Math.min(f(ct), e + t) : e + t;
	});
	function ut() {
		let e = s.shared.loading_status;
		return e?.status === "pending" && e.queue_position != null && e.queue_position > 0 ? `Waiting in queue (position ${e.queue_position + 1}${e.queue_size ? ` / ${e.queue_size}` : ""})…` : "";
	}
	let Y = {
		you: [],
		frames: [],
		queue: [],
		latency_ms: null,
		session: 0,
		sched: null
	}, X = {
		scene: null,
		scene_version: 0,
		poses: [],
		played: 0,
		version: 0
	}, dt = "", Z = [], ft = 0, pt = Promise.resolve(), mt = null, ht = /* @__PURE__ */ new Set(), gt = -1, _t = 12, vt = !1, yt = 0, bt = 0, xt = null, Q = [], St = 0, Ct = 0, wt = null, Tt = /* @__PURE__ */ new Map(), Et = null, Dt = 3500, Ot = 0, kt = 15, At = -1, jt = !1, Mt = null;
	function Nt(e) {
		e && ("close" in e.bm && e.bm.close(), e.rb && "close" in e.rb && e.rb.close());
	}
	function Pt(e) {
		ft++;
		for (let e of Z) Nt(e);
		Z = [], Y.queue = Z, ht = /* @__PURE__ */ new Set(), gt = -1, mt = e, vt = !1, bt = 0, Q = [], T(Ue, 0), wt = null, Y.latency_ms = null, T(Ge, null), Et = null, Ot = 0, At = -1, jt = !1, Y.sched = null, X.poses = [], X.played = 0, X.version++;
	}
	function Ft(e) {
		let t = e.indexOf(","), n = e.slice(5, t).split(";")[0] || "image/jpeg", r = atob(e.slice(t + 1)), i = new Uint8Array(r.length);
		for (let e = 0; e < r.length; e++) i[e] = r.charCodeAt(e);
		return new Blob([i], { type: n });
	}
	async function It(e) {
		if (typeof createImageBitmap == "function" && e.startsWith("data:")) return await createImageBitmap(Ft(e));
		let t = new Image();
		return t.decoding = "async", t.src = e, await t.decode(), t;
	}
	function Lt(e) {
		return e ? {
			forward: +(e.forward ?? 0),
			right: +(e.right ?? 0),
			up: +(e.up ?? 0),
			yaw: +(e.yaw ?? 0),
			pitch: +(e.pitch ?? 0)
		} : null;
	}
	function Rt(e) {
		let t = ft, n = e.fps > 0 ? e.fps : 15, r = typeof e.frame_start == "number" ? e.frame_start : null, i = Promise.all(e.frames.map(It)), a = e.renders?.length ? Promise.all(e.renders.map((e) => It(e).catch(() => null))) : Promise.resolve(null);
		pt = pt.then(async () => {
			let o, s;
			try {
				[o, s] = await Promise.all([i, a]);
			} catch (t) {
				console.warn("[WorldViewer] failed to decode chunk", e.id, t);
				return;
			}
			if (t !== ft) {
				o.forEach((e) => Nt({
					bm: e,
					rb: null
				})), s?.forEach((e) => e && Nt({
					bm: e,
					rb: null
				}));
				return;
			}
			let c = Array.isArray(e.actions), l = o.map((t, i) => {
				let a = e.poses?.[i], o = -1;
				return Array.isArray(a) && a.length >= 12 && (X.poses.push(a), o = X.poses.length - 1), {
					bm: t,
					rb: s?.[i] ?? null,
					fps: n,
					action: c ? Lt(e.actions[i]) : null,
					has_action: c,
					seq: e.control_seqs?.[i] ?? null,
					pose: a ?? null,
					chunk_id: e.id,
					first_in_chunk: i === 0,
					index: r == null ? null : r + i,
					arrived: performance.now(),
					pose_index: o
				};
			});
			e.poses?.length && X.version++, s && s.some(Boolean) && T(me, !0), _t = Math.max(1, l.length), Z.push(...l), T(Ue, Z.length, !0);
		});
	}
	function zt(e) {
		let t = e.scene;
		if (!t || !t.points) return;
		let n = `${t.title}|${t.points.length}|${t.points.slice(0, 64)}|${t.points.slice(-64)}|${t.source_poses?.length}`;
		n !== dt && (dt = n, X.scene = t, X.scene_version++, T(Ze, t.title || "", !0));
	}
	function Bt(e) {
		if (!e) return;
		(f(W) === "start" || f(W) === "stop" && e.status !== "running" && e.status !== "loading") && T(W, null), T(Xe, performance.now(), !0), zt(e);
		let t = e.chunk;
		if (t && Array.isArray(t.frames) && t.frames.length !== 0 && t.session !== Mt) {
			if (t.session !== mt) Pt(t.session);
			else if (t.id === 0 && gt > 0) Pt(t.session);
			else if (ht.has(t.id)) return;
			ht.add(t.id), gt = Math.max(gt, t.id), Et == null && typeof t.elapsed == "number" && typeof t.frame_start == "number" && (Et = performance.now() - t.elapsed * 1e3, kt = t.fps > 0 ? t.fps : 15), Et != null && (Dt = 1e3 * (typeof t.latency == "number" ? t.latency : f(D) / 1e3), Y.sched = {
				base0: Et,
				fps: kt,
				delay_ms: Dt + Ot
			}), Rt(t);
		}
	}
	m(() => {
		let e = s.props.value;
		p(() => Bt(e));
	});
	function Vt(e, t) {
		Y.frames.push({
			t,
			dur: 1e3 / (e.fps || 15),
			action: e.action,
			has_action: e.has_action,
			fps: e.fps,
			first_in_chunk: e.first_in_chunk,
			index: e.index
		});
	}
	function Ht() {
		Y.you.length = 0, Y.frames.length = 0, Y.latency_ms = null, Y.session++;
		for (let e of l) delete Qt[e];
		$t(Zt(f($)));
	}
	function Ut(e, t) {
		if (!f(z)) return;
		let n = e.bm.width, r = e.bm.height;
		n && r && (f(z).width !== n || f(z).height !== r) && (f(z).width = n, f(z).height = r, T(Je, n / r)), f(z).getContext("2d")?.drawImage(e.bm, 0, 0, f(z).width, f(z).height), Wt(e);
		let i = xt;
		if (xt = e, i && i !== e && Nt(i), f(pe) || T(pe, !0), e.seq != null && Tt.has(e.seq)) {
			let n = t - Tt.get(e.seq);
			wt = wt == null ? n : wt * .85 + n * .15, Y.latency_ms = wt;
		}
		Vt(e, t), e.pose_index >= 0 && (X.played = e.pose_index + 1, X.version++);
	}
	function Wt(e) {
		if (!e?.rb || !f(B)) return;
		let t = e.rb.width, n = e.rb.height;
		t && n && (f(B).width !== t || f(B).height !== n) && (f(B).width = t, f(B).height = n), f(B).getContext("2d")?.drawImage(e.rb, 0, 0, f(B).width, f(B).height);
	}
	function Gt() {
		xt && f(z) && (f(z).getContext("2d")?.drawImage(xt.bm, 0, 0, f(z).width, f(z).height), Wt(xt));
	}
	function Kt(e) {
		St = requestAnimationFrame(Kt);
		let t = yt ? Math.min(e - yt, 250) : 0;
		yt = e;
		let n = f($e) === "running" || f($e) === "loading";
		if (Et != null && (Z.length === 0 || Z[0].index != null) ? qt(e, n) : Jt(e, t, n), e - Ct > 120) {
			Ct = e;
			let t;
			if (Et != null) {
				let r = Et + Dt + Ot + (At + 1) * 1e3 / kt;
				t = n && jt && Z.length === 0 && e > r + 30;
				let i = !jt && n ? Math.max(0, (r - e) / 1e3) : null;
				i !== f(qe) && (i == null || f(qe) == null || Math.abs(i - f(qe)) > .05) && T(qe, i, !0);
				let a = (Dt + Ot) / 1e3;
				a !== f(Ke) && T(Ke, a);
			} else t = n && !vt && f(pe), f(qe) != null && T(qe, null), f(Ke) != null && T(Ke, null);
			t !== f(ve) && T(ve, t, !0), f(Ue) !== Z.length && T(Ue, Z.length, !0);
			let r = 0;
			Q.length > 2 && e - Q[Q.length - 1] < 1e3 && (r = (Q.length - 1) * 1e3 / (Q[Q.length - 1] - Q[0])), Math.abs(r - f(We)) > .05 && T(We, r, !0);
			let i = wt;
			i !== f(Ge) && (i == null || f(Ge) == null || Math.abs(i - f(Ge)) > 15) && T(Ge, i, !0), T(Ye, performance.now(), !0);
			for (let [t, n] of Tt) e - n > 6e4 && Tt.delete(t);
		}
	}
	function qt(e, t) {
		let n = (e) => Et + Dt + Ot + e.index * 1e3 / (e.fps || kt);
		for (; Z.length > 1 && n(Z[1]) <= e && Z[1].arrived <= n(Z[1]);) {
			let e = Z.shift();
			Vt(e, n(e)), e.pose_index >= 0 && (X.played = e.pose_index + 1), Nt(e);
		}
		let r = Z[0];
		if (!r || e < n(r)) return;
		let i = e - n(r);
		r.arrived > n(r) && i > 0 && (Ot += i, Y.sched && (Y.sched.delay_ms = Dt + Ot)), Z.shift(), vt = !0, jt = !0, At = r.index, Ut(r, e), Q.push(e), Q.length > 30 && Q.shift();
	}
	function Jt(e, t, n) {
		if (vt || (Z.length >= f(_) || Z.length > 0 && !n) && (vt = !0, bt = 1e3 / (Z[0]?.fps || 15)), vt) {
			if (Z.length === 0) vt = !1;
			else {
				let n = Z.length, r = n > 4 * _t ? f(v) * f(v) : n > 2 * _t ? f(v) : 1;
				bt += t * r;
				let i = 1e3 / (Z[0].fps || 15);
				bt >= i && (bt = Math.min(bt - i, i), Ut(Z.shift(), e), Q.push(e), Q.length > 30 && Q.shift());
			}
		}
	}
	let Yt = {
		KeyW: "fwd",
		ArrowUp: "fwd",
		KeyS: "back",
		ArrowDown: "back",
		KeyA: "left",
		KeyD: "right",
		KeyQ: "yawL",
		ArrowLeft: "yawL",
		KeyE: "yawR",
		ArrowRight: "yawR",
		KeyR: "pitchU",
		KeyF: "pitchD",
		Space: "up",
		ShiftLeft: "down",
		ShiftRight: "down"
	}, Xt = k(O({})), $ = b(() => new Set(Object.values(f(Xt))));
	function Zt(e) {
		let t = (t, n) => +!!e.has(t) - !!e.has(n);
		return {
			forward: t("fwd", "back"),
			right: t("right", "left"),
			up: t("up", "down"),
			yaw: t("yawR", "yawL"),
			pitch: t("pitchU", "pitchD")
		};
	}
	let Qt = {};
	function $t(e) {
		let t = performance.now();
		for (let n of l) {
			let r = Qt[n];
			if (!(r && r.val === e[n]) && (r && (r.t1 = t, delete Qt[n]), e[n] !== 0)) {
				let r = {
					axis: n,
					val: e[n],
					t0: t,
					t1: null
				};
				Y.you.push(r), Qt[n] = r;
			}
		}
	}
	let en = 0, tn = "", nn = 0, rn = null;
	function an(e = !1) {
		let t = Zt(f($)), n = `${t.forward},${t.right},${t.up},${t.yaw},${t.pitch}`;
		if (!e && n === tn) return;
		let r = performance.now(), i = nn + f(te) - r;
		if (i > 0) {
			rn ||= setTimeout(() => {
				rn = null, an(!0);
			}, i);
			return;
		}
		tn = n, nn = r;
		let a = {
			...t,
			seq: ++en,
			session: mt ?? ""
		};
		Tt.set(a.seq, r), s.dispatch("control", a);
	}
	m(() => {
		let e = f($);
		p(() => {
			$t(Zt(e)), an(!1);
		});
	}), m(() => {
		if (!f(rt)) return;
		let e = setInterval(() => an(!0), f(y));
		return () => clearInterval(e);
	});
	function on() {
		f(it) && (T(W, "start"), T(Xe, performance.now(), !0), Mt = null, Ht(), s.dispatch("start", {}), f(R)?.focus({ preventScroll: !0 }));
	}
	function sn() {
		if (f(at)) {
			T(W, "stop"), Mt = mt, ft++;
			for (let e of Z) Nt(e);
			Z.length = 0, T(Ue, 0), s.dispatch("stop", {});
		}
	}
	function cn(e) {
		if (e.ctrlKey || e.metaKey || e.altKey) return;
		if (e.code === "Enter" || e.code === "NumpadEnter") {
			e.preventDefault(), on();
			return;
		}
		if (e.code === "Escape") {
			e.preventDefault(), sn();
			return;
		}
		let t = Yt[e.code];
		t && (e.preventDefault(), f(Xt)[e.code] !== t && (f(Xt)[e.code] = t));
	}
	function ln(e) {
		Yt[e.code] && (e.preventDefault(), delete f(Xt)[e.code]);
	}
	function un() {
		Object.keys(f(Xt)).length && T(Xt, {}, !0);
	}
	function dn() {
		T(ue, !1), un();
	}
	async function fn() {
		try {
			document.fullscreenElement ? await document.exitFullscreen() : await f(F)?.requestFullscreen();
		} catch (e) {
			console.warn("[WorldViewer] fullscreen failed", e);
		}
	}
	function pn() {
		document.hidden && un();
	}
	function mn() {
		T(G, document.fullscreenElement === f(F)), requestAnimationFrame(Gt);
	}
	ie(() => {
		St = requestAnimationFrame(Kt), document.addEventListener("fullscreenchange", mn), document.addEventListener("visibilitychange", pn), window.addEventListener("blur", un);
	}), oe(() => {
		cancelAnimationFrame(St), rn && clearTimeout(rn), document.removeEventListener("fullscreenchange", mn), document.removeEventListener("visibilitychange", pn), window.removeEventListener("blur", un), Pt(null), Nt(xt);
	}), de(t, {
		get visible() {
			return s.shared.visible;
		},
		get elem_id() {
			return s.shared.elem_id;
		},
		get elem_classes() {
			return s.shared.elem_classes;
		},
		get container() {
			return s.shared.container;
		},
		get scale() {
			return s.shared.scale;
		},
		get min_width() {
			return s.shared.min_width;
		},
		padding: !1,
		allow_overflow: !0,
		children: (t, r) => {
			var s = He();
			let l;
			var p = u(s), m = u(p), _ = u(m);
			let v, y;
			var x = u(_);
			let ee;
			C(x, (e) => T(z, e), () => f(z));
			var te = M(x, 2), re = (e) => {
				var t = ye();
				E(e, t);
			};
			d(te, (e) => {
				f(pe) || e(re);
			});
			var D = M(te, 2);
			let ie;
			var O = u(D), k = u(O), oe = M(k, 2), le = S(oe, !0), W = M(oe, 2), de = (e) => {
				var t = be(), n = S(t, !0);
				h(() => {
					w(t, "title", f(nt)), c(n, f(nt));
				}), E(e, t);
			};
			d(W, (e) => {
				f(nt) && f(J) !== "loading" && f(J) !== "error" && e(de);
			}), L(O);
			var _e = M(O, 2), Ye = u(_e), Xe = M(u(Ye));
			L(Ye);
			var Qe = M(Ye, 2), $e = (e) => {
				var t = xe(), n = M(u(t));
				L(t), h((e) => c(n, ` ${e ?? ""} fps`), [() => f(st).toFixed(1)]), E(e, t);
			};
			d(Qe, (e) => {
				f(st) != null && e($e);
			});
			var et = M(Qe, 2), tt = M(u(et));
			L(et);
			var rt = M(et, 2), ot = (e) => {
				var t = Se(), n = M(u(t));
				L(t), h((e) => c(n, ` ${e ?? ""} s`), [() => f(Ke).toFixed(2)]), E(e, t);
			};
			d(rt, (e) => {
				f(Ke) != null && e(ot);
			});
			var ut = M(rt, 2), dt = (e) => {
				var t = Ce(), n = u(t), r = S(n, !0), i = M(n);
				L(t), h((e) => {
					N(t, 1, se(f(Ke) == null ? "lat" : ""), "svelte-r41nsf"), c(r, f(Ke) == null ? "latency" : "lag"), c(i, ` ${e ?? ""} s`);
				}, [() => (f(Ge) / 1e3).toFixed(2)]), E(e, t);
			};
			d(ut, (e) => {
				f(Ge) != null && e(dt);
			}), L(_e), L(D);
			var Z = M(D, 2), ft = u(Z), pt = u(ft), mt = (e) => {
				var t = we();
				E(e, t);
			}, ht = (e) => {
				var t = Te();
				E(e, t);
			};
			d(pt, (e) => {
				f(G) ? e(mt) : e(ht, -1);
			}), L(ft), L(Z);
			var gt = M(Z, 2), _t = (e) => {
				var t = Ee(), n = M(u(t), 2), r = S(n, !0);
				L(t), h(() => c(r, f(nt) || "Loading…")), E(e, t);
			}, vt = (e) => {
				var t = De(), n = M(u(t), 2), r = S(n, !0), a = M(n, 2);
				L(t), h(() => c(r, f(nt))), i("click", a, on), E(e, t);
			}, yt = (e) => {
				var t = ke(), n = M(u(t), 2), r = (e) => {
					var t = Oe(), n = S(t, !0);
					h(() => c(n, f(nt))), E(e, t);
				};
				d(n, (e) => {
					f(nt) && e(r);
				});
				var a = M(n, 2);
				L(t), i("click", a, on), E(e, t);
			}, bt = (e) => {
				var t = Ae();
				let n;
				var r = u(t), a = M(r, 2), o = S(a, !0);
				L(t), h(() => {
					n = N(t, 1, "overlay svelte-r41nsf", null, n, { dim: f(pe) }), c(o, f(nt) || f(j));
				}), i("click", r, on), E(e, t);
			};
			d(gt, (e) => {
				f(J) === "loading" ? e(_t) : f(J) === "error" ? e(vt, 1) : f(J) === "ended" && f(Ue) === 0 ? e(yt, 2) : f(J) === "idle" && e(bt, 3);
			});
			var xt = M(gt, 2), Q = (e) => {
				var t = je();
				E(e, t);
			};
			d(xt, (e) => {
				f(ve) && f(J) === "running" && e(Q);
			});
			var St = M(xt, 2), Ct = (e) => {
				var t = Me(), n = M(u(t));
				L(t), h((e) => c(n, `first frame in ${e ?? ""} s`), [() => f(qe).toFixed(1)]), E(e, t);
			};
			d(St, (e) => {
				f(qe) != null && f(J) === "running" && e(Ct);
			});
			var wt = M(St, 2), Tt = (e) => {
				var t = Ne();
				E(e, t);
			};
			d(wt, (e) => {
				f(J) === "running" && !f(ue) && e(Tt);
			});
			var Et = M(wt, 2), Dt = (e) => {
				var t = Pe(), n = u(t);
				let r;
				L(t), h((e, i, a) => {
					w(t, "title", `Session time ${e ?? ""}s / ${i ?? ""}s`), r = g(n, "", r, { width: a });
				}, [
					() => f(lt).toFixed(0),
					() => f(ct).toFixed(0),
					() => `${Math.min(100, 100 * f(lt) / f(ct))}%`
				]), E(e, t);
			};
			d(Et, (e) => {
				f(ct) && e(Dt);
			}), L(_), C(_, (e) => T(R, e), () => f(R));
			var Ot = M(_, 2), kt = u(Ot), At = u(kt), jt = M(At, 2), Mt = M(jt, 2), Nt = (e) => {
				var t = Fe(), n = S(t);
				h((e, t) => c(n, `${e ?? ""}s / ${t ?? ""}s`), [() => f(lt).toFixed(0), () => f(ct).toFixed(0)]), E(e, t);
			};
			d(Mt, (e) => {
				f(ct) && e(Nt);
			}), L(kt);
			var Pt = M(kt, 2), Ft = u(Pt), It = u(Ft);
			let Lt;
			var Rt = M(It);
			let zt;
			var Bt = M(Rt);
			let Vt;
			var Ht = M(Bt);
			let Ut;
			P(), L(Ft);
			var Wt = M(Ft, 2), Kt = u(Wt);
			let qt;
			var Jt = M(Kt);
			let Yt;
			P(4), L(Wt);
			var Xt = M(Wt, 2), Zt = u(Xt);
			let Qt;
			var $t = M(Zt);
			let en;
			P(), L(Xt);
			var tn = M(Xt, 2), nn = u(tn);
			let rn;
			var an = M(nn);
			let un;
			P(), L(tn), P(2), L(Pt), L(Ot), L(m);
			var pn = M(m, 2), mn = u(pn);
			let hn;
			var gn = u(mn), _n = M(u(gn), 2);
			ge(_n, () => "Your scene's point cloud seen from your camera; black holes are what the model imagines.", () => "right");
			var vn = M(_n, 4), yn = S(vn, !0);
			L(gn);
			var bn = M(gn, 2);
			let xn;
			var Sn = u(bn);
			let Cn;
			var wn = u(Sn);
			let Tn;
			C(wn, (e) => T(B, e), () => f(B));
			var En = M(wn, 2), Dn = (e) => {
				var t = Ie();
				E(e, t);
			};
			d(En, (e) => {
				f(me) || e(Dn);
			}), L(Sn), P(2), L(bn), L(mn);
			var On = M(mn, 2);
			let kn;
			var An = u(On), jn = M(u(An), 2);
			ge(jn, () => "Top-down map of your camera path from the start (dashed: not played yet); switch to 3D to orbit.", () => "right");
			var Mn = M(jn, 2), Nn = (e) => {
				var t = Le(), n = S(t, !0);
				h(() => {
					w(t, "title", f(Ze)), c(n, f(Ze));
				}), E(e, t);
			};
			d(Mn, (e) => {
				f(Ze) && e(Nn);
			});
			var Pn = M(Mn, 4), Fn = (t) => {
				var n = Re(), r = e(n), a = u(r);
				let o;
				var s = M(a, 2);
				let c;
				L(r);
				var l = M(r, 2);
				h(() => {
					w(a, "aria-pressed", f(V) === "map"), o = N(a, 1, "svelte-r41nsf", null, o, { on: f(V) === "map" }), w(s, "aria-pressed", f(V) === "3d"), c = N(s, 1, "svelte-r41nsf", null, c, { on: f(V) === "3d" });
				}), i("click", a, () => U("map")), i("click", s, () => U("3d")), i("click", l, () => ae(ce)), E(t, n);
			};
			d(Pn, (e) => {
				f(q) && e(Fn);
			});
			var In = M(Pn, 2), Ln = S(In, !0);
			L(An);
			var Rn = M(An, 2);
			let zn;
			var Bn = u(Rn), Vn = (e) => {
				he(e, {
					get store() {
						return X;
					},
					get visible() {
						return f(q);
					},
					get reset() {
						return f(ce);
					}
				});
			}, Hn = (t) => {
				var r = o(), i = e(r);
				n(i, () => f(H), null, (t, n) => {
					var r = o(), i = e(r);
					I(i, () => f(n).default, (e, t) => {
						t(e, {
							get store() {
								return X;
							},
							get visible() {
								return f(q);
							},
							get reset() {
								return f(ce);
							}
						});
					}), E(t, r);
				}, (e) => {
					var t = ze();
					E(e, t);
				}), E(t, r);
			};
			d(Bn, (e) => {
				f(V) === "map" ? e(Vn) : f(H) && e(Hn, 1);
			}), P(2), L(Rn), L(On), L(pn), L(p);
			var Un = M(p, 2), Wn = (e) => {
				var t = Ve(), n = u(t), r = M(u(n), 2);
				ge(r, () => "Your keys (right cursor) reach the screen at the model cursor, one latency later.", () => "left");
				var i = M(r, 6), a = (e) => {
					var t = Be(), n = S(t);
					h((e) => c(n, `measured lag ${e ?? ""} s`), [() => (f(Ge) / 1e3).toFixed(2)]), E(e, t);
				};
				d(i, (e) => {
					f(Ge) != null && e(a);
				}), L(n);
				var o = M(n, 2);
				{
					let e = b(() => f(J) === "running");
					fe(o, {
						get store() {
							return Y;
						},
						get seconds() {
							return f(ne);
						},
						get running() {
							return f(e);
						}
					});
				}
				L(t), E(e, t);
			};
			d(Un, (e) => {
				f(A) && e(Wn);
			}), L(s), C(s, (e) => T(F, e), () => f(F)), h((e, t, n, r, i, a, o, u, d, p, m) => {
				l = N(s, 1, "wv svelte-r41nsf", null, l, { fullscreen: f(G) }), v = N(_, 1, "stage svelte-r41nsf", null, v, { focused: f(ue) }), y = g(_, "", y, { "--ar": f(Je) }), ee = N(x, 1, "screen svelte-r41nsf", null, ee, { hidden: !f(pe) }), ie = N(D, 1, "hud glass svelte-r41nsf", null, ie, { hidden: f(J) === "idle" && !f(pe) }), N(k, 1, `dot ${f(J) ?? ""}`, "svelte-r41nsf"), c(le, f(J)), c(Xe, ` ${e ?? ""}`), c(tt, ` ${f(Ue) ?? ""}`), w(ft, "title", f(G) ? "Exit fullscreen" : "Fullscreen"), At.disabled = !f(it), jt.disabled = !f(at), Lt = N(It, 1, "svelte-r41nsf", null, Lt, { on: t }), zt = N(Rt, 1, "svelte-r41nsf", null, zt, { on: n }), Vt = N(Bt, 1, "svelte-r41nsf", null, Vt, { on: r }), Ut = N(Ht, 1, "svelte-r41nsf", null, Ut, { on: i }), qt = N(Kt, 1, "svelte-r41nsf", null, qt, { on: a }), Yt = N(Jt, 1, "svelte-r41nsf", null, Yt, { on: o }), Qt = N(Zt, 1, "svelte-r41nsf", null, Qt, { on: u }), en = N($t, 1, "svelte-r41nsf", null, en, { on: d }), rn = N(nn, 1, "svelte-r41nsf", null, rn, { on: p }), un = N(an, 1, "svelte-r41nsf", null, un, { on: m }), hn = N(mn, 1, "panel cond-panel svelte-r41nsf", null, hn, { closed: !f(K) }), w(vn, "aria-pressed", f(K)), c(yn, f(K) ? "Hide" : "Show"), xn = N(bn, 1, "panel-body svelte-r41nsf", null, xn, { hidden: !f(K) }), Cn = g(Sn, "", Cn, { "--ar": f(Je) }), Tn = N(wn, 1, "cond svelte-r41nsf", null, Tn, { hidden: !f(me) }), kn = N(On, 1, "panel cam-panel svelte-r41nsf", null, kn, { closed: !f(q) }), w(In, "aria-pressed", f(q)), c(Ln, f(q) ? "Hide" : "Show"), zn = N(Rn, 1, "panel-body cam-body svelte-r41nsf", null, zn, { hidden: !f(q) });
			}, [
				() => f(We).toFixed(1),
				() => f($).has("fwd"),
				() => f($).has("left"),
				() => f($).has("back"),
				() => f($).has("right"),
				() => f($).has("yawL"),
				() => f($).has("yawR"),
				() => f($).has("pitchU"),
				() => f($).has("pitchD"),
				() => f($).has("up"),
				() => f($).has("down")
			]), i("keydown", _, cn), i("keyup", _, ln), a("focus", _, () => T(ue, !0)), a("blur", _, dn), i("pointerdown", _, () => f(R)?.focus({ preventScroll: !0 })), i("click", ft, fn), i("click", At, on), i("click", jt, sn), i("click", vn, () => {
				T(K, !f(K)), requestAnimationFrame(Gt);
			}), i("click", In, () => T(q, !f(q))), E(t, s);
		},
		$$slots: { default: !0 }
	}), x();
}
r([
	"keydown",
	"keyup",
	"pointerdown",
	"click"
]);
//#endregion
export { Ue as default };
