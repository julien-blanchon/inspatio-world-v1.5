import { c as e, g as t, i as n, o as r } from "./index-client-CkyDaBBE.js";
//#region \0rolldown/runtime.js
var i = Object.defineProperty, a = /* @__PURE__ */ ((e, t) => {
	let n = {};
	for (var r in e) i(n, r, {
		get: e[r],
		enumerable: !0
	});
	return t || i(n, Symbol.toStringTag, { value: "Module" }), n;
})({});
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
//#endregion
export { a as SVELTE_VERSION, n as createRawSnippet, t as getAllContexts, r as mount, e as unmount };
