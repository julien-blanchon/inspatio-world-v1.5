import { _ as e, a as t, d as n, f as r, h as i, l as a, m as o, n as s, p as c, r as l, s as u, t as d, u as f, v as p, y as m } from "./index-client-CkyDaBBE.js";
//#region frontend/Example.svelte
var h = f("<img alt=\"first frame\" class=\"svelte-s3apn9\"/>"), g = f("<div><!></div>");
function _(f, _) {
	p(_, !0);
	let v = d(_, "selected", 3, !1), y = i(() => (_.value === null || _.value === void 0 ? void 0 : _.value.chunk)?.frames?.[0] ?? null);
	var b = g();
	let x;
	var S = o(b), C = (e) => {
		var t = h();
		c(() => s(t, "src", r(y))), a(e, t);
	}, w = (e) => {
		var t = n();
		c(() => u(t, _.value?.status ?? "")), a(e, t);
	};
	t(S, (e) => {
		r(y) ? e(C) : e(w, -1);
	}), m(b), c(() => x = l(b, 1, "svelte-s3apn9", null, x, {
		table: _.type === "table",
		gallery: _.type === "gallery",
		selected: v()
	})), a(f, b), e();
}
//#endregion
export { _ as default };
