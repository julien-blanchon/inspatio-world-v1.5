import { U as e, m as t, x as n, y as r } from "./index-client-r7L6l6Tr.js";
//#region \0rolldown/runtime.js
var i = Object.defineProperty, a = /* @__PURE__ */ ((e, t) => {
	let n = {};
	for (var r in e) i(n, r, {
		get: e[r],
		enumerable: !0
	});
	return t || i(n, Symbol.toStringTag, { value: "Module" }), n;
})({});
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
//#endregion
export { a as SVELTE_VERSION, t as createRawSnippet, e as getAllContexts, r as mount, n as unmount };
