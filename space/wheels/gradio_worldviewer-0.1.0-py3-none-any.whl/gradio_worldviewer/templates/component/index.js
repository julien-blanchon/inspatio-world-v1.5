import { A as e, B as t, C as n, D as r, E as i, F as a, G as o, H as s, I as c, J as l, K as u, L as d, M as f, N as p, O as m, P as h, R as g, S as _, T as v, V as y, W as ee, X as te, Y as ne, _ as re, a as ie, b, c as ae, d as oe, f as x, g as se, h as S, i as C, j as w, k as ce, l as T, n as le, o as ue, p as E, q as D, r as O, s as de, t as fe, u as k, v as A, w as pe, z as j } from "./index-client-r7L6l6Tr.js";
//#region frontend/node_modules/@gradio/theme/dist/src/colors.js
var M = [
	{
		color: "red",
		primary: 600,
		secondary: 100
	},
	{
		color: "green",
		primary: 600,
		secondary: 100
	},
	{
		color: "blue",
		primary: 600,
		secondary: 100
	},
	{
		color: "yellow",
		primary: 500,
		secondary: 100
	},
	{
		color: "purple",
		primary: 600,
		secondary: 100
	},
	{
		color: "teal",
		primary: 600,
		secondary: 100
	},
	{
		color: "orange",
		primary: 600,
		secondary: 100
	},
	{
		color: "cyan",
		primary: 600,
		secondary: 100
	},
	{
		color: "lime",
		primary: 500,
		secondary: 100
	},
	{
		color: "pink",
		primary: 600,
		secondary: 100
	}
], N = {
	inherit: "inherit",
	current: "currentColor",
	transparent: "transparent",
	black: "#000",
	white: "#fff",
	slate: {
		50: "#f8fafc",
		100: "#f1f5f9",
		200: "#e2e8f0",
		300: "#cbd5e1",
		400: "#94a3b8",
		500: "#64748b",
		600: "#475569",
		700: "#334155",
		800: "#1e293b",
		900: "#0f172a",
		950: "#020617"
	},
	gray: {
		50: "#f9fafb",
		100: "#f3f4f6",
		200: "#e5e7eb",
		300: "#d1d5db",
		400: "#9ca3af",
		500: "#6b7280",
		600: "#4b5563",
		700: "#374151",
		800: "#1f2937",
		900: "#111827",
		950: "#030712"
	},
	zinc: {
		50: "#fafafa",
		100: "#f4f4f5",
		200: "#e4e4e7",
		300: "#d4d4d8",
		400: "#a1a1aa",
		500: "#71717a",
		600: "#52525b",
		700: "#3f3f46",
		800: "#27272a",
		900: "#18181b",
		950: "#09090b"
	},
	neutral: {
		50: "#fafafa",
		100: "#f5f5f5",
		200: "#e5e5e5",
		300: "#d4d4d4",
		400: "#a3a3a3",
		500: "#737373",
		600: "#525252",
		700: "#404040",
		800: "#262626",
		900: "#171717",
		950: "#0a0a0a"
	},
	stone: {
		50: "#fafaf9",
		100: "#f5f5f4",
		200: "#e7e5e4",
		300: "#d6d3d1",
		400: "#a8a29e",
		500: "#78716c",
		600: "#57534e",
		700: "#44403c",
		800: "#292524",
		900: "#1c1917",
		950: "#0c0a09"
	},
	red: {
		50: "#fef2f2",
		100: "#fee2e2",
		200: "#fecaca",
		300: "#fca5a5",
		400: "#f87171",
		500: "#ef4444",
		600: "#dc2626",
		700: "#b91c1c",
		800: "#991b1b",
		900: "#7f1d1d",
		950: "#450a0a"
	},
	orange: {
		50: "#fff7ed",
		100: "#ffedd5",
		200: "#fed7aa",
		300: "#fdba74",
		400: "#fb923c",
		500: "#f97316",
		600: "#ea580c",
		700: "#c2410c",
		800: "#9a3412",
		900: "#7c2d12",
		950: "#431407"
	},
	amber: {
		50: "#fffbeb",
		100: "#fef3c7",
		200: "#fde68a",
		300: "#fcd34d",
		400: "#fbbf24",
		500: "#f59e0b",
		600: "#d97706",
		700: "#b45309",
		800: "#92400e",
		900: "#78350f",
		950: "#451a03"
	},
	yellow: {
		50: "#fefce8",
		100: "#fef9c3",
		200: "#fef08a",
		300: "#fde047",
		400: "#facc15",
		500: "#eab308",
		600: "#ca8a04",
		700: "#a16207",
		800: "#854d0e",
		900: "#713f12",
		950: "#422006"
	},
	lime: {
		50: "#f7fee7",
		100: "#ecfccb",
		200: "#d9f99d",
		300: "#bef264",
		400: "#a3e635",
		500: "#84cc16",
		600: "#65a30d",
		700: "#4d7c0f",
		800: "#3f6212",
		900: "#365314",
		950: "#1a2e05"
	},
	green: {
		50: "#f0fdf4",
		100: "#dcfce7",
		200: "#bbf7d0",
		300: "#86efac",
		400: "#4ade80",
		500: "#22c55e",
		600: "#16a34a",
		700: "#15803d",
		800: "#166534",
		900: "#14532d",
		950: "#052e16"
	},
	emerald: {
		50: "#ecfdf5",
		100: "#d1fae5",
		200: "#a7f3d0",
		300: "#6ee7b7",
		400: "#34d399",
		500: "#10b981",
		600: "#059669",
		700: "#047857",
		800: "#065f46",
		900: "#064e3b",
		950: "#022c22"
	},
	teal: {
		50: "#f0fdfa",
		100: "#ccfbf1",
		200: "#99f6e4",
		300: "#5eead4",
		400: "#2dd4bf",
		500: "#14b8a6",
		600: "#0d9488",
		700: "#0f766e",
		800: "#115e59",
		900: "#134e4a",
		950: "#042f2e"
	},
	cyan: {
		50: "#ecfeff",
		100: "#cffafe",
		200: "#a5f3fc",
		300: "#67e8f9",
		400: "#22d3ee",
		500: "#06b6d4",
		600: "#0891b2",
		700: "#0e7490",
		800: "#155e75",
		900: "#164e63",
		950: "#083344"
	},
	sky: {
		50: "#f0f9ff",
		100: "#e0f2fe",
		200: "#bae6fd",
		300: "#7dd3fc",
		400: "#38bdf8",
		500: "#0ea5e9",
		600: "#0284c7",
		700: "#0369a1",
		800: "#075985",
		900: "#0c4a6e",
		950: "#082f49"
	},
	blue: {
		50: "#eff6ff",
		100: "#dbeafe",
		200: "#bfdbfe",
		300: "#93c5fd",
		400: "#60a5fa",
		500: "#3b82f6",
		600: "#2563eb",
		700: "#1d4ed8",
		800: "#1e40af",
		900: "#1e3a8a",
		950: "#172554"
	},
	indigo: {
		50: "#eef2ff",
		100: "#e0e7ff",
		200: "#c7d2fe",
		300: "#a5b4fc",
		400: "#818cf8",
		500: "#6366f1",
		600: "#4f46e5",
		700: "#4338ca",
		800: "#3730a3",
		900: "#312e81",
		950: "#1e1b4b"
	},
	violet: {
		50: "#f5f3ff",
		100: "#ede9fe",
		200: "#ddd6fe",
		300: "#c4b5fd",
		400: "#a78bfa",
		500: "#8b5cf6",
		600: "#7c3aed",
		700: "#6d28d9",
		800: "#5b21b6",
		900: "#4c1d95",
		950: "#2e1065"
	},
	purple: {
		50: "#faf5ff",
		100: "#f3e8ff",
		200: "#e9d5ff",
		300: "#d8b4fe",
		400: "#c084fc",
		500: "#a855f7",
		600: "#9333ea",
		700: "#7e22ce",
		800: "#6b21a8",
		900: "#581c87",
		950: "#3b0764"
	},
	fuchsia: {
		50: "#fdf4ff",
		100: "#fae8ff",
		200: "#f5d0fe",
		300: "#f0abfc",
		400: "#e879f9",
		500: "#d946ef",
		600: "#c026d3",
		700: "#a21caf",
		800: "#86198f",
		900: "#701a75",
		950: "#4a044e"
	},
	pink: {
		50: "#fdf2f8",
		100: "#fce7f3",
		200: "#fbcfe8",
		300: "#f9a8d4",
		400: "#f472b6",
		500: "#ec4899",
		600: "#db2777",
		700: "#be185d",
		800: "#9d174d",
		900: "#831843",
		950: "#500724"
	},
	rose: {
		50: "#fff1f2",
		100: "#ffe4e6",
		200: "#fecdd3",
		300: "#fda4af",
		400: "#fb7185",
		500: "#f43f5e",
		600: "#e11d48",
		700: "#be123c",
		800: "#9f1239",
		900: "#881337",
		950: "#4c0519"
	}
};
M.reduce((e, { color: t, primary: n, secondary: r }) => ({
	...e,
	[t]: {
		primary: N[t][n],
		secondary: N[t][r]
	}
}), {});
//#endregion
//#region frontend/node_modules/svelte/src/store/index-client.js
function P(e) {
	let t, n = _((n) => {
		let r = !1, i = e.subscribe((e) => {
			t = e, r && n();
		});
		return r = !0, i;
	});
	function r() {
		return f() ? (n(), t) : ie(e);
	}
	return "set" in e ? {
		get current() {
			return r();
		},
		set current(t) {
			e.set(t);
		}
	} : { get current() {
		return r();
	} };
}
var F = [
	"label",
	"info",
	"placeholder",
	"description",
	"title",
	"value"
], me = /* @__PURE__ */ "elem_id.elem_classes.visible.interactive.server_fns.server.id.target.theme_mode.version.root.autoscroll.max_file_size.formatter.client.load_component.scale.min_width.theme.padding.loading_status.label.show_label.validation_error.show_progress.api_prefix.container.attached_events.register_component.unregister_component.dispatcher".split(".");
function I(e) {
	return typeof e == "string" && e.includes("__i18n__");
}
var he = class {
	load_component;
	#e = y(j({}));
	get shared() {
		return e(this.#e);
	}
	set shared(e) {
		t(this.#e, e, !0);
	}
	#t = y(j({}));
	get props() {
		return e(this.#t);
	}
	set props(e) {
		t(this.#t, e, !0);
	}
	#n = y((e) => e);
	get i18n() {
		return e(this.#n);
	}
	set i18n(e) {
		t(this.#n, e, !0);
	}
	i18n_store;
	_i18n_from_store;
	translatable_props = {};
	dispatcher;
	last_update = null;
	shared_props = me;
	mounted = !1;
	old_value;
	register_component;
	unregister_component;
	set_data_callback;
	get_data_callback;
	registered_id = null;
	last_shared_props;
	last_props;
	constructor(e, t) {
		for (let t in e.shared_props) this.shared[t] = e.shared_props[t];
		for (let t in e.props) t !== "i18n_store" && (this.props[t] = e.props[t]);
		if (t) for (let e in t) this.props[e] === void 0 && (this.props[e] = t[e]);
		this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? P(this.i18n_store) : void 0;
		for (let t of F) this.shared[t] = this._translate_and_store("shared", t, e.shared_props[t]), this.props[t] = this._translate_and_store("props", t, e.props[t]);
		this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {}), this.unregister_component = this.shared.unregister_component || (() => {}), this.dispatcher = this.shared.dispatcher || (() => {}), this.set_data_callback = this.set_data.bind(this), this.get_data_callback = this.get_data.bind(this), this.register_component(this.shared.id, this.set_data_callback, this.get_data_callback), this.registered_id = this.shared.id, this.last_shared_props = e.shared_props, this.last_props = e.props, h(() => {
			let t = e.shared_props.id;
			if (this.last_shared_props !== e.shared_props) {
				for (let t in e.shared_props) {
					let n = e.shared_props[t];
					n !== void 0 && (this._is_i18n_managed(`shared.${t}`, n) || (this.shared[t] = n));
				}
				this.last_shared_props = e.shared_props;
			}
			if (this.last_props !== e.props) {
				for (let t in e.props) {
					if (t === "i18n_store") continue;
					let n = e.props[t];
					n !== void 0 && (this._is_i18n_managed(`props.${t}`, n) || (this.props[t] = n));
				}
				this.last_props = e.props;
			}
			this.registered_id !== null && this.registered_id !== t && this.unregister_component(this.registered_id, this.set_data_callback), this.register_component(t, this.set_data_callback, this.get_data_callback), this.registered_id = t, w(() => {
				this.shared.id = t;
			});
		}), h(() => () => {
			this.registered_id !== null && this.unregister_component(this.registered_id, this.set_data_callback);
		}), h(() => {
			if (this.i18n_store) return this.i18n_store.subscribe(() => {
				for (let [e, t] of Object.entries(this.translatable_props)) {
					let [n, r] = e.split("."), i = this.i18n(t);
					n === "shared" ? this.shared[r] = i : this.props[r] = i;
				}
			});
		});
	}
	_is_i18n_managed(e, t) {
		let n = this.translatable_props[e];
		return n ? t === n || (delete this.translatable_props[e], !1) : !1;
	}
	_translate_and_store(e, t, n) {
		if (typeof n != "string") return n;
		let r = this.i18n(n);
		return r !== n && (this.translatable_props[`${e}.${t}`] = n), r;
	}
	live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
	dispatch(e, t) {
		this.dispatcher(this.shared.id, e, t);
	}
	async get_data() {
		return u(this.props);
	}
	update(e) {
		this.set_data(e);
	}
	set_data(e) {
		for (let t in e) {
			let n = e[t], r = I(n) ? this._translate_and_store(this.shared_props.includes(t) ? "shared" : "props", t, n) : n;
			if (this.shared_props.includes(t)) {
				let e = t;
				this.shared[e] = r;
				continue;
			}
			this.props[t] = r;
		}
	}
	watch_for_change() {
		h(() => {
			this.mounted ||= (this.old_value = this.props.value, !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
		});
	}
}, ge = i("<svg class=\"resize-handle svelte-1stq1b1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 10 10\"><line x1=\"1\" y1=\"9\" x2=\"9\" y2=\"1\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line><line x1=\"5\" y1=\"9\" x2=\"9\" y2=\"5\" stroke=\"gray\" stroke-width=\"0.5\" class=\"svelte-1stq1b1\"></line></svg>"), _e = v("<!> <!>", 1), ve = v("<div class=\"placeholder svelte-1stq1b1\"></div>");
function ye(r, i) {
	o(i, !0);
	let a = O(i, "height", 3, void 0), l = O(i, "min_height", 3, void 0), u = O(i, "max_height", 3, void 0), d = O(i, "width", 3, void 0), f = O(i, "elem_id", 3, ""), _ = O(i, "elem_classes", 19, () => []), v = O(i, "variant", 3, "solid"), te = O(i, "border_mode", 3, "base"), re = O(i, "padding", 3, !0), ie = O(i, "type", 3, "normal"), b = O(i, "test_id", 3, void 0), x = O(i, "explicit_call", 3, !1), se = O(i, "container", 3, !0), C = O(i, "visible", 3, !0), w = O(i, "allow_overflow", 3, !0), ce = O(i, "overflow_behavior", 3, "auto"), le = O(i, "scale", 3, null), D = O(i, "min_width", 3, 0), fe = O(i, "flex", 3, !1), k = O(i, "resizable", 3, !1), j = O(i, "rtl", 3, !1), M = O(i, "fullscreen", 15, !1), N = O(i, "label", 3, void 0), P = M(), F = y(void 0), me = s(() => ie() === "fieldset" ? "fieldset" : "div"), I = s(() => C() ? fe() : !1), he = y(0), ye = y(0), L = y(null), R = null, z = null, be = null;
	function xe(e) {
		M() && e.key === "Escape" && M(!1);
	}
	function Se(e) {
		let t = e.getRootNode();
		return e.closest(".gradio-container") ?? (t instanceof ShadowRoot ? t : document.body);
	}
	function Ce(e) {
		let t = document.createElement("div");
		t.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; visibility: hidden; pointer-events: none;", e.appendChild(t);
		let n = t.getBoundingClientRect();
		return t.remove(), n;
	}
	function we(e, t) {
		let n = e.parentNode;
		if (!n || n === t) return !1;
		let r = Ce(n), i = Ce(t);
		return Math.abs(r.top - i.top) > 1 || Math.abs(r.left - i.left) > 1 || Math.abs(r.width - i.width) > 1 || Math.abs(r.height - i.height) > 1;
	}
	function Te(e, t) {
		e.parentNode && e.parentNode !== t && (R = e.parentNode, be = e, z = document.createComment("fullscreen block"), R.insertBefore(z, e), t.appendChild(e));
	}
	function Ee() {
		if (!R || !be) return;
		let e = z && z.parentNode === R ? z : null;
		R.insertBefore(be, e), e?.remove(), R = null, z = null, be = null;
	}
	h(() => {
		let n = e(F);
		if (M() !== P && n) {
			if (P = M(), M()) {
				t(L, n.getBoundingClientRect(), !0), t(he, n.offsetHeight, !0), t(ye, n.offsetWidth, !0);
				let e = Se(n);
				we(n, e) && Te(n, e), window.addEventListener("keydown", xe);
			} else Ee(), t(L, null), window.removeEventListener("keydown", xe);
		}
	}), h(() => () => {
		window.removeEventListener("keydown", xe), Ee();
	});
	let De = (e) => {
		if (e !== void 0) {
			if (typeof e == "number") return e + "px";
			if (typeof e == "string") return e;
		}
	}, Oe = (t) => {
		let n = e(F);
		if (!n) return;
		let r = t.clientY, i = (e) => {
			let t = e.clientY - r;
			r = e.clientY, n.style.height = `${n.offsetHeight + t}px`;
		}, a = () => {
			window.removeEventListener("mousemove", i), window.removeEventListener("mouseup", a);
		};
		window.addEventListener("mousemove", i), window.addEventListener("mouseup", a);
	};
	var ke = pe(), Ae = c(ke), je = (r) => {
		var o = _e(), s = c(o);
		E(s, () => e(me), !1, (r, o) => {
			ue(r, (e) => t(F, e, !0), () => e(F)), T(r, (t, n, r, i, a) => ({
				"data-testid": b(),
				id: f(),
				class: `block ${t ?? ""}`,
				dir: j() ? "rtl" : "ltr",
				"aria-label": N(),
				style: "",
				[de]: {
					hidden: C() === "hidden",
					padded: re(),
					flex: e(I),
					border_focus: te() === "focus",
					border_contrast: te() === "contrast",
					"hide-container": !x() && !se(),
					fullscreen: M(),
					animating: M() && e(L) !== null,
					"auto-margin": le() === null
				},
				[ae]: {
					height: n,
					"min-height": r,
					"max-height": i,
					"--start-top": e(L) ? `${e(L).top}px` : "0px",
					"--start-left": e(L) ? `${e(L).left}px` : "0px",
					"--start-width": e(L) ? `${e(L).width}px` : "0px",
					"--start-height": e(L) ? `${e(L).height}px` : "0px",
					width: a,
					"border-style": v(),
					overflow: w() ? ce() : "hidden",
					"flex-grow": le(),
					"min-width": `calc(min(${D()}px, 100%))`
				}
			}), [
				() => _()?.join(" ") || "",
				() => M() ? void 0 : De(a()),
				() => M() ? void 0 : De(l()),
				() => M() ? void 0 : De(u()),
				() => M() ? void 0 : typeof d() == "number" ? `calc(min(${d()}px, 100%))` : De(d())
			], void 0, void 0, "svelte-1stq1b1");
			var s = _e(), p = c(s);
			S(p, () => i.children ?? ne);
			var h = g(p, 2), y = (e) => {
				var t = ge();
				m("mousedown", t, Oe), n(e, t);
			};
			A(h, (e) => {
				k() && e(y);
			}), n(o, s);
		});
		var h = g(s, 2), y = (t) => {
			var r = ve();
			let i;
			p(() => i = oe(r, "", i, {
				height: e(he) + "px",
				width: e(ye) + "px"
			})), n(t, r);
		};
		A(h, (e) => {
			M() && e(y);
		}), n(r, o);
	};
	A(Ae, (e) => {
		(C() === !0 || C() === "hidden") && e(je);
	}), n(r, ke), ee();
}
//#endregion
//#region frontend/node_modules/@gradio/atoms/dist/src/CustomButton.svelte
r(["mousedown"]), r(["click"]), D(), r(["click"]), r(["click"]);
//#endregion
//#region frontend/Index.svelte
var L = /* @__PURE__ */ new Set([
	"$$slots",
	"$$events",
	"$$legacy"
]), R = v("<div class=\"poster svelte-r41nsf\"><div class=\"poster-grid svelte-r41nsf\"></div></div>"), z = v("<span class=\"msg svelte-r41nsf\"> </span>"), be = v("<span class=\"svelte-r41nsf\"><span class=\"k svelte-r41nsf\"> </span> </span>"), xe = v("<div class=\"hud-row mono stats svelte-r41nsf\"></div>"), Se = v("<span> </span>"), Ce = v("<div class=\"kr svelte-r41nsf\"></div>"), we = v("<div class=\"progress svelte-r41nsf\" title=\"Session time\"><div class=\"bar svelte-r41nsf\"><div class=\"fill svelte-r41nsf\"></div></div> <span class=\"mono svelte-r41nsf\"> </span></div>"), Te = v("<button><svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"svelte-r41nsf\"><path d=\"M12 2 2 7l10 5 10-5-10-5z\" class=\"svelte-r41nsf\"></path><path d=\"m2 17 10 5 10-5\" class=\"svelte-r41nsf\"></path><path d=\"m2 12 10 5 10-5\" class=\"svelte-r41nsf\"></path></svg> <span class=\"lbl svelte-r41nsf\"> </span></button>"), Ee = i("<svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"svelte-r41nsf\"><path d=\"M8 3v3a2 2 0 0 1-2 2H3M21 8h-3a2 2 0 0 1-2-2V3M3 16h3a2 2 0 0 1 2 2v3M16 21v-3a2 2 0 0 1 2-2h3\" class=\"svelte-r41nsf\"></path></svg>"), De = i("<svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"svelte-r41nsf\"><path d=\"M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3\" class=\"svelte-r41nsf\"></path></svg>"), Oe = v("<div class=\"overlay dim svelte-r41nsf\"><div class=\"spinner svelte-r41nsf\" aria-hidden=\"true\"></div> <div class=\"ov-text svelte-r41nsf\"> </div></div>"), ke = v("<div class=\"overlay error svelte-r41nsf\"><div class=\"ov-title svelte-r41nsf\">Error</div> <div class=\"ov-text svelte-r41nsf\"> </div> <button class=\"btn primary small svelte-r41nsf\">Try again</button></div>"), Ae = v("<div class=\"ov-text svelte-r41nsf\"> </div>"), je = v("<div class=\"overlay dim svelte-r41nsf\"><div class=\"ov-title svelte-r41nsf\">Session ended</div> <!> <button class=\"btn primary small svelte-r41nsf\"><svg viewBox=\"0 0 24 24\" width=\"14\" height=\"14\" fill=\"currentColor\" class=\"svelte-r41nsf\"><path d=\"M8 5v14l11-7z\" class=\"svelte-r41nsf\"></path></svg> Start again</button></div>"), Me = v("<div><button class=\"big-play svelte-r41nsf\" aria-label=\"Start\"><svg viewBox=\"0 0 24 24\" width=\"30\" height=\"30\" fill=\"currentColor\" class=\"svelte-r41nsf\"><path d=\"M8 5v14l11-7z\" class=\"svelte-r41nsf\"></path></svg></button> <div class=\"ov-text svelte-r41nsf\"> </div></div>"), Ne = v("<div class=\"chip buffering glass svelte-r41nsf\"><span class=\"mini-spin svelte-r41nsf\"></span>buffering</div>"), Pe = v("<div class=\"chip hint glass svelte-r41nsf\">Click to control</div>"), Fe = v("<span class=\"label svelte-r41nsf\"> </span>"), Ie = v("<button> </button>"), Le = v("<div class=\"pad svelte-r41nsf\" data-testid=\"worldviewer-pad\"><div class=\"cluster svelte-r41nsf\"><div class=\"cap svelte-r41nsf\">move</div> <div class=\"cross svelte-r41nsf\"><!> <!> <!> <!></div></div> <div class=\"cluster svelte-r41nsf\"><div class=\"cap svelte-r41nsf\">height</div> <div class=\"col svelte-r41nsf\"><!> <!></div></div> <div class=\"cluster svelte-r41nsf\"><div class=\"cap svelte-r41nsf\">look</div> <div class=\"cross svelte-r41nsf\"><!> <!> <!> <!></div></div></div>"), Re = v("<div><div tabindex=\"0\" role=\"application\" aria-label=\"World viewer. Click, then use W A S D, arrows, Q E, R F, Space and Shift to move the camera. Enter starts, Escape stops.\" data-testid=\"worldviewer-stage\"><canvas data-testid=\"worldviewer-canvas\"></canvas> <!> <canvas aria-label=\"Render condition preview\"></canvas> <div aria-live=\"polite\"><div class=\"hud-row status-row svelte-r41nsf\"><span></span> <span class=\"status-name svelte-r41nsf\"> </span> <!></div> <div class=\"hud-row mono svelte-r41nsf\"><span class=\"svelte-r41nsf\"> </span> <span class=\"sep svelte-r41nsf\">·</span> <span class=\"svelte-r41nsf\"> </span></div> <!> <div class=\"hud-keys svelte-r41nsf\" aria-hidden=\"true\"><!> <div class=\"kr svelte-r41nsf\"><span>⇧</span> <span>␣</span></div></div> <!></div> <div class=\"tools svelte-r41nsf\"><!> <button class=\"icon-btn glass svelte-r41nsf\" aria-label=\"Toggle fullscreen\"><!></button></div> <!> <!> <!></div> <div class=\"toolbar svelte-r41nsf\"><div class=\"left svelte-r41nsf\"><button class=\"btn primary svelte-r41nsf\" data-testid=\"worldviewer-start\"><svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"svelte-r41nsf\"><path d=\"M8 5v14l11-7z\" class=\"svelte-r41nsf\"></path></svg> Start</button> <button class=\"btn stop svelte-r41nsf\" data-testid=\"worldviewer-stop\"><svg viewBox=\"0 0 24 24\" width=\"14\" height=\"14\" fill=\"currentColor\" class=\"svelte-r41nsf\"><rect x=\"6\" y=\"6\" width=\"12\" height=\"12\" rx=\"2\" class=\"svelte-r41nsf\"></rect></svg> Stop</button> <!></div> <div class=\"hints svelte-r41nsf\" aria-hidden=\"true\"><span class=\"svelte-r41nsf\"><kbd class=\"svelte-r41nsf\">W</kbd><kbd class=\"svelte-r41nsf\">A</kbd><kbd class=\"svelte-r41nsf\">S</kbd><kbd class=\"svelte-r41nsf\">D</kbd> move</span> <span class=\"svelte-r41nsf\"><kbd class=\"svelte-r41nsf\">Q</kbd><kbd class=\"svelte-r41nsf\">E</kbd>/<kbd class=\"svelte-r41nsf\">←</kbd><kbd class=\"svelte-r41nsf\">→</kbd> turn</span> <span class=\"svelte-r41nsf\"><kbd class=\"svelte-r41nsf\">R</kbd><kbd class=\"svelte-r41nsf\">F</kbd> look</span> <span class=\"svelte-r41nsf\"><kbd class=\"svelte-r41nsf\">Space</kbd><kbd class=\"svelte-r41nsf\">⇧</kbd> up/down</span> <span class=\"svelte-r41nsf\"><kbd class=\"svelte-r41nsf\">↵</kbd> start <kbd class=\"svelte-r41nsf\">Esc</kbd> stop</span></div> <button><svg viewBox=\"0 0 24 24\" width=\"18\" height=\"18\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"svelte-r41nsf\"><path d=\"M6 11h4M8 9v4M15 12h.01M18 10h.01\" class=\"svelte-r41nsf\"></path><rect x=\"2\" y=\"6\" width=\"20\" height=\"12\" rx=\"6\" class=\"svelte-r41nsf\"></rect></svg> <span class=\"lbl svelte-r41nsf\">Pad</span></button></div> <!></div>");
function B(r, i) {
	o(i, !0);
	var c = this && this.__awaiter || function(e, t, n, r) {
		function i(e) {
			return e instanceof n ? e : new n(function(t) {
				t(e);
			});
		}
		return new (n ||= Promise)(function(n, a) {
			function o(e) {
				try {
					c(r.next(e));
				} catch (e) {
					a(e);
				}
			}
			function s(e) {
				try {
					c(r.throw(e));
				} catch (e) {
					a(e);
				}
			}
			function c(e) {
				e.done ? n(e.value) : i(e.value).then(o, s);
			}
			c((r = r.apply(e, t || [])).next());
		});
	};
	let u = new he(C(i, L));
	u.watch_for_change();
	let f = s(() => Math.max(1, u.props.prebuffer_frames ?? 6)), _ = s(() => u.props.catchup_rate ?? 1.15), v = s(() => u.props.heartbeat_ms ?? 250), ie = s(() => 1e3 / Math.max(1, u.props.max_control_hz ?? 20)), ae = s(() => u.props.placeholder ?? "Press Start, then click here and use WASD / arrows to move"), S = y(void 0), T = y(void 0), E = y(void 0), D = y(void 0), O = y(null), de = y(!1), pe = y(!1), M = y(j(w(() => !!u.props.show_render))), N = y(!1), P = y(!1), F = y(!1), me = y(!1), I = y(0), ge = y(0), _e = y(j(w(() => u.props.aspect_ratio || 832 / 480))), ve = y(j(performance.now())), B = y(j(performance.now())), V = s(() => u.props.value ?? null), H = s(() => (e(V) === null || e(V) === void 0 ? void 0 : e(V).status) ?? "idle"), U = s(() => u.shared.loading_status), ze = s(() => (e(U) === null || e(U) === void 0 ? void 0 : e(U).status) === "error" && (e(O) === "start" || e(H) === "loading" || e(H) === "running")), W = s(() => e(ze) ? "error" : e(O) === "start" ? "loading" : e(O) === "stop" ? "ended" : e(H)), G = s(() => e(ze) ? (e(U) === null || e(U) === void 0 ? void 0 : e(U).message) || (e(V) === null || e(V) === void 0 ? void 0 : e(V).message) || "Something went wrong" : e(O) === "start" ? Ke() || "Starting…" : e(O) === "stop" ? "Stopped" : (e(V) === null || e(V) === void 0 ? void 0 : e(V).message) ?? ""), Be = s(() => e(W) === "running" || e(W) === "loading"), Ve = s(() => !e(Be)), He = s(() => e(Be)), K = s(() => (e(V) === null || e(V) === void 0 ? void 0 : e(V).stats) ?? {}), Ue = s(() => typeof e(K).limit_s == "number" ? e(K).limit_s : null), We = s(() => {
		let t = typeof e(K).elapsed_s == "number" ? e(K).elapsed_s : 0, n = e(H) === "running" ? (e(ve) - e(B)) / 1e3 : 0;
		return e(Ue) ? Math.min(e(Ue), t + n) : t + n;
	}), Ge = s(() => Object.entries(e(K)).filter(([e]) => e !== "elapsed_s" && e !== "limit_s"));
	function Ke() {
		let e = u.shared.loading_status;
		return e?.status === "pending" && e.queue_position != null && e.queue_position > 0 ? `Waiting in queue (position ${e.queue_position + 1}${e.queue_size ? ` / ${e.queue_size}` : ""})…` : "";
	}
	function qe(e, t) {
		return typeof t == "number" ? e.endsWith("_ms") ? `${t.toFixed(0)} ms` : e.endsWith("_s") ? `${t.toFixed(1)} s` : Number.isInteger(t) ? String(t) : t.toFixed(1) : String(t);
	}
	function Je(e) {
		return e.replace(/_(ms|s)$/, "").replace(/_/g, " ");
	}
	let q = [], Ye = 0, Xe = Promise.resolve(), Ze = null, Qe = /* @__PURE__ */ new Set(), $e = -1, et = 12, J = !1, tt = 0, Y = 0, X = null, Z = [], Q = 0, nt = 0;
	function rt(e) {
		e && ("close" in e.bm && e.bm.close(), e.rb && "close" in e.rb && e.rb.close());
	}
	function it(e) {
		Ye++;
		for (let e of q) rt(e);
		q = [], Qe = /* @__PURE__ */ new Set(), $e = -1, Ze = e, J = !1, Y = 0, Z = [], t(I, 0);
	}
	function at(e) {
		let t = e.indexOf(","), n = e.slice(5, t).split(";")[0] || "image/jpeg", r = atob(e.slice(t + 1)), i = new Uint8Array(r.length);
		for (let e = 0; e < r.length; e++) i[e] = r.charCodeAt(e);
		return new Blob([i], { type: n });
	}
	function ot(e) {
		return c(this, void 0, void 0, function* () {
			if (typeof createImageBitmap == "function" && e.startsWith("data:")) return yield createImageBitmap(at(e));
			let t = new Image();
			return t.decoding = "async", t.src = e, yield t.decode(), t;
		});
	}
	function st(e) {
		let n = Ye, r = e.fps > 0 ? e.fps : 15, i = Promise.all(e.frames.map(ot)), a = e.renders?.length ? Promise.all(e.renders.map((e) => ot(e).catch(() => null))) : Promise.resolve(null);
		Xe = Xe.then(() => c(this, void 0, void 0, function* () {
			let o, s;
			try {
				[o, s] = yield Promise.all([i, a]);
			} catch (t) {
				console.warn("[WorldViewer] failed to decode chunk", e.id, t);
				return;
			}
			let c = o.map((e, t) => ({
				bm: e,
				rb: s?.[t] ?? null,
				fps: r
			}));
			if (n !== Ye) {
				c.forEach(rt);
				return;
			}
			s && s.some(Boolean) && t(F, !0), et = Math.max(1, c.length), q.push(...c), t(I, q.length, !0);
		}));
	}
	function ct(n) {
		if (!n) return;
		(e(O) === "start" || e(O) === "stop" && n.status !== "running" && n.status !== "loading") && t(O, null), t(B, performance.now(), !0);
		let r = n.chunk;
		if (r && Array.isArray(r.frames) && r.frames.length !== 0) {
			if (r.session !== Ze) it(r.session);
			else if (r.id === 0 && $e > 0) it(r.session);
			else if (Qe.has(r.id)) return;
			Qe.add(r.id), $e = Math.max($e, r.id), st(r);
		}
	}
	h(() => {
		let e = u.props.value;
		w(() => ct(e));
	});
	function lt(n) {
		var r, i;
		if (!e(E)) return;
		let a = n.bm.width, o = n.bm.height;
		if (a && o && (e(E).width !== a || e(E).height !== o) && (e(E).width = a, e(E).height = o, t(_e, a / o)), (r = e(E).getContext("2d")) == null || r.drawImage(n.bm, 0, 0, e(E).width, e(E).height), n.rb && e(D)) {
			let t = n.rb.width, r = n.rb.height;
			t && r && (e(D).width !== t || e(D).height !== r) && (e(D).width = t, e(D).height = r), (i = e(D).getContext("2d")) == null || i.drawImage(n.rb, 0, 0, e(D).width, e(D).height);
		}
		let s = X;
		X = n, s && s !== n && rt(s), e(P) || t(P, !0);
	}
	function ut() {
		var t, n;
		X && e(E) && ((t = e(E).getContext("2d")) == null || t.drawImage(X.bm, 0, 0, e(E).width, e(E).height), X.rb && e(D) && ((n = e(D).getContext("2d")) == null || n.drawImage(X.rb, 0, 0, e(D).width, e(D).height)));
	}
	function dt(n) {
		Q = requestAnimationFrame(dt);
		let r = tt ? Math.min(n - tt, 250) : 0;
		tt = n;
		let i = e(H) === "running" || e(H) === "loading";
		if (J || (q.length >= e(f) || q.length > 0 && !i) && (J = !0, Y = 1e3 / (q[0]?.fps || 15)), J) {
			if (q.length === 0) J = !1;
			else {
				let t = q.length, i = t > 4 * et ? e(_) * e(_) : t > 2 * et ? e(_) : 1;
				Y += r * i;
				let a = 1e3 / (q[0].fps || 15);
				Y >= a && (Y = Math.min(Y - a, a), lt(q.shift()), Z.push(n), Z.length > 30 && Z.shift());
			}
		}
		if (n - nt > 120) {
			nt = n;
			let r = i && !J && e(P);
			r !== e(me) && t(me, r, !0), e(I) !== q.length && t(I, q.length, !0);
			let a = 0;
			Z.length > 2 && n - Z[Z.length - 1] < 1e3 && (a = (Z.length - 1) * 1e3 / (Z[Z.length - 1] - Z[0])), Math.abs(a - e(ge)) > .05 && t(ge, a, !0), t(ve, performance.now(), !0);
		}
	}
	let ft = {
		KeyW: "fwd",
		ArrowUp: "fwd",
		KeyS: "back",
		ArrowDown: "back",
		KeyA: "left",
		KeyD: "right",
		KeyQ: "yawL",
		ArrowLeft: "yawL",
		KeyE: "yawR",
		ArrowRight: "yawR",
		KeyR: "pitchU",
		KeyF: "pitchD",
		Space: "up",
		ShiftLeft: "down",
		ShiftRight: "down"
	}, $ = y(j({})), pt = y(j({})), mt = s(() => /* @__PURE__ */ new Set([...Object.values(e($)), ...Object.values(e(pt))]));
	function ht(e) {
		let t = (t, n) => +!!e.has(t) - !!e.has(n);
		return {
			forward: t("fwd", "back"),
			right: t("right", "left"),
			up: t("up", "down"),
			yaw: t("yawR", "yawL"),
			pitch: t("pitchU", "pitchD")
		};
	}
	let gt = 0, _t = "", vt = 0, yt = null;
	function bt(t = !1) {
		let n = ht(e(mt)), r = `${n.forward},${n.right},${n.up},${n.yaw},${n.pitch}`;
		if (!t && r === _t) return;
		let i = performance.now(), a = vt + e(ie) - i;
		if (a > 0) {
			yt ||= setTimeout(() => {
				yt = null, bt(!0);
			}, a);
			return;
		}
		_t = r, vt = i;
		let o = Object.assign(Object.assign({}, n), {
			seq: ++gt,
			session: Ze ?? ""
		});
		u.dispatch("control", o);
	}
	h(() => {
		e(mt), w(() => bt(!1));
	}), h(() => {
		if (!e(Be)) return;
		let t = setInterval(() => bt(!0), e(v));
		return () => clearInterval(t);
	});
	function xt() {
		e(Ve) && (t(O, "start"), t(B, performance.now(), !0), u.dispatch("start", {}), e(T) === null || e(T) === void 0 || e(T).focus({ preventScroll: !0 }));
	}
	function St() {
		e(He) && (t(O, "stop"), u.dispatch("stop", {}));
	}
	function Ct(t) {
		if (t.ctrlKey || t.metaKey || t.altKey) return;
		if (t.code === "Enter" || t.code === "NumpadEnter") {
			t.preventDefault(), xt();
			return;
		}
		if (t.code === "Escape") {
			t.preventDefault(), St();
			return;
		}
		let n = ft[t.code];
		n && (t.preventDefault(), e($)[t.code] !== n && (e($)[t.code] = n));
	}
	function wt(t) {
		ft[t.code] && (t.preventDefault(), delete e($)[t.code]);
	}
	function Tt() {
		Object.keys(e($)).length && t($, {}, !0), Object.keys(e(pt)).length && t(pt, {}, !0);
	}
	function Et() {
		t(de, !1), Object.keys(e($)).length && t($, {}, !0);
	}
	function Dt(t, n) {
		var r, i;
		t.preventDefault(), (i = (r = t.currentTarget).setPointerCapture) == null || i.call(r, t.pointerId), e(pt)[t.pointerId] = n, e(T) === null || e(T) === void 0 || e(T).focus({ preventScroll: !0 });
	}
	function Ot(t) {
		t.pointerId in e(pt) && delete e(pt)[t.pointerId];
	}
	function kt() {
		return c(this, void 0, void 0, function* () {
			try {
				document.fullscreenElement ? yield document.exitFullscreen() : yield e(S) === null || e(S) === void 0 ? void 0 : e(S).requestFullscreen();
			} catch (e) {
				console.warn("[WorldViewer] fullscreen failed", e);
			}
		});
	}
	function At() {
		document.hidden && Tt();
	}
	function jt() {
		t(pe, document.fullscreenElement === e(S)), requestAnimationFrame(ut);
	}
	le(() => {
		let e = u.props.show_pad;
		t(N, e === !0 || e == null && window.matchMedia?.call(window, "(pointer: coarse)").matches === !0, !0), Q = requestAnimationFrame(dt), document.addEventListener("fullscreenchange", jt), document.addEventListener("visibilitychange", At), window.addEventListener("blur", Tt);
	}), fe(() => {
		cancelAnimationFrame(Q), yt && clearTimeout(yt), document.removeEventListener("fullscreenchange", jt), document.removeEventListener("visibilitychange", At), window.removeEventListener("blur", Tt), it(null), rt(X);
	});
	let Mt = [[
		{
			k: "Q",
			vk: "yawL"
		},
		{
			k: "W",
			vk: "fwd"
		},
		{
			k: "E",
			vk: "yawR"
		},
		{
			k: "R",
			vk: "pitchU"
		}
	], [
		{
			k: "A",
			vk: "left"
		},
		{
			k: "S",
			vk: "back"
		},
		{
			k: "D",
			vk: "right"
		},
		{
			k: "F",
			vk: "pitchD"
		}
	]];
	ye(r, {
		get visible() {
			return u.shared.visible;
		},
		get elem_id() {
			return u.shared.elem_id;
		},
		get elem_classes() {
			return u.shared.elem_classes;
		},
		get container() {
			return u.shared.container;
		},
		get scale() {
			return u.shared.scale;
		},
		get min_width() {
			return u.shared.min_width;
		},
		padding: !1,
		allow_overflow: !1,
		children: (r, i) => {
			var o = Re();
			let c;
			var f = a(o);
			let h, _;
			var v = a(f);
			let y;
			ue(v, (e) => t(E, e), () => e(E));
			var ee = g(v, 2), ie = (e) => {
				var t = R();
				n(e, t);
			};
			A(ee, (t) => {
				e(P) || t(ie);
			});
			var C = g(ee, 2);
			let w;
			ue(C, (e) => t(D, e), () => e(D));
			var le = g(C, 2);
			let O;
			var fe = a(le), j = a(fe), he = g(j, 2), ve = d(he, !0), ye = g(he, 2), L = (t) => {
				var r = z(), i = d(r, !0);
				p(() => {
					k(r, "title", e(G)), b(i, e(G));
				}), n(t, r);
			};
			A(ye, (t) => {
				e(G) && e(W) !== "loading" && e(W) !== "error" && t(L);
			}), l(fe);
			var B = g(fe, 2), V = a(B), H = d(V), U = g(V, 4), ze = d(U);
			l(B);
			var K = g(B, 2), Ke = (t) => {
				var r = xe();
				se(r, 21, () => e(Ge), ([e, t]) => e, (t, r) => {
					var i = s(() => te(e(r), 2));
					let o = () => e(i)[0], c = () => e(i)[1];
					var u = be(), f = a(u), m = d(f, !0), h = g(f);
					l(u), p((e, t) => {
						b(m, e), b(h, ` ${t ?? ""}`);
					}, [() => Je(o()), () => qe(o(), c())]), n(t, u);
				}), l(r), n(t, r);
			};
			A(K, (t) => {
				e(Ge).length && t(Ke);
			});
			var q = g(K, 2), Ye = a(q);
			se(Ye, 17, () => Mt, re, (t, r) => {
				var i = Ce();
				se(i, 21, () => e(r), (e) => e.k, (t, r) => {
					var i = Se();
					let a;
					var o = d(i, !0);
					p((t) => {
						a = x(i, 1, "mk svelte-r41nsf", null, a, { on: t }), b(o, e(r).k);
					}, [() => e(mt).has(e(r).vk)]), n(t, i);
				}), l(i), n(t, i);
			});
			var Xe = g(Ye, 2), Ze = a(Xe);
			let Qe;
			var $e = g(Ze, 2);
			let et;
			l(Xe), l(q);
			var J = g(q, 2), tt = (t) => {
				var r = we(), i = a(r), o = a(i);
				let s;
				l(i);
				var c = g(i, 2), u = d(c);
				l(r), p((e, t, n) => {
					s = oe(o, "", s, { width: e }), b(u, `${t ?? ""}s / ${n ?? ""}s`);
				}, [
					() => `${Math.min(100, 100 * e(We) / e(Ue))}%`,
					() => e(We).toFixed(0),
					() => e(Ue).toFixed(0)
				]), n(t, r);
			};
			A(J, (t) => {
				e(Ue) && t(tt);
			}), l(le);
			var Y = g(le, 2), X = a(Y), Z = (r) => {
				var i = Te();
				let o;
				var s = g(a(i), 2), c = d(s, !0);
				l(i), p(() => {
					o = x(i, 1, "icon-btn glass svelte-r41nsf", null, o, { on: e(M) }), k(i, "title", e(M) ? "Hide render" : "Show render"), k(i, "aria-pressed", e(M)), b(c, e(M) ? "Hide render" : "Show render");
				}), m("click", i, () => {
					t(M, !e(M)), requestAnimationFrame(ut);
				}), n(r, i);
			};
			A(X, (t) => {
				e(F) && t(Z);
			});
			var Q = g(X, 2), nt = a(Q), rt = (e) => {
				var t = Ee();
				n(e, t);
			}, it = (e) => {
				var t = De();
				n(e, t);
			};
			A(nt, (t) => {
				e(pe) ? t(rt) : t(it, -1);
			}), l(Q), l(Y);
			var at = g(Y, 2), ot = (t) => {
				var r = Oe(), i = g(a(r), 2), o = d(i, !0);
				l(r), p(() => b(o, e(G) || "Loading…")), n(t, r);
			}, st = (t) => {
				var r = ke(), i = g(a(r), 2), o = d(i, !0), s = g(i, 2);
				l(r), p(() => b(o, e(G))), m("click", s, xt), n(t, r);
			}, ct = (t) => {
				var r = je(), i = g(a(r), 2), o = (t) => {
					var r = Ae(), i = d(r, !0);
					p(() => b(i, e(G))), n(t, r);
				};
				A(i, (t) => {
					e(G) && t(o);
				});
				var s = g(i, 2);
				l(r), m("click", s, xt), n(t, r);
			}, lt = (t) => {
				var r = Me();
				let i;
				var o = a(r), s = g(o, 2), c = d(s, !0);
				l(r), p(() => {
					i = x(r, 1, "overlay svelte-r41nsf", null, i, { dim: e(P) }), b(c, e(G) || e(ae));
				}), m("click", o, xt), n(t, r);
			};
			A(at, (t) => {
				e(W) === "loading" ? t(ot) : e(W) === "error" ? t(st, 1) : e(W) === "ended" && e(I) === 0 ? t(ct, 2) : e(W) === "idle" && t(lt, 3);
			});
			var dt = g(at, 2), ft = (e) => {
				var t = Ne();
				n(e, t);
			};
			A(dt, (t) => {
				e(me) && e(W) === "running" && t(ft);
			});
			var $ = g(dt, 2), pt = (e) => {
				var t = Pe();
				n(e, t);
			};
			A($, (t) => {
				e(W) === "running" && !e(de) && t(pt);
			}), l(f), ue(f, (e) => t(T, e), () => e(T));
			var ht = g(f, 2), gt = a(ht), _t = a(gt), vt = g(_t, 2), yt = g(vt, 2), bt = (e) => {
				var t = Fe(), r = d(t, !0);
				p(() => b(r, u.shared.label)), n(e, t);
			};
			A(yt, (e) => {
				u.shared.show_label && u.shared.label && e(bt);
			}), l(gt);
			var Tt = g(gt, 4);
			let At;
			l(ht);
			var jt = g(ht, 2), Nt = (t) => {
				var r = Le();
				{
					let t = (t, r = ne, i = ne, a = ne, o = ne) => {
						var s = Ie();
						let c;
						var l = d(s, !0);
						p((e) => {
							c = x(s, 1, `pb ${o() ?? ""}`, "svelte-r41nsf", c, { on: e }), k(s, "title", a()), k(s, "aria-label", a()), b(l, i());
						}, [() => e(mt).has(r())]), m("pointerdown", s, (e) => Dt(e, r())), m("pointerup", s, Ot), ce("pointercancel", s, Ot), ce("lostpointercapture", s, Ot), m("contextmenu", s, (e) => e.preventDefault()), n(t, s);
					};
					var i = a(r), o = g(a(i), 2), s = a(o);
					t(s, () => "fwd", () => "▲", () => "Forward (W)", () => "n");
					var c = g(s, 2);
					t(c, () => "left", () => "◀", () => "Strafe left (A)", () => "w");
					var u = g(c, 2);
					t(u, () => "right", () => "▶", () => "Strafe right (D)", () => "e"), t(g(u, 2), () => "back", () => "▼", () => "Backward (S)", () => "s"), l(o), l(i);
					var f = g(i, 2), h = g(a(f), 2), _ = a(h);
					t(_, () => "up", () => "↑", () => "Up (Space)", () => ""), t(g(_, 2), () => "down", () => "↓", () => "Down (Shift)", () => ""), l(h), l(f);
					var v = g(f, 2), y = g(a(v), 2), ee = a(y);
					t(ee, () => "pitchU", () => "⌃", () => "Look up (R)", () => "n");
					var te = g(ee, 2);
					t(te, () => "yawL", () => "↶", () => "Turn left (Q / ←)", () => "w");
					var re = g(te, 2);
					t(re, () => "yawR", () => "↷", () => "Turn right (E / →)", () => "e"), t(g(re, 2), () => "pitchD", () => "⌄", () => "Look down (F)", () => "s"), l(y), l(v), l(r);
				}
				n(t, r);
			};
			A(jt, (t) => {
				e(N) && t(Nt);
			}), l(o), ue(o, (e) => t(S, e), () => e(S)), p((t, n, r) => {
				c = x(o, 1, "wv svelte-r41nsf", null, c, { fullscreen: e(pe) }), h = x(f, 1, "stage svelte-r41nsf", null, h, {
					focused: e(de),
					active: e(Be)
				}), _ = oe(f, "", _, { "--ar": e(_e) }), y = x(v, 1, "screen svelte-r41nsf", null, y, { hidden: !e(P) }), w = x(C, 1, "pip svelte-r41nsf", null, w, { hidden: !(e(M) && e(F)) }), O = x(le, 1, "hud glass svelte-r41nsf", null, O, { hidden: e(W) === "idle" && !e(P) }), x(j, 1, `dot ${e(W) ?? ""}`, "svelte-r41nsf"), b(ve, e(W)), b(H, `play ${t ?? ""} fps`), b(ze, `buf ${e(I) ?? ""}`), Qe = x(Ze, 1, "mk wide svelte-r41nsf", null, Qe, { on: n }), et = x($e, 1, "mk wider svelte-r41nsf", null, et, { on: r }), k(Q, "title", e(pe) ? "Exit fullscreen" : "Fullscreen"), _t.disabled = !e(Ve), vt.disabled = !e(He), At = x(Tt, 1, "icon-btn plain svelte-r41nsf", null, At, { on: e(N) }), k(Tt, "title", e(N) ? "Hide control pad" : "Show control pad"), k(Tt, "aria-pressed", e(N));
			}, [
				() => e(ge).toFixed(1),
				() => e(mt).has("down"),
				() => e(mt).has("up")
			]), m("keydown", f, Ct), m("keyup", f, wt), ce("focus", f, () => t(de, !0)), ce("blur", f, Et), m("pointerdown", f, () => e(T)?.focus({ preventScroll: !0 })), m("click", Q, kt), m("click", _t, xt), m("click", vt, St), m("click", Tt, () => t(N, !e(N))), n(r, o);
		},
		$$slots: { default: !0 }
	}), ee();
}
r([
	"keydown",
	"keyup",
	"pointerdown",
	"click",
	"pointerup",
	"contextmenu"
]);
//#endregion
export { B as default };
